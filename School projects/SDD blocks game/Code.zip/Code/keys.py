from tkinter import*
from pynput import keyboard
from PIL import Image, ImageTk
top = Tk()
top.geometry("800x600")




def clicker(event):
    print("hi")
    label=Label(top, text='hi')
    label.pack()
def clickers(event):
    print("Shift")
    label=Label(top, text='Shift')
    label.pack()
button=Button(top, text='ok')
button.bind("<Left>", clicker)
button.bind("<Shift_L>", clickers)
button.pack()


         
top.mainloop()
