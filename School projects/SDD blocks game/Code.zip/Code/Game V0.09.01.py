from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
top = Tk()
top.geometry("800x700")
top.configure(bg = '#068C83')
for i in range(1,16):
    for j in range(3,33):
        frame = Frame(top, height = 20, width = 20, bg = 'black')
        frame.grid(column = i, row = j)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 0, row = 0, padx=100)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 0, row = 1, padx=100)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 0, row = 2, padx=100)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 2, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 3, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 4, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 5, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 6, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 7, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 8, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 9, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 10, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 11, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 12, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 13, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 14, row = 32)

frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 15, row = 32)






frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 3)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 4)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 5)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 6)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 7)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 8)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 9)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 10)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 11)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 12)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 13)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 14)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 15)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 16)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 17)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 18)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 19)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 20)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 21)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 22)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 23)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 24)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 25)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 26)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 27)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 28)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 29)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 31)



rotationPosition = [[[[3,8], [3,9], [4,8], [4,9]]], [[[3,7], [3,8], [3,9], [4,7]], [[2,8], [3,8], [4,8], [4,9]], [[2,9], [3,7], [3,8], [3,9]],
                    [[2,7], [2,8], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,9]], [[2,8], [2,9], [3,8], [4,8]], [[2,7], [3,7], [3,8], [3,9]],
                    [[2,8], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [4,8]], [[2,8], [3,8], [3,9], [4,8]], [[2,8], [3,7], [3,8], [3,9]],
                    [[2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [4,8], [4,9]], [[2,9], [3,8], [3,9], [4,8]]], [[[3,8], [3,9], [4,7], [4,8]],
                    [[2,7], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [3,10]], [[1,9], [2,9], [3,9], [4,9]]], [[[3,7], [3,8], [3,9], [4,8], [5,8]],
                    [[2,8], [3,8], [3,9], [3,10], [4,8]], [[1,8], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,6], [3,7], [3,8], [4,8]]],
                    [[[3,7], [3,8], [3,9], [4,7], [4,8]], [[2,8], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,7], [3,8], [3,9]],
                    [[2,7], [2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,8], [3,9], [4,8]],
                    [[2,7], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,7], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [3,10], [4,7]],
                    [[1,9], [2,9], [3,9], [4,9], [4,10]], [[2,10], [3,7], [3,8], [3,9], [3,10]], [[1,8], [1,9], [2,9], [3,9], [4,9]]],
                    [[[3,7], [3,8], [3,9], [3,10], [4,10]], [[1,9], [1,10], [2,9], [3,9], [4,9]], [[2,7], [3,7], [3,8], [3,9], [3,10]],
                    [[1,9], [2,9], [3,9], [4,8], [4,9]]], [[[3,6], [3,7], [3,8], [3,9], [3,10]], [[1,8], [2,8], [3,8], [4,8], [5,8]]], [[[3,8]]], [[[3,8]]],
                    [[[3,8]]]]
#spawns right to left then up to down
#1-4 piece O shape, 2-4 piece L shape, 3-4 piece J shape, 4-4 piece T shape, 5-4 piece Z shape, 6-4 piece S shape, 7-4 piece I shape
#8-5 piece T shape, 9-5 piece b shape, 10-5 piece d shape, 11-5 piece L shape, 12-5 piece J shape, 13-5 piece I piece
#14-vertical lightning powerup, 15-5x5 bomb powerup, 16-3x9 nuke powerup
#anti-clockwise
#[Y,X]

blockColour = ["#FF9900", "#0022FF", "#FF00EC", "#00E6FF", "#FFEC00", "#86FF00", "#FF0000", "#610034", "#00734D", "#2E6000", "#2A00B8", "#5200A5", "#660000",
               "black", "black", "black"]
#colour of each piece type
filledBlocks = []

def newPiece():
    global Xpiece
    global Ypiece
    global startPiece
    global rotationPositionNumber
    global pieceBlocks
    global rotationNumber
    global blockColour
    print("hi")
    Xpiece = 0 #the piece's horizontal distance moved 
    Ypiece = 0 #the piece's vertical distance moved
    startPiece = random.randint(0,15) #type of piece
    rotationPositionNumber = 0
    pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
    rotationNumber = len(rotationPosition[startPiece])
    for i in range(0,pieceBlocks):
        frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
        frame.grid(column = rotationPosition[startPiece][0][i][1], row = rotationPosition[startPiece][0][i][0])
    
def left(event):
    global Xpiece
    global Ypiece
    global movePiece
    global rotationPositionNumber
    global pieceBlocks
    testXpiece = Xpiece - 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece < 1:
            pieceInGrid = False
    for i in range(0,len(filledBlocks)):
        if filledBlocks[i] == [rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece]:
            print("hi")
    if pieceInGrid == True:
        Xpiece = Xpiece - 1
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, bg = 'black')
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece + 1, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)

def right(event):
    global Xpiece
    global Ypiece
    global movePiece
    global rotationPositionNumber
    global pieceBlocks
    testXpiece = Xpiece + 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece > 15:
            pieceInGrid = False
    if pieceInGrid == True:
        Xpiece = Xpiece + 1
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, bg = 'black')
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece - 1, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)

def up(event):
    global rotationPositionNumber
    global Xpiece
    global Ypiece
    global pieceBlocks
    global rotationNumber
    pieceInGrid = True
    testRotationPositionNumber = rotationPositionNumber
    testRotationPositionNumber = testRotationPositionNumber + 1
    if testRotationPositionNumber == rotationNumber:
        testRotationPositionNumber = 0
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece > 15:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece < 1:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece > 32:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece < 3:
            pieceInGrid = False
    if pieceInGrid == True:
        for j in range(1,15):
                if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1 > 2:
                    frame = Frame(top, height = 20, width = 20, bg = 'black')
                frame.grid(column = j, row = rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1)
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, bg = 'black')
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
        rotationPositionNumber = rotationPositionNumber + 1
        if rotationPositionNumber == rotationNumber:
            rotationPositionNumber = 0
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
            
def downPress(event):
    global gameDown
    global pressDown
    global pressOnce
    global drop
    global userDown
    global runGravity
    pressDown = True
    checkGravity()
    
def downRelease(event):
    global gameDown
    global pressDown
    global pressOnce
    pressDown = False
    checkGravity()
    
def shift(event):
    print(time.time() - dropTimer)

def checkGravity():
    global pressDown
    global drop
    global speed
    global checkGravityActive
    global downTimer
    if checkGravityActive == False:
        if pressDown == True:
            drop = 0.05
            speed = 0.04
            downTimer.cancel()
            checkGravityActive = True
            gravity()
    if pressDown == False:
        drop = 1
        speed = 0.8
        downTimer.cancel()
        checkGravityActive = True
        gravity()
    
def gravity():
    global Ypiece
    global dropTimer
    global movePiece
    global gameDown
    global userDown
    global pressDown
    global pressOnce
    global drop
    global runGravity
    global downTimer
    global speed
    global checkGravityActive
    global rotationPositionNumber
    global pieceBlocks
    start = time.time()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()
    movePiece = True
    testYpiece = Ypiece + 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece > 32:
            pieceInGrid = False
    if pieceInGrid == True:
        Ypiece = Ypiece + 1
        for j in range(1,15):
            if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1 > 2:
                frame = Frame(top, height = 20, width = 20, bg = 'black')
            frame.grid(column = j, row = rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1)
        for i in range(0,pieceBlocks):
            if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1 > 2:
                frame = Frame(top, height = 20, width = 20, bg = 'black')
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece - 1)
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
    else:
        for i in range(0,pieceBlocks):
            filledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece])
        newPiece()
    dropTimer = time.time()
    movePiece = False
    checkGravityActive = False
    print(filledBlocks)

newPiece()
checkGravityActive = False
pressDown = False
dropTimer = time.time()
drop = 1
speed = 0.9
gravity()
top.bind("<Shift_L>", shift)
top.bind("<Shift_R>", gravity)
top.bind("<Left>", left)
top.bind("<Right>", right)
top.bind("<KeyRelease-Up>", up)
top.bind("<KeyPress-Down>", downPress)
top.bind("<KeyRelease-Down>", downRelease)
         
top.mainloop()

