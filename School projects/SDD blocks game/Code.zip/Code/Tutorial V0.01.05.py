from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
top = Tk()
top.geometry("740x800")
top.configure(bg = '#068C83')


#setup grid and lists
for i in range(1,16):
    for j in range(3,33):
        frame = Frame(top, height = 20, width = 20, bg = 'black')
        frame.grid(column = i, row = j)#setup the grid

levelFrame = Frame(top, height = 50, width = 800, bg = '#9FEA7F')
levelFrame.place(x = 0, y = 0)#the title box

frame = Frame(top, height = 50, width = 20, bg = '#9FEA7F')
frame.grid(column = 0, row = 0, padx=100)

frame = Frame(top, height = 30, width = 20, bg = '#068C83')
frame.grid(column = 0, row = 1, padx=100)

frame = Frame(top, height = 40, width = 20, bg = '#068C83')
frame.grid(column = 0, row = 2, padx=100)#3 placeholder frames (for making the grid system work) that are the same colour as the background image so users won't know the frames are there

requiredScoreFrame = Frame(top, height = 100, width = 150, bg = 'black')
requiredScoreFrame.place(x = 60, y = 120)

nextPieceFrame = Frame(top, height = 100, width = 150, bg = 'black')
nextPieceFrame.place(x = 60, y = 230)

swapPieceFrame = Frame(top, height = 100, width = 150, bg = 'black')
swapPieceFrame.place(x = 60, y = 340)

fiveBlockFrame = Frame(top, height = 270, width = 150, bg = 'black')
fiveBlockFrame.place(x = 60, y = 450)

requiredLinesFrame = Frame(top, height = 100, width = 150, bg = 'black')
requiredLinesFrame.place(x = 530, y = 120)

scoreFrame = Frame(top, height = 100, width = 150, bg = 'black')
scoreFrame.place(x = 530, y = 230)

lineClearsFrame = Frame(top, height = 100, width = 150, bg = 'black')
lineClearsFrame.place(x = 530, y = 340)

fourBlockFrame = Frame(top, height = 270, width = 150, bg = 'black')
fourBlockFrame.place(x = 530, y = 450)

timeFrame = Frame(top, height = 40, width = 300, bg = 'white')
timeFrame.place(x = 220, y = 80)

exitFrame = Frame(top, height = 40, width = 80, bg = 'white')
exitFrame.place(x = 60, y = 740)

level = Label(levelFrame, text = "TUTORIAL", fg = 'black', bg = '#9FEA7F', font = ('Algerian','30'))
level.place(x = 400, y = 24, anchor = CENTER)

#requiredScore = Label(requiredScoreFrame, text = "Required \n Score \n 010000", fg = 'white', bg = 'black', font = ('calibri','20'))
#requiredScore.place(x = 75, y = 45, anchor = CENTER)

#nextPiece = Label(nextPieceFrame, text = "Next", fg = 'white', bg = 'black', font = ('calibri','20'))
#nextPiece.place(x = 75, y = 10, anchor = CENTER)

#swapPiece = Label(swapPieceFrame, text = "Swap", fg = 'white', bg = 'black', font = ('calibri','20'))
#swapPiece.place(x = 75, y = 10, anchor = CENTER)

#fiveBlocks = Label(fiveBlockFrame, text = "5 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
#fiveBlocks.place(x = 75, y = 10, anchor = CENTER)

#requiredLines = Label(requiredLinesFrame, text = "Required \n Lines \n 000", fg = 'white', bg = 'black', font = ('calibri','20'))
#requiredLines.place(x = 75, y = 45, anchor = CENTER)

#score = Label(scoreFrame, text = "Score", fg = 'white', bg = 'black', font = ('calibri','20'))
#score.place(x = 75, y = 10, anchor = CENTER)

#scoreNumber = Label(scoreFrame, text = "000000", fg = 'white', bg = 'black', font = ('calibri','20'))
#scoreNumber.place(x = 75, y = 50, anchor = CENTER)

#lineClears = Label(lineClearsFrame, text = "Line Clears", fg = 'white', bg = 'black', font = ('calibri','20'))
#lineClears.place(x = 75, y = 10, anchor = CENTER)

#lineClearsNumber = Label(lineClearsFrame, text = "000", fg = 'white', bg = 'black', font = ('calibri','20'))
#lineClearsNumber.place(x = 75, y = 50, anchor = CENTER)

#fourBlock = Label(fourBlockFrame, text = "4 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
#fourBlock.place(x = 75, y = 10, anchor = CENTER)

#timeLabel = Label(timeFrame, text = "Time: 15:00", fg = 'black', bg = 'white', font = ('calibri','20'))
#timeLabel.place(x = 150, y = 10, anchor = CENTER)

Exit = Label(exitFrame, text = "Exit", fg = 'black', bg = 'white', font = ('calibri','20'))
Exit.place(x = 40, y = 10, anchor = CENTER)

tutorialFrame = Frame(top, height = 200, width = 200, bg = '#EFF077')
tutorialFrame.place(x = 370, y = 400, anchor = CENTER)#the title box


rotationPosition = [[[[3,8], [3,9], [4,8], [4,9]]], [[[3,7], [3,8], [3,9], [4,7]], [[2,8], [3,8], [4,8], [4,9]], [[2,9], [3,7], [3,8], [3,9]],
                    [[2,7], [2,8], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,9]], [[2,8], [2,9], [3,8], [4,8]], [[2,7], [3,7], [3,8], [3,9]],
                    [[2,8], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [4,8]], [[2,8], [3,8], [3,9], [4,8]], [[2,8], [3,7], [3,8], [3,9]],
                    [[2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [4,8], [4,9]], [[2,9], [3,8], [3,9], [4,8]]], [[[3,8], [3,9], [4,7], [4,8]],
                    [[2,7], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [3,10]], [[1,9], [2,9], [3,9], [4,9]]], [[[3,7], [3,8], [3,9], [4,8], [5,8]],
                    [[2,8], [3,8], [3,9], [3,10], [4,8]], [[1,8], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,6], [3,7], [3,8], [4,8]]],
                    [[[3,7], [3,8], [3,9], [4,7], [4,8]], [[2,8], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,7], [3,8], [3,9]],
                    [[2,7], [2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,8], [3,9], [4,8]],
                    [[2,7], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,7], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [3,10], [4,7]],
                    [[1,9], [2,9], [3,9], [4,9], [4,10]], [[2,10], [3,7], [3,8], [3,9], [3,10]], [[1,8], [1,9], [2,9], [3,9], [4,9]]],
                    [[[3,7], [3,8], [3,9], [3,10], [4,10]], [[1,9], [1,10], [2,9], [3,9], [4,9]], [[2,7], [3,7], [3,8], [3,9], [3,10]],
                    [[1,9], [2,9], [3,9], [4,8], [4,9]]], [[[3,6], [3,7], [3,8], [3,9], [3,10]], [[1,8], [2,8], [3,8], [4,8], [5,8]]], [[[3,8]]], [[[3,8]]],
                    [[[3,8]]]]
#spawns right to left then up to down
#1-4 piece O shape, 2-4 piece L shape, 3-4 piece J shape, 4-4 piece T shape, 5-4 piece Z shape, 6-4 piece S shape, 7-4 piece I shape
#8-5 piece T shape, 9-5 piece b shape, 10-5 piece d shape, 11-5 piece L shape, 12-5 piece J shape, 13-5 piece I piece
#14-vertical lightning powerup, 15-5x5 bomb powerup, 16-3x9 nuke powerup
#anti-clockwise
#[Y,X]

blockColour = ["#FF9900", "#0022FF", "#FF00EC", "#00E6FF", "#FFEC00", "#86FF00", "#FF0000", "#610034", "#00734D", "#2E6000", "#2A00B8", "#5200A5", "#660000",
               "LIGHTNING.png", "BOMB.png", "NUKE.png"]
#colour of each piece type
Xlength = [0,1,1,1,1,1,0,1,1,1,0,0,1,1,1,1]
filledBlocks = []
newFilledBlocks = []
testFilledBlocks = []
filledBlocksVerticalLinesList = []
filledBlocksHorizontalLinesList = []
lineClearList = []
activeFrameList = []
stableFrameList = []
newPieceList = []
nextPieceFrameList = []
swapPieceList = [[],[]]
swapPieceBlocksList = []
statsPiece = [["OPiece",0],["LPiece",0],["JPiece",0],["TPiece",0],["ZPiece",0],["SPiece",0],["IPiece",0],["5TPiece",0],["5BPiece",0],["5DPiece",0],["5LPiece",0],["5JPiece",0],["5IPiece",0]]
for i in range(0,33):
    filledBlocksVerticalLinesList.append([])
for i in range(0,15):
    filledBlocksHorizontalLinesList.append([])

def addStats():
    for j in range(0,7):
        for i in range(0,4):
            frame = Frame(top, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
            frame.place(x = 560 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 33 * j, anchor = E)
    for j in range(7,13):
        for i in range(0,5):
            frame = Frame(top, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
            frame.place(x = 100 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 40 * (j - 7), anchor = E)
    for i in range(0,7):
        statsPiece[i][0] = Label(top, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
        statsPiece[i][0].place(x = 650, y = 500 + 33 * i, anchor = CENTER)
    for i in range(7,13):
        statsPiece[i][0] = Label(top, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
        statsPiece[i][0].place(x = 180, y = 500 + 40 * (i - 7), anchor = CENTER)


#tutorial
def Tutorial():
    global tutorialFrame
    global setTutorial
    global tutorialTitle
    global tutorialText
    global swapPieceText
    global Xpiece
    global Ypiece
    global startPiece
    global rotationPositionNumber
    global pieceBlocks
    global rotationNumber
    global blockColour
    global swapPieceOnce
    if setTutorial == 0:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','25'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "Welcome to the \n tutorial", fg = 'black', bg = '#EFF077', font = ('calibri','20'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 1:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "You will be controlling a main \n piece with your keyboard", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        Xpiece = 0 #the piece's horizontal distance moved 
        Ypiece = 0 #the piece's vertical distance moved
        startPiece = random.randint(0,12)
        newPieceList.append(startPiece)
        newPieceList.pop(0)
        startPiece = newPieceList[0]
        rotationPositionNumber = 0
        pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
        rotationNumber = len(rotationPosition[startPiece])
        blockImage()
        statsPiece[startPiece][1] = statsPiece[startPiece][1] + 1
    if setTutorial == 2:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "The piece must always be \n inside the grid", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 3:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "To move the piece left, press \n or hold the left arrow key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 4:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "To move the piece right, \n press or hold the right arrow \n key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 5:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "To rotate the piece \n anti-clockwise, press and \n release the up arrow key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 6:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "The piece will slowly drop \n at a set level speed if the \n down arrow key isn't held", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 7:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "The piece will drop at the soft \n drop speed when the down \n key is held", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 8:
        print("yes")
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "You can press the left shift key to swap a \n piece if you had not swapped \n a piece since the piece has \n been spawned", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        swapPieceText = Label(swapPieceFrame, text = "Swap", fg = 'white', bg = 'black', font = ('calibri','20'))
        swapPieceText.place(x = 75, y = 10, anchor = CENTER)
    if setTutorial == 9:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if the block below the piece is a stable piece or out of the grid, the piece becomes a stable piece and you can't control it anymore", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 10:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if the block below the piece is a stable piece or out of the grid, the piece becomes a stable piece and you can't control it anymore", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 11:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if a new stable piece is created, the piece in the next piece box will be added to the grid and a randomly generated piece will replace the piece in the next piece box", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        nextPiece = Label(nextPieceFrame, text = "Next", fg = 'white', bg = 'black', font = ('calibri','20'))
        nextPiece.place(x = 75, y = 10, anchor = CENTER)
    if setTutorial == 12:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "everytime a new piece is added, it will be added to the piece stats box", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        fiveBlocks = Label(fiveBlockFrame, text = "5 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
        fiveBlocks.place(x = 75, y = 10, anchor = CENTER)
        fourBlock = Label(fourBlockFrame, text = "4 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
        fourBlock.place(x = 75, y = 10, anchor = CENTER)
        addStats()
    if setTutorial == 13:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "The two types of pieces are normal pieces and powerups", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 14:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "normal pieces are more common than powerups and they consists of either 4 or 5 blocks", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 15:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "normal pieces consists of either 4 or 5 blocks and they all have the same colour", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 16:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "powerups only consist of one block but they have an image", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 17:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "the lightning bolt powerup destroys every block in its column", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 18:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "the bomb powerup destroys every block in a 5x5 area with the powerup being the center", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 19:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "the nuke powerup destroys every block in the row above to the row below", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 20:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "to gain score, you can perform line clears or use powerups", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        score = Label(scoreFrame, text = "Score", fg = 'white', bg = 'black', font = ('calibri','20'))
        score.place(x = 75, y = 10, anchor = CENTER)
    if setTutorial == 21:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "when a row is fully filled with stable pieces, the whole row will disappear and all the blocks above the row will drop down the number of rows that have been cleared", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        lineClears = Label(lineClearsFrame, text = "Line Clears", fg = 'white', bg = 'black', font = ('calibri','20'))
        lineClears.place(x = 75, y = 10, anchor = CENTER)
    if setTutorial == 22:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "line clear score system: \n 1 line clear = 200 \n 2 line clear = 500 \n 3 line clear = 1000 \n 4 line clear = 3000 \n 5 line clear = 5000", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 23:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "lightning bolt powerup score system: \n 0-4 blocks = 50 x blocks destroyed \n 5-9 blocks = 100 x blocks destroyed \n 10-19 blocks = 200 x blocks destroyed \n 20-28 blocks = 300 x blocks destroyed \n 29 blocks = 15000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 24:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "bomb powerup score system: \n 0-10 blocks = 25 x blocks destroyed \n 11-14 blocks = 50 x blocks destroyed \n 15-21 blocks = 100 x blocks destroyed \n 22 blocks = 4000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 25:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "nuke powerup score system: \n 0-20 blocks = 25 x blocks destroyed \n 21-30 blocks = 50 x blocks destroyed \n 31-41 blocks = 100 x blocks destroyed \n 42 blocks = 7000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 26:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if the level timer hits 0, you lose the level/game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        timeLabel = Label(timeFrame, text = "Time: 15:00", fg = 'black', bg = 'white', font = ('calibri','20'))
        timeLabel.place(x = 150, y = 10, anchor = CENTER)
    if setTutorial == 27:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if the new piece spawns inside a stable piece, you also lose the game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 28:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if you have reached the required score and lines before you have lost the game, you beat the level/game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        requiredScore = Label(requiredScoreFrame, text = "Required \n Score \n 010000", fg = 'white', bg = 'black', font = ('calibri','20'))
        requiredScore.place(x = 75, y = 45, anchor = CENTER)
        requiredLines = Label(requiredLinesFrame, text = "Required \n Lines \n 000", fg = 'white', bg = 'black', font = ('calibri','20'))
        requiredLines.place(x = 75, y = 45, anchor = CENTER)
    if setTutorial == 29:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "you have finished the tutorial", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    
    #swapPiece, nextPiece, Stats, normalPiece, Powerups, scoreSystem, lineClears, Timer, loseCondition, winCondition

def tutorialImage():
    tutorialImage = Image.open("Next button.png")
    tutorialImage = tutorialImage.resize((40,40), Image.LANCZOS)
    tutorialImage = ImageTk.PhotoImage(tutorialImage)
    tutorialImage_label= Label(image=tutorialImage)
    tutorialImage_label.image = tutorialImage
    frameImage = Button(tutorialFrame, height = 40, width = 40, relief = "flat", image=tutorialImage, bg = '#EFF077', command = nextButton)
    frameImage.place(x = 170, y = 170, anchor = CENTER)
    tutorialImage = Image.open("Back button.png")
    tutorialImage = tutorialImage.resize((45,45), Image.LANCZOS)
    tutorialImage = ImageTk.PhotoImage(tutorialImage)
    tutorialImage_label= Label(image=tutorialImage)
    tutorialImage_label.image = tutorialImage
    frameImage = Button(tutorialFrame, height = 40, width = 40, relief = "flat", image=tutorialImage, bg = '#EFF077', command = backButton)
    frameImage.place(x = 30, y = 170, anchor = CENTER)

def nextButton():
    global setTutorial
    global tutorialTitle
    global tutorialText
    setTutorial = setTutorial + 1
    tutorialTitle.destroy()
    tutorialText.destroy()
    Tutorial()
    print(setTutorial)

def backButton():
    global setTutorial
    global tutorialTitle
    global tutorialText
    global swapPieceText
    global Xpiece
    global Ypiece
    global startPiece
    global rotationPositionNumber
    global pieceBlocks
    global rotationNumber
    global blockColour
    global swapPieceOnce
    if setTutorial == 0:
        print("hi")
    else:
        setTutorial = setTutorial - 1
        if setTutorial == 0 or setTutorial == 1:
            deleteActiveFrames()
        if setTutorial == 7 or setTutorial == 8:
            print("ok")
            swapPieceText.destroy()
    print("number",setTutorial)
    tutorialTitle.destroy()
    tutorialText.destroy()
    Tutorial()


#setup/add info boxes/objects
def Time():#display/update the time left to complete the level
    global minutes
    global seconds
    global gameover
    if gameover == False:
        if minutes == 0 and seconds == 0:
            print("gameover")
            gameover = True
        else:
            if seconds == 0:
                minutes = minutes - 1
                seconds = 59
            else:
                seconds = seconds - 1
            if seconds < 10:
                secondsText = "0" + str(seconds)
            else:
                secondsText = str(seconds)
            timeLabel.config(text = "Time: " + str(minutes) + ":" + secondsText)
            timeLabel.after(1000,Time)


def lineClear():#display/update the number of lines cleared
    global lineClearNumber
    global lineClearList
    lineClearNumber = lineClearNumber + len(lineClearList)
    if lineClearNumber < 100:
        if lineClearNumber < 10:
            lineClearsNumber.config(text = "00" + str(lineClearNumber))
        else:
            lineClearsNumber.config(text = "0" + str(lineClearNumber))
    else:
        lineClearsNumber.config(text = lineClearNumber)


def displayScore():#display/update the total score
    global scoreNumbers
    if scoreNumbers < 100000:
        if scoreNumbers < 10000:
            if scoreNumbers < 1000:
                if scoreNumbers < 100:
                    if scoreNumbers < 10:
                        scoreNumber.config(text = "00000" + str(scoreNumbers))
                    else:
                        scoreNumber.config(text = "0000" + str(scoreNumbers))
                else:
                    scoreNumber.config(text = "000" + str(scoreNumbers))
            else:
                scoreNumber.config(text = "00" + str(scoreNumbers))
        else:
            scoreNumber.config(text = "0" + str(scoreNumbers))
    else:
        scoreNumber.config(text = scoreNumbers)

def lineClearScore():#formula for calculating how much score is added each time line clear/clears are performed
    global scoreNumbers
    global lineClearList
    if len(lineClearList) == 1:
        scoreNumbers = scoreNumbers + 200
    if len(lineClearList) == 2:
        scoreNumbers = scoreNumbers + 500
    if len(lineClearList) == 3:
        scoreNumbers = scoreNumbers + 1000
    if len(lineClearList) == 4:
        scoreNumbers = scoreNumbers + 3000
    if len(lineClearList) == 5:
        scoreNumbers = scoreNumbers + 5000
    displayScore()

def lightningPowerUpScore():#formula for calculating how much score is added each time the lightning power up (the block with the lightning bolt image) is used
    global scoreNumbers
    global blocksDestroyed
    if blocksDestroyed < 5:
        scoreNumbers = scoreNumbers + 50 * blocksDestroyed
    if blocksDestroyed < 10 and blocksDestroyed > 4:
        scoreNumbers = scoreNumbers + 100 * blocksDestroyed
    if blocksDestroyed < 20 and blocksDestroyed > 9:
        scoreNumbers = scoreNumbers + 200 * blocksDestroyed
    if blocksDestroyed < 29 and blocksDestroyed > 19:
        scoreNumbers = scoreNumbers + 300 * blocksDestroyed
    if blocksDestroyed == 29:
        scoreNumbers = scoreNumbers + 15000
    displayScore()

def bombPowerUpScore():#formula for calculating how much score is added each time the bomb power up (the block with the bomb image) is used
    global scoreNumbers
    global blocksDestroyed
    if blocksDestroyed < 11:
        scoreNumbers = scoreNumbers + 25 * blocksDestroyed
    if blocksDestroyed < 15 and blocksDestroyed > 10:
        scoreNumbers = scoreNumbers + 50 * blocksDestroyed
    if blocksDestroyed < 22 and blocksDestroyed > 14:
        scoreNumbers = scoreNumbers + 100 * blocksDestroyed
    if blocksDestroyed == 22:
        scoreNumbers = scoreNumbers + 4000
    displayScore()

def nukePowerUpScore():#formula for calculating how much score is added each time the nuke power up (the block with the nuke cloud image) is used
    global scoreNumbers
    global blocksDestroyed
    if blocksDestroyed < 21:
        scoreNumbers = scoreNumbers + 25 * blocksDestroyed
    if blocksDestroyed < 31 and blocksDestroyed > 20:
        scoreNumbers = scoreNumbers + 50 * blocksDestroyed
    if blocksDestroyed < 42 and blocksDestroyed > 30:
        scoreNumbers = scoreNumbers + 100 * blocksDestroyed
    if blocksDestroyed == 42:
        scoreNumbers = scoreNumbers + 7000
    displayScore()


def stats():#display/update the piece statistics
    if startPiece < 13:
        statsPiece[startPiece][1] = statsPiece[startPiece][1] + 1
        for i in range(0,7):
            statsPiece[i][0] = Label(top, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
            statsPiece[i][0].place(x = 650, y = 500 + 33 * i, anchor = CENTER)
        for i in range(7,13):
            statsPiece[i][0] = Label(top, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
            statsPiece[i][0].place(x = 180, y = 500 + 40 * (i - 7), anchor = CENTER)

def newPiece():#adds/spawns a new piece
    global Xpiece
    global Ypiece
    global startPiece
    global rotationPositionNumber
    global pieceBlocks
    global rotationNumber
    global blockColour
    global swapPieceOnce
    global downTimer
    downTimer.cancel()
    Xpiece = 0 #the piece's horizontal distance moved 
    Ypiece = 0 #the piece's vertical distance moved
    if press == False:
        startPiece = random.randint(0,15) #type of piece:
    else:
        startPiece = random.randint(13,15)
    newPieceList.append(startPiece)
    newPieceList.pop(0)
    startPiece = newPieceList[0]
    rotationPositionNumber = 0
    pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
    rotationNumber = len(rotationPosition[startPiece])
    blockImage()
    stats()
    deleteNextPiece()
    updateNextPiece()
    if swapPieceOnce == True:
        swapPieceOnce = False
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()

def deleteNextPiece():#deletes the image in the next piece box
    for i in range(0,newPieceBlocks):
        nextPieceFrameList[0].destroy()
        nextPieceFrameList.pop(0)

def updateNextPiece():#adds/updates the image in the next piece box
    global newStartPiece
    global newPieceBlocks
    newStartPiece = newPieceList[1]
    newPieceBlocks = len(rotationPosition[newStartPiece][0])
    if newStartPiece < 13:
        if Xlength[newStartPiece] == 0:
            for i in range(0,newPieceBlocks):
                frame = Frame(nextPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[newStartPiece])
                frame.place(x = 75 + (rotationPosition[newStartPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[newStartPiece][0][i][0] - 3) * 20, anchor = E)
                nextPieceFrameList.append(frame)
        else:
            for i in range(0,newPieceBlocks):
                frame = Frame(nextPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[newStartPiece])
                frame.place(x = 85 + (rotationPosition[newStartPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[newStartPiece][0][i][0] - 3) * 20, anchor = E)
                nextPieceFrameList.append(frame)
    if newStartPiece > 12:
        powerUpImage = Image.open(blockColour[newStartPiece])
        powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
        powerUpImage = ImageTk.PhotoImage(powerUpImage)
        powerUpImage_label= Label(image=powerUpImage)
        powerUpImage_label.image = powerUpImage
        frameImage = Label(nextPieceFrame, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
        frameImage.place(x = 85, y = 40, anchor = E)
        nextPieceFrameList.append(frameImage)

def addSwapPiece():#adds/updates the image in the swap piece box
    if startPiece < 13:
        if Xlength[startPiece] == 0:
            for i in range(0,pieceBlocks):
                frame = Frame(swapPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                frame.place(x = 75 + (rotationPosition[startPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[startPiece][0][i][0] - 3) * 20, anchor = E)
                swapPieceBlocksList.append(frame)
        else:
            for i in range(0,pieceBlocks):
                frame = Frame(swapPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                frame.place(x = 85 + (rotationPosition[startPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[startPiece][0][i][0] - 3) * 20, anchor = E)
                swapPieceBlocksList.append(frame)
    if startPiece > 12:
        powerUpImage = Image.open(blockColour[startPiece])
        powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
        powerUpImage = ImageTk.PhotoImage(powerUpImage)
        powerUpImage_label= Label(image=powerUpImage)
        powerUpImage_label.image = powerUpImage
        frameImage = Label(swapPieceFrame, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
        frameImage.place(x = 85, y = 40, anchor = E)
        swapPieceBlocksList.append(frameImage)


#game code
def checkGravity():#set how fast the piece will drop (either normal level speed or the soft drop speed)
    global pressDown
    global drop
    global speed
    global checkGravityActive
    global downTimer
    if checkGravityActive == False:
        if pressDown == True:
            drop = 0.05
            speed = 0.04
            downTimer.cancel()
            checkGravityActive = True
            gravity()
    if pressDown == False:
        drop = 1
        speed = 0.8
        downTimer.cancel()
        checkGravityActive = True
        gravity()
    
def gravity():#drop the piece
    global Ypiece
    global dropTimer
    global gameDown
    global userDown
    global pressDown
    global pressOnce
    global drop
    global runGravity
    global downTimer
    global speed
    global checkGravityActive
    global rotationPositionNumber
    global pieceBlocks
    global testFilledBlocks
    global leftActive
    global rightActive
    global rotationActive
    global gravityActive
    global swapActive
    global moveGravity
    global gameover
    if gameover == False:
        start = time.time()
        downTimer = threading.Timer(drop, checkGravity)
        downTimer.start()
        if time.time() - dropTimer > speed:
            testYpiece = Ypiece + 1
            pieceInGrid = True
            for i in range(0,pieceBlocks):
                if rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece > 32:
                    pieceInGrid = False
            for j in range(0,len(filledBlocks)):
                for i in range(0,pieceBlocks):
                    if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece:
                        if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece:
                            pieceInGrid = False
            if pieceInGrid == True:
                moveGravity = True
                gravityActive = True
                Ypiece = Ypiece + 1
                blockImage()
                gravityActive = False
                moveGravity = False
            else:
                checkPieceType = True
                if startPiece < 13:
                    polyomino()
                    checkPieceType = False
                if checkPieceType == True:
                    if startPiece == 13:
                        lightningPowerUp()
                        checkPieceType = False
                if checkPieceType == True:
                    if startPiece == 14:
                        bombPowerUp()
                        checkPieceType = False
                if checkPieceType == True:
                    if startPiece == 15:
                        nukePowerUp()
                        checkPieceType = False
            dropTimer = time.time()
        checkGravityActive = False

def polyomino():#code for normal pieces when they can't drop anymore
    global pieceInGrid
    global moveGravity
    global leftActive
    global rightActive
    global rotationActive
    global gravityActive
    global Ypiece
    global pieceBlocks
    global activeFrameList
    global filledBlocks
    global testFilledBlocks
    global stableFrameList
    global activeFrameList
    global downTimer
    global dropTimer
    global deleteActiveFrameList
    global polyominoActive
    if deleteActiveFrameList == False:
        polyominoActive = True
        deleteActiveFrameList = True
        moveGravity = True
        gravityActive = True
        downTimer.cancel()
        for i in range(0,pieceBlocks):
            filledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece,blockColour[startPiece],activeFrameList[-1]])
            testFilledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece,blockColour[startPiece],activeFrameList[-1]])
            stableFrameList.append(activeFrameList[-1])
            activeFrameList.pop(-1)
        polyominoActive = False
        deleteActiveFrames()
        sortFilledBlocks()
        checkLineClear()
        downTimer = threading.Timer(drop, checkGravity)
        downTimer.start()
        newPiece()
        gravityActive = False
        moveGravity = False
        deleteActiveFrameList = False

def lightningPowerUp():#code for lightning power up when they can't drop anymore
    global filledBlocks
    global testFilledBlocks
    global filledBlocksHorizontalLinesList
    global filledBlocksVerticalLinesList
    global stableFrameList
    global downTimer
    global blocksDestroyed
    global deleteActiveFrameList
    downTimer.cancel()
    deleteActiveFrames()
    blocksDestroyed = 0
    for i in range(0,len(filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1])):
        filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1][i][3].destroy()
        blocksDestroyed = blocksDestroyed + 1
    filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1] = []
    for i in range(0,len(stableFrameList)):
        stableFrameList[0].destroy()
        stableFrameList.pop(0)
    for i in range(0,15):
        for j in range(0,len(filledBlocksHorizontalLinesList[i])):
            testFilledBlocks.append(filledBlocksHorizontalLinesList[i][j])
    filledBlocksVerticalLinesList = []
    filledBlocksHorizontalLinesList = []
    for i in range(0,33):
        filledBlocksVerticalLinesList.append([])
    for i in range(0,15):
        filledBlocksHorizontalLinesList.append([])
    filledBlocks = []
    for i in range(0,len(testFilledBlocks)):
        filledBlocks.append(testFilledBlocks[i])
    lineClearImage()
    sortFilledBlocks()
    lightningPowerUpScore()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()
    newPiece()

def bombPowerUp():#code for bomb power up when they can't drop anymore
    global filledBlocks
    global testFilledBlocks
    global filledBlocksHorizontalLinesList
    global filledBlocksVerticalLinesList
    global stableFrameList
    global downTimer
    global newFilledBlocks
    global blocksDestroyed
    global deleteActiveFrameList
    downTimer.cancel()
    deleteActiveFrames()
    blocksDestroyed = 0
    for j in range(-2,3):
        for i in range(0,len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j])):
            if filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][1] > rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 3 and filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][1] < rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece + 3:
                filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][3].destroy()
                filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i] = []
                blocksDestroyed = blocksDestroyed + 1
    for i in range(0,len(stableFrameList)):
        stableFrameList[0].destroy()
        stableFrameList.pop(0)
    for i in range(0,30):
        for j in range(0,len(filledBlocksVerticalLinesList[i])):
            if filledBlocksVerticalLinesList[i][j] != []:
                testFilledBlocks.append(filledBlocksVerticalLinesList[i][j])
    filledBlocks = []
    for i in range(0,len(testFilledBlocks)):
        filledBlocks.append(testFilledBlocks[i])
    testFilledBlocks = []
    for k in range(0,len(filledBlocks)):
        if filledBlocks[k][0] < rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 2 and filledBlocks[k][1] > rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 3 and filledBlocks[k][1] < rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece + 3:
            if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece + 2 <= 32:
                newFilledBlocks.append([filledBlocks[k][0] + 5,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
            else:
                newFilledBlocks.append([filledBlocks[k][0] + 32 - (rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3),filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
        else:
            newFilledBlocks.append(filledBlocks[k])
    filledBlocks = newFilledBlocks
    newFilledBlocks = []
    lineClearImage()
    for i in range(0,len(filledBlocks)):
        testFilledBlocks.append(filledBlocks[i])
    filledBlocksVerticalLinesList = []
    filledBlocksHorizontalLinesList = []
    for i in range(0,33):
        filledBlocksVerticalLinesList.append([])
    for i in range(0,15):
        filledBlocksHorizontalLinesList.append([])
    sortFilledBlocks()
    bombPowerUpScore()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()
    newPiece()

def nukePowerUp():#code for nuke power up when they can't drop anymore
    global filledBlocks
    global testFilledBlocks
    global filledBlocksHorizontalLinesList
    global filledBlocksVerticalLinesList
    global stableFrameList
    global downTimer
    global newFilledBlocks
    global blocksDestroyed
    global deleteActiveFrameList
    downTimer.cancel()
    deleteActiveFrames()
    blocksDestroyed = 0
    for j in range(-1,2):
        for i in range(0,len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j])):
            filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][3].destroy()
            blocksDestroyed = blocksDestroyed + 1
        filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j] = []
    for i in range(0,len(stableFrameList)):
        stableFrameList[0].destroy()
        stableFrameList.pop(0)
    for i in range(0,30):
        for j in range(0,len(filledBlocksVerticalLinesList[i])):
            if filledBlocksVerticalLinesList[i][j] != []:
                testFilledBlocks.append(filledBlocksVerticalLinesList[i][j])
    filledBlocks = []
    for i in range(0,len(testFilledBlocks)):
        filledBlocks.append(testFilledBlocks[i])
    testFilledBlocks = []
    for k in range(0,len(filledBlocks)):
        if filledBlocks[k][0] < rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1:
            if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece + 1 <= 32:
                newFilledBlocks.append([filledBlocks[k][0] + 3,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
            else:
                newFilledBlocks.append([filledBlocks[k][0] + 32 - (rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 2),filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
        else:
            newFilledBlocks.append(filledBlocks[k])
    filledBlocks = newFilledBlocks
    newFilledBlocks = []
    lineClearImage()
    for i in range(0,len(filledBlocks)):
        testFilledBlocks.append(filledBlocks[i])
    filledBlocksVerticalLinesList = []
    filledBlocksHorizontalLinesList = []
    for i in range(0,33):
        filledBlocksVerticalLinesList.append([])
    for i in range(0,15):
        filledBlocksHorizontalLinesList.append([])
    sortFilledBlocks()
    nukePowerUpScore()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()
    newPiece()

def sortFilledBlocks():#adds the active blocks into the filled blocks horizontal and vertical lists when the active blocks can't drop anymore
    global filledBlocks
    global testFilledBlocks
    for i in range(0,len(testFilledBlocks)):
        filledBlocksVerticalLinesList[testFilledBlocks[i][0] - 3].append(testFilledBlocks[i])
        filledBlocksHorizontalLinesList[testFilledBlocks[i][1] - 1].append(testFilledBlocks[i])
    testFilledBlocks = []

def checkLineClear():#check if line clear/clears has been performed and if there is a line clear/clears, then perform a line clear/clears
    global filledBlocksVerticalLinesList
    global filledBlocksHorizontalLinesList
    global lineClearList
    global newFilledBlocks
    global filledBlocks
    global testFilledBlocks
    for i in range(0,30):
        if len(filledBlocksVerticalLinesList[i]) == 15:
            lineClearList.append(filledBlocksVerticalLinesList[i][0][0])
    if lineClearList != []:
        for i in range(0,len(filledBlocks)):
            stableFrameList[0].destroy()
            stableFrameList.pop(0)
    for i in range(0,len(lineClearList)):
        for k in range(0,len(filledBlocks)):
            if filledBlocks[k][0] > lineClearList[i]:
                newFilledBlocks.append(filledBlocks[k])
            if filledBlocks[k][0] < lineClearList[i]:
                newFilledBlocks.append([filledBlocks[k][0] + 1,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
        filledBlocks = newFilledBlocks
        newFilledBlocks = []
    if lineClearList != []:
        lineClear()
        lineClearScore()
        lineClearImage()
        for i in range(0,len(filledBlocks)):
            testFilledBlocks.append(filledBlocks[i])
        filledBlocksVerticalLinesList = []
        filledBlocksHorizontalLinesList = []
        for i in range(0,33):
            filledBlocksVerticalLinesList.append([])
        for i in range(0,15):
            filledBlocksHorizontalLinesList.append([])
        sortFilledBlocks()
    lineClearList = []

def deleteActiveFrames():
    global deleteActiveFrameList
    if deleteActiveFrameList == False:
        deleteActiveFrameList = True
        for i in range(0,len(activeFrameList)):
            activeFrameList[0].destroy()
            activeFrameList.pop(0)
        deleteActiveFrameList = False
def blockImage():#updates the image of the active piece
    global startPiece
    global pieceBlocks
    global activeFrameList
    global rotationPositionNumber
    global Xpiece
    global Ypiece
    global blockColour
    global powerUpImage
    global blockImageActive
    global deleteActiveFrameList
    if blockImageActive == False:
        blockImageActive = True
        if activeFrameList != []:
            deleteActiveFrames()
        print(activeFrameList)
        if startPiece < 13:
            for i in range(0,pieceBlocks):
                frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
                activeFrameList.append(frame)
        if startPiece > 12:
            powerUpImage = Image.open(blockColour[startPiece])
            powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
            powerUpImage = ImageTk.PhotoImage(powerUpImage)
            powerUpImage_label= Label(image=powerUpImage)
            powerUpImage_label.image = powerUpImage
            frameImage = Label(top, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
            frameImage.grid(column = rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece)
            activeFrameList.append(frameImage)
        print(Ypiece,activeFrameList)
        blockImageActive = False

def lineClearImage():#updates the image of all the stable pieces
    global startPiece
    global pieceBlocks
    global activeFrameList
    global rotationPositionNumber
    global Xpiece
    global Ypiece
    global blockColour
    global powerUpImage
    for i in range(0,len(filledBlocks)):
        frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = filledBlocks[i][2])
        frame.grid(column = filledBlocks[i][1], row = filledBlocks[i][0])
        stableFrameList.append(frame)


#controls
def left(event):#move piece to the left by 1
    global Xpiece
    global Ypiece
    global rotationPositionNumber
    global pieceBlocks
    global leftActive
    global rightActive
    testXpiece = Xpiece - 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece < 1:
            pieceInGrid = False
    for j in range(0,len(filledBlocks)):
        for i in range(0,pieceBlocks):
            if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece:
                if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece:
                    pieceInGrid = False
    if pieceInGrid == True:
            Xpiece = Xpiece - 1
            blockImage()

def right(event):#move piece to the right by 1
    global Xpiece
    global Ypiece
    global rotationPositionNumber
    global pieceBlocks
    global rightActive
    testXpiece = Xpiece + 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece > 15:
            pieceInGrid = False
    for j in range(0,len(filledBlocks)):
        for i in range(0,pieceBlocks):
            if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece:
                if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece:
                    pieceInGrid = False
    if pieceInGrid == True:
            Xpiece = Xpiece + 1
            blockImage()

def up(event):#rotate the piece to the next rotation position
    global rotationPositionNumber
    global Xpiece
    global Ypiece
    global pieceBlocks
    global rotationNumber
    global rotationActive
    global deleteActiveFrameList
    pieceInGrid = True
    testRotationPositionNumber = rotationPositionNumber
    testRotationPositionNumber = testRotationPositionNumber + 1
    if testRotationPositionNumber == rotationNumber:
        testRotationPositionNumber = 0
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece > 15:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece < 1:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece > 32:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece < 3:
            pieceInGrid = False
    for j in range(0,len(filledBlocks)):
        for i in range(0,pieceBlocks):
            if filledBlocks[j][0] == rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece:
                if filledBlocks[j][1] == rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece:
                    pieceInGrid = False
    if pieceInGrid == True and len(activeFrameList) == pieceBlocks:
            rotationActive = True
            deleteActiveFrames()
            rotationPositionNumber = rotationPositionNumber + 1
            if rotationPositionNumber == rotationNumber:
                rotationPositionNumber = 0
            blockImage()
            rotationActive = False

def downPress(event):#change the piece drop speed to the soft drop speed
    global gameDown
    global pressDown
    global pressOnce
    global drop
    global userDown
    global runGravity
    pressDown = True
    checkGravity()
    
def downRelease(event):#change the piece drop speed to the normal level speed
    global gameDown
    global pressDown
    global pressOnce
    pressDown = False
    checkGravity()

def swapPieces(event):#swap the current active piece with the piece in the swap piece box
    global swapPiece
    global swapPieceOnce
    global Xpiece
    global Ypiece
    global startPiece
    global rotationPositionNumber
    global pieceBlocks
    global rotationNumber
    global swapActive
    global checkPieceType
    global downTimer
    global deleteActiveFrameList
    if gravityActive == False and swapPieceOnce == False and checkPieceType == False:
        downTimer.cancel()
        swapActive = True
        if swapPiece == False:
            swapPieceList[0] = startPiece
            addSwapPiece()
            deleteActiveFrames()
            newPiece()
            swapPiece = True
        else:
            swapPieceList[1] = swapPieceList[0]
            swapPieceList[0] = startPiece
            for i in range(0,len(swapPieceBlocksList)):
                swapPieceBlocksList[0].destroy()
                swapPieceBlocksList.pop(0)
            addSwapPiece()
            deleteActiveFrames()
            Xpiece = 0 #the piece's horizontal distance moved 
            Ypiece = 0 #the piece's vertical distance moved
            startPiece = swapPieceList[1]
            rotationPositionNumber = 0
            pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
            rotationNumber = len(rotationPosition[startPiece])
            blockImage()
            checkLoseCondition()
        swapPieceOnce = True
        swapActive = False
        downTimer = threading.Timer(drop, checkGravity)
        downTimer.start()

#start/end functions
def Start():#initiate a countdown when the game begins
    global start
    global destroy
    global startNumber
    startNumber.destroy()
    start = start - 1
    if destroy == False:
        if start > 0:
            startNumber = Label(top, text = start, fg = 'white', bg = 'black', font = ('calibri','100'))
            startNumber.place(x = 370, y = 400, anchor = CENTER)
            top.after(1000,Start)
        else:
            startNumber = Label(top, text = "start", fg = 'white', bg = 'black', font = ('calibri','100'))
            startNumber.place(x = 370, y = 400, anchor = CENTER)
            destroy = True
            top.after(1000,Start)
    else:
        top.bind("<KeyPress-Down>", downPress)
        top.bind("<KeyRelease-Down>", downRelease)
        top.bind("<Shift_L>", swapPieces)

def End():#unbinds every control key when the game ends
    top.unbind("<Shift_L>")
    top.unbind("<Shift_R>")
    top.unbind("<Left>")
    top.unbind("<Right>")
    top.unbind("<KeyRelease-Up>")
    top.unbind("<KeyPress-Down>")
    top.unbind("<KeyRelease-Down>")

def shift1(event):
    global press
    if press == True:
        press = False
    else:
        press = True

#variable info + starting functions + adding objects
minutes = 15
seconds = 0
lineClearNumber = 0
scoreNumbers = 0
deleteActiveFrameList = False
polyominoActive = False
press = False
blockImageActive = False
leftActive = False
rightActive = False
rotationActive = False
gravityActive = False
swapActive = False
moveGravity = False
gameover = False
startPiece = random.randint(0,15)
newPieceList.append(startPiece)
drop = 6
speed = 0.9
swapPiece = False
swapPieceOnce = False
#updateNextPiece()
Xpiece = 0 #the piece's horizontal distance moved 
Ypiece = 0 #the piece's vertical distance moved
startPiece = random.randint(0,15) #type of piece:
newPieceList.append(startPiece)
newPieceList.pop(0)
startPiece = newPieceList[0]
rotationPositionNumber = 0
pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
rotationNumber = len(rotationPosition[startPiece])
#blockImage()
#stats()
#deleteNextPiece()
#updateNextPiece()
checkPieceType = False
checkGravityActive = False
pressDown = False
dropTimer = time.time()
destroy = False
setTutorial = 0
Tutorial()
tutorialImage()
top.bind("<Shift_R>", shift1)
top.bind("<KeyRelease-Up>", up)
         
top.mainloop()

