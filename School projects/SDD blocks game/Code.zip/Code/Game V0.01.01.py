from tkinter import*
from PIL import Image, ImageTk
top = Tk()
top.geometry("800x600")


w=600
h=400
x=w//2
y=h//2

canvas=Canvas(top, width=w, height=h, bg="white")
canvas.pack(pady=20)
circle=canvas.create_oval(x, y, x+10, y+10)

def left(event):
    x=-10
    y=0
    canvas.move(circle, x, y)
def right(event):
    x=10
    y=0
    canvas.move(circle, x, y)
def up(event):
    x=0
    y=-10
    canvas.move(circle, x, y)
def down(event):
    x=0
    y=10
    canvas.move(circle, x, y)

top.bind("<Left>", left)
top.bind("<Right>", right)
top.bind("<Up>", up)
top.bind("<Down>", down)
         
top.mainloop()
