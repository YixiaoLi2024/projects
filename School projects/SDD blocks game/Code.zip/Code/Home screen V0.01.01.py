from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
homeScreen = Tk()
homeScreen.geometry("740x800")
homeScreen.configure(bg = '#26FB58')

canvas = Canvas(homeScreen, width = 740, height = 800, bg="#26FB58")
canvas.pack()

settingsIcon = Image.open("settings icon.png")
settingsIcon = settingsIcon.resize((50,50), Image.LANCZOS)
settingsIcon = ImageTk.PhotoImage(settingsIcon)
settingsIcon_label= Label(image=settingsIcon)
settingsIcon_label.image = settingsIcon
frameImage = Label(homeScreen, height = 60, width = 60, image=settingsIcon, bg = '#26FB58')
frameImage.place(x = 670, y = 5)

Title = Label(canvas, text = "B", fg = 'black', bg = '#26FB58', font = ('Stencil','100'))
Title.place(x = 60, y = 120, anchor = CENTER)

frame = Frame(canvas, height = 105, width = 39, bg = 'black')
frame.place(x = 107, y = 67)

frame = Frame(canvas, height = 39, width = 39, bg = 'black')
frame.place(x = 140, y = 133)

frame = Frame(canvas, height = 33, width = 33, borderwidth = 3, relief = 'solid', bg = '#FF0000')
frame.place(x = 110, y = 70)

frame = Frame(canvas, height = 33, width = 33, borderwidth = 3, relief = 'solid', bg = '#F6FF00')
frame.place(x = 110, y = 103)

frame = Frame(canvas, height = 33, width = 33, borderwidth = 3, relief = 'solid', bg = '#0043FF')
frame.place(x = 110, y = 136)

frame = Frame(canvas, height = 33, width = 33, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 143, y = 136)

circle=canvas.create_oval(180, 70, 260, 169, fill = 'black')

circle=canvas.create_oval(190, 80, 250, 159, fill = 'white')

Title = Label(canvas, text = "CKS", fg = 'black', bg = '#26FB58', font = ('Stencil','100'))
Title.place(x = 390, y = 120, anchor = CENTER)

circle=canvas.create_oval(550, 70, 630, 169, fill = 'black')

circle=canvas.create_oval(560, 80, 620, 159, fill = 'white')

frame = Frame(canvas, height = 46, width = 46, bg = 'black')
frame.place(x = 567, y = 97)

frame = Frame(canvas, height = 20, width = 20, borderwidth = 3, relief = 'solid', bg = '#FF0000')
frame.place(x = 570, y = 100)

frame = Frame(canvas, height = 20, width = 20, borderwidth = 3, relief = 'solid', bg = '#F6FF00')
frame.place(x = 590, y = 100)

frame = Frame(canvas, height = 20, width = 20, borderwidth = 3, relief = 'solid', bg = '#0043FF')
frame.place(x = 570, y = 120)

frame = Frame(canvas, height = 20, width = 20, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 590, y = 120)

Title = Label(canvas, text = "F", fg = 'black', bg = '#26FB58', font = ('Calibri','100'))
Title.place(x = 670, y = 115, anchor = CENTER)

Title = Label(canvas, text = "MADNESS", fg = 'black', bg = '#26FB58', font = ('Algerian','100'))
Title.place(x = 360, y = 250, anchor = CENTER)

frame = Frame(canvas, height = 199, width = 689, bg = 'black')
frame.place(x = 0, y = 601)

frame = Frame(canvas, height = 52, width = 398, bg = 'black')
frame.place(x = 46, y = 551)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 0, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 49, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#00E6FF')
frame.place(x = 98, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#00E6FF')
frame.place(x = 147, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#00E6FF')
frame.place(x = 196, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 245, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 294, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 343, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 392, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 441, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 490, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 539, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 588, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 637, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 0, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 49, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 98, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#00E6FF')
frame.place(x = 147, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#86FF00')
frame.place(x = 196, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 245, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 294, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 343, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 392, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 441, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 490, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 539, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 588, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 637, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 0, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 49, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 98, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#86FF00')
frame.place(x = 147, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#86FF00')
frame.place(x = 196, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 245, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 294, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 343, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 392, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 441, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 490, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 539, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 588, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 637, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 0, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 49, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 98, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#86FF00')
frame.place(x = 147, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 196, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 245, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 294, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 343, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 392, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 441, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 490, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 539, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 588, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 637, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E5500')
frame.place(x = 49, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 98, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 147, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 196, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 245, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 294, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 343, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 392, y = 555)

circle=canvas.create_rectangle(100, 330, 620, 390, fill = '#FBD026')

circle=canvas.create_rectangle(100, 405, 620, 465, fill = '#26A6FB')

circle=canvas.create_rectangle(100, 480, 620, 540, fill = '#FB2626')

levelSelectionButton = Label(canvas, text = "LEVEL SELECTION", fg = 'white', bg = '#FBD026', font = ('Arial','30'))
levelSelectionButton.place(x = 360, y = 360, anchor = CENTER)

levelSelectionButton = Label(canvas, text = "PRACTICE", fg = 'white', bg = '#26A6FB', font = ('Arial','30'))
levelSelectionButton.place(x = 360, y = 435, anchor = CENTER)

levelSelectionButton = Label(canvas, text = "QUIT", fg = 'white', bg = '#FB2626', font = ('Arial','30'))
levelSelectionButton.place(x = 360, y = 510, anchor = CENTER)

homeScreen.mainloop()
