from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
youWinScreen = Tk()
youWinScreen.geometry("400x400")
youWinScreen.configure(bg = '#00DCFF')

canvas = Canvas(youWinScreen, width = 400, height = 400, bg="#00DCFF")
canvas.pack()

Title = Label(youWinScreen, text = "YOU WIN", fg = 'black', bg = '#00DCFF', font = ('Algerian','50'))
Title.place(x = 200, y = 100, anchor = CENTER)

Reason = Label(youWinScreen, text = "Good job!", fg = 'black', bg = '#00DCFF', font = ('Calibri','20'))
Reason.place(x = 200, y = 160, anchor = CENTER)

score = "you got a score of " + str("000332")
Score = Label(youWinScreen, text = score, fg = 'black', bg = '#00DCFF', font = ('Calibri','20'))
Score.place(x = 200, y = 200, anchor = CENTER)

circle=canvas.create_rectangle(10, 350, 140, 390, fill = '#2699FB')

levelSelectionButton = Label(canvas, text = "LEVEL SELECTION", fg = 'white', bg = '#2699FB', font = ('Arial','10'))
levelSelectionButton.place(x = 75, y = 370, anchor = CENTER)

circle=canvas.create_rectangle(260, 350, 390, 390, fill = '#2699FB')

levelSelectionButton = Label(canvas, text = "TRY AGAIN", fg = 'white', bg = '#2699FB', font = ('Arial','10'))
levelSelectionButton.place(x = 325, y = 370, anchor = CENTER)

youWinScreen.mainloop()
