from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
levelSelectionScreen = Tk()
levelSelectionScreen.geometry("740x800")
levelSelectionScreen.configure(bg = '#00CBFF')

titleFrame = Frame(levelSelectionScreen, height = 50, width = 800, bg = '#D3FFC0')
titleFrame.place(x = 0, y = 0)

Title = Label(titleFrame, text = "LEVEL SELECTION", fg = 'black', bg = '#D3FFC0', font = ('Algerian','30'))
Title.place(x = 400, y = 24, anchor = CENTER)

levelTitleFrame = Frame(levelSelectionScreen, height = 350, width = 800, bg = '#00CBFF')
levelTitleFrame.place(x = 0, y = 50)

levelTitle = Label(levelTitleFrame, text = "LEVEL", fg = 'black', bg = '#00CBFF', font = ('Algerian','30'))
levelTitle.place(x = 400, y = 24, anchor = CENTER)

levelStatsFrame = Frame(levelSelectionScreen, height = 400, width = 800, bg = '#676060')
levelStatsFrame.place(x = 0, y = 400)

levelStats = Label(levelStatsFrame, text = "LEVEL INFO", fg = 'white', bg = '#676060', font = ('Algerian','30'))
levelStats.place(x = 400, y = 24, anchor = CENTER)

level1Frame = Frame(levelSelectionScreen, height = 100, width = 100, relief = 'solid', bg = '#949494')
level1Frame.place(x = 150, y = 125)

level1 = Label(level1Frame, text = "1", fg = 'black', bg = '#949494', font = ('Calibri','70'))
level1.place(x = 50, y = 50, anchor = CENTER)

level2Frame = Frame(levelSelectionScreen, height = 100, width = 100, relief = 'solid', bg = '#F7CA08')
level2Frame.place(x = 350, y = 125)

level2 = Label(level2Frame, text = "2", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'))
level2.place(x = 50, y = 50, anchor = CENTER)

level3Frame = Frame(levelSelectionScreen, height = 100, width = 100, relief = 'solid', bg = '#F7CA08')
level3Frame.place(x = 550, y = 125)

level3 = Label(level3Frame, text = "3", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'))
level3.place(x = 50, y = 50, anchor = CENTER)

settingsIcon = Image.open("lock.png")
settingsIcon = settingsIcon.resize((60,60), Image.LANCZOS)
settingsIcon = ImageTk.PhotoImage(settingsIcon)
settingsIcon_label= Label(image=settingsIcon)
settingsIcon_label.image = settingsIcon
frameImage = Label(levelSelectionScreen, height = 57, width = 38, image=settingsIcon, bg = '#00CBFF')
frameImage.place(x = 425, y = 97)

frameImage = Label(levelSelectionScreen, height = 57, width = 38, image=settingsIcon, bg = '#00CBFF')
frameImage.place(x = 625, y = 97)
levelSelectionScreen.mainloop()
