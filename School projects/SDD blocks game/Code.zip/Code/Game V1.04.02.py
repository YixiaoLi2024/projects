from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
import pygame
homeScreen = Tk()
homeScreen.geometry("740x800")
homeScreen.configure(bg = '#26FB58')

def Settings():#settings page
    global musicSettings
    global musicButtonText
    settingsScreen = Toplevel()
    settingsScreen.geometry("400x300")
    settingsScreen.configure(bg = '#FFFF00')
    
    def switchMusicButtons():#turn on/off music
        global musicSettings
        global musicButtonText
        if musicSettings == ON:
            musicSettings = OFF
            stop()
            musicButtonText.destroy()
            musicButton.configure(bg = '#FFFFFF')
            musicButton.place(x = 300, y = 100, anchor = CENTER)
            musicButtonText = Label(settingsScreen, text="OFF", fg = 'black', bg = '#FFFF00', font = ('Arial','20'))
            musicButtonText.place(x = 350, y = 100, anchor = CENTER)
        else:
            musicSettings = ON
            play()
            musicButtonText.destroy()
            musicButton.configure(bg = '#AAAAAA')
            musicButton.place(x = 300, y = 100, anchor = CENTER)
            musicButtonText = Label(settingsScreen, text="ON", fg = 'black', bg = '#FFFF00', font = ('Arial','20'))
            musicButtonText.place(x = 350, y = 100, anchor = CENTER)

    def play():#play music
        pygame.mixer.music.load("Wings of Liberty Main Theme.MP3")
        pygame.mixer.music.play(loops=-1)

    def stop():#stop music
        pygame.mixer.music.stop()

    Title = Label(settingsScreen, text = "SETTINGS", fg = 'black', bg = '#FFFF00', font = ('Algerian','30'))
    Title.place(x = 200, y = 40, anchor = CENTER)

    musicSettings = Label(settingsScreen, text = "Music:", fg = 'black', bg = '#FFFF00', font = ('Arial','10'))
    musicSettings.place(x = 100, y = 100, anchor = CENTER)

    musicButton = Button(settingsScreen, height = 1, width = 5, relief = "flat", fg = 'black', bg = '#AAAAAA', command = switchMusicButtons)
    musicButton.place(x = 300, y = 100, anchor = CENTER)

    musicButtonText = Label(settingsScreen, text="ON", fg = 'black', bg = '#FFFF00', font = ('Arial','20'))
    musicButtonText.place(x = 350, y = 100, anchor = CENTER)

    backButtonImage = Image.open("Back button.png")
    backButtonImage = backButtonImage.resize((80,80), Image.LANCZOS)
    backButtonImage = ImageTk.PhotoImage(backButtonImage)
    backButtonImage_label= Label(image=backButtonImage)
    backButtonImage_label.image = backButtonImage
    backButtonImageFrameImage = Button(settingsScreen, height = 80, width = 80, relief = "flat", image=backButtonImage, bg = '#FFFF00', command = lambda:[settingsScreen.destroy(),enableHomeScreenButtons()])
    backButtonImageFrameImage.place(x = 75, y = 240, anchor = CENTER)

    musicSettings = ON

    settingsScreen.mainloop()






def gamePractice():#practice screen
    global deleteActiveFrameList
    global press
    global blockImageActive
    global rotationActive
    global gravityActive
    global swapActive
    global moveGravity
    global gameover
    global swapPiece
    global swapPieceOnce
    global checkPieceType
    global checkGravityActive
    global pressDown
    global destroy
    global endGame1
    global endGame2
    global minutes
    global seconds
    global lineClearNumber
    global scoreNumbers
    global drop
    global speed
    global start
    global startPiece
    global newPieceList
    global downTimer
    global dropTimer
    global rotationPosition
    global blockColour
    global Xlength
    global filledBlocks
    global newFilledBlocks
    global testFilledBlocks
    global filledBlocksVerticalLinesList
    global filledBlocksHorizontalLinesList
    global lineClearList
    global activeFrameList
    global stableFrameList
    global newPieceList
    global nextPieceFrameList
    global swapPieceList
    global swapPieceBlocksList
    global statsPiece
    global nextPieceFrame
    global swapPieceFrame
    global startNumber
    global timeLabel
    global lineClearsNumber
    global scoreNumber
    global restartButton
    gamePracticeScreen = Toplevel()
    gamePracticeScreen.geometry("740x800")
    gamePracticeScreen.configure(bg = '#068C83')

    
    #setup grid and lists
    for i in range(1,16):
        for j in range(3,33):
            frame = Frame(gamePracticeScreen, height = 20, width = 20, bg = 'black')
            frame.grid(column = i, row = j)#setup the grid

    levelFrame = Frame(gamePracticeScreen, height = 50, width = 800, bg = '#9FEA7F')
    levelFrame.place(x = 0, y = 0)#the title box

    frame = Frame(gamePracticeScreen, height = 50, width = 20, bg = '#9FEA7F')
    frame.grid(column = 0, row = 0, padx=100)

    frame = Frame(gamePracticeScreen, height = 30, width = 20, bg = '#068C83')
    frame.grid(column = 0, row = 1, padx=100)

    frame = Frame(gamePracticeScreen, height = 40, width = 20, bg = '#068C83')
    frame.grid(column = 0, row = 2, padx=100)#3 placeholder frames (for making the grid system work) that are the same colour as the background image so users won't know the frames are there

    nextPieceFrame = Frame(gamePracticeScreen, height = 100, width = 150, bg = 'black')
    nextPieceFrame.place(x = 60, y = 230)

    swapPieceFrame = Frame(gamePracticeScreen, height = 100, width = 150, bg = 'black')
    swapPieceFrame.place(x = 60, y = 340)

    fiveBlockFrame = Frame(gamePracticeScreen, height = 270, width = 150, bg = 'black')
    fiveBlockFrame.place(x = 60, y = 450)

    tutorialFrame = Frame(gamePracticeScreen, height = 60, width = 150, bg = 'white')
    tutorialFrame.place(x = 530, y = 160)

    scoreFrame = Frame(gamePracticeScreen, height = 100, width = 150, bg = 'black')
    scoreFrame.place(x = 530, y = 230)

    lineClearsFrame = Frame(gamePracticeScreen, height = 100, width = 150, bg = 'black')
    lineClearsFrame.place(x = 530, y = 340)

    fourBlockFrame = Frame(gamePracticeScreen, height = 270, width = 150, bg = 'black')
    fourBlockFrame.place(x = 530, y = 450)

    timeFrame = Frame(gamePracticeScreen, height = 40, width = 300, bg = 'white')
    timeFrame.place(x = 220, y = 80)

    exitFrame = Frame(gamePracticeScreen, height = 40, width = 80, bg = 'white')
    exitFrame.place(x = 60, y = 740)

    levelTitle = Label(levelFrame, text = "PRACTICE MATCH", fg = 'black', bg = '#9FEA7F', font = ('Algerian','30'))
    levelTitle.place(x = 400, y = 24, anchor = CENTER)

    nextPiece = Label(nextPieceFrame, text = "Next", fg = 'white', bg = 'black', font = ('calibri','20'))
    nextPiece.place(x = 75, y = 10, anchor = CENTER)

    swapPiece = Label(swapPieceFrame, text = "Swap", fg = 'white', bg = 'black', font = ('calibri','20'))
    swapPiece.place(x = 75, y = 10, anchor = CENTER)

    fiveBlocks = Label(fiveBlockFrame, text = "5 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
    fiveBlocks.place(x = 75, y = 10, anchor = CENTER)

    tutorial = Button(tutorialFrame, text = "TUTORIAL", width = 10, relief = 'flat', fg = 'black', bg = 'white', font = ('calibri','20'), command = lambda:[closePracticeLevel(),gamePracticeScreen.destroy(), Tutorial()])
    tutorial.place(x = 75, y = 30, anchor = CENTER)

    score = Label(scoreFrame, text = "Score", fg = 'white', bg = 'black', font = ('calibri','20'))
    score.place(x = 75, y = 10, anchor = CENTER)

    scoreNumber = Label(scoreFrame, text = "000000", fg = 'white', bg = 'black', font = ('calibri','20'))
    scoreNumber.place(x = 75, y = 50, anchor = CENTER)

    lineClears = Label(lineClearsFrame, text = "Line Clears", fg = 'white', bg = 'black', font = ('calibri','20'))
    lineClears.place(x = 75, y = 10, anchor = CENTER)

    lineClearsNumber = Label(lineClearsFrame, text = "000", fg = 'white', bg = 'black', font = ('calibri','20'))
    lineClearsNumber.place(x = 75, y = 50, anchor = CENTER)

    fourBlock = Label(fourBlockFrame, text = "4 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
    fourBlock.place(x = 75, y = 10, anchor = CENTER)

    Exit = Button(exitFrame, width = 5, text = "Exit", relief = 'flat', fg = 'black', bg = 'white', font = ('calibri','20'), command = lambda:[closePracticeLevel(),gamePracticeScreen.destroy(),enableHomeScreenButtons()])
    Exit.place(x = 40, y = 20, anchor = CENTER)


    rotationPosition = [[[[3,8], [3,9], [4,8], [4,9]]], [[[3,7], [3,8], [3,9], [4,7]], [[2,8], [3,8], [4,8], [4,9]], [[2,9], [3,7], [3,8], [3,9]],
                        [[2,7], [2,8], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,9]], [[2,8], [2,9], [3,8], [4,8]], [[2,7], [3,7], [3,8], [3,9]],
                        [[2,8], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [4,8]], [[2,8], [3,8], [3,9], [4,8]], [[2,8], [3,7], [3,8], [3,9]],
                        [[2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [4,8], [4,9]], [[2,9], [3,8], [3,9], [4,8]]], [[[3,8], [3,9], [4,7], [4,8]],
                        [[2,7], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [3,10]], [[1,9], [2,9], [3,9], [4,9]]], [[[3,7], [3,8], [3,9], [4,8], [5,8]],
                        [[2,8], [3,8], [3,9], [3,10], [4,8]], [[1,8], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,6], [3,7], [3,8], [4,8]]],
                        [[[3,7], [3,8], [3,9], [4,7], [4,8]], [[2,8], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,7], [3,8], [3,9]],
                        [[2,7], [2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,8], [3,9], [4,8]],
                        [[2,7], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,7], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [3,10], [4,7]],
                        [[1,9], [2,9], [3,9], [4,9], [4,10]], [[2,10], [3,7], [3,8], [3,9], [3,10]], [[1,8], [1,9], [2,9], [3,9], [4,9]]],
                        [[[3,7], [3,8], [3,9], [3,10], [4,10]], [[1,9], [1,10], [2,9], [3,9], [4,9]], [[2,7], [3,7], [3,8], [3,9], [3,10]],
                        [[1,9], [2,9], [3,9], [4,8], [4,9]]], [[[3,6], [3,7], [3,8], [3,9], [3,10]], [[1,8], [2,8], [3,8], [4,8], [5,8]]], [[[3,8]]], [[[3,8]]],
                        [[[3,8]]]]
    #spawns right to left then up to down
    #1-4 piece O shape, 2-4 piece L shape, 3-4 piece J shape, 4-4 piece T shape, 5-4 piece Z shape, 6-4 piece S shape, 7-4 piece I shape
    #8-5 piece T shape, 9-5 piece b shape, 10-5 piece d shape, 11-5 piece L shape, 12-5 piece J shape, 13-5 piece I piece
    #14-vertical lightning powerup, 15-5x5 bomb powerup, 16-3x9 nuke powerup
    #anti-clockwise
    #[Y,X]

    blockColour = ["#FF9900", "#0022FF", "#FF00EC", "#00E6FF", "#FFEC00", "#86FF00", "#FF0000", "#610034", "#00734D", "#2E6000", "#2A00B8", "#5200A5", "#660000",
                   "LIGHTNING.png", "BOMB.png", "NUKE.png"]#colour of each piece type
    Xlength = [0,1,1,1,1,1,0,1,1,1,0,0,1,1,1,1]
    filledBlocks = []
    newFilledBlocks = []
    testFilledBlocks = []
    filledBlocksVerticalLinesList = []
    filledBlocksHorizontalLinesList = []
    lineClearList = []
    activeFrameList = []
    stableFrameList = []
    newPieceList = []
    nextPieceFrameList = []
    swapPieceList = [[],[]]
    swapPieceBlocksList = []
    statsPiece = [["OPiece",0],["LPiece",0],["JPiece",0],["TPiece",0],["ZPiece",0],["SPiece",0],["IPiece",0],["5TPiece",0],["5BPiece",0],["5DPiece",0],["5LPiece",0],["5JPiece",0],["5IPiece",0]]
    for i in range(0,33):
        filledBlocksVerticalLinesList.append([])
    for i in range(0,15):
        filledBlocksHorizontalLinesList.append([])
    for j in range(0,7):
        for i in range(0,4):
            frame = Frame(gamePracticeScreen, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
            frame.place(x = 560 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 33 * j, anchor = E)
    for j in range(7,13):
        for i in range(0,5):
            frame = Frame(gamePracticeScreen, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
            frame.place(x = 100 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 40 * (j - 7), anchor = E)
    for i in range(0,7):
        statsPiece[i][0] = Label(gamePracticeScreen, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
        statsPiece[i][0].place(x = 650, y = 500 + 33 * i, anchor = CENTER)
    for i in range(7,13):
        statsPiece[i][0] = Label(gamePracticeScreen, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
        statsPiece[i][0].place(x = 180, y = 500 + 40 * (i - 7), anchor = CENTER)
        
    def closePracticeLevel():#stops the functions/threads in the practice screen when the screen is closed
        global gameover
        global endGame1
        global endGame2
        downTimer.cancel()
        gameover = True
        if endGame1 == False:#initially when the game starts, endgame1 is False and endgame2 is False and everytime game is closed, endgame1 switches and everytime the game begins, endgame2 switches
            endGame1 = True
        else:
            endGame1 = False


    #setup/add info boxes/objects
    def lineClear():#display/update the number of lines cleared
        global lineClearNumber
        global lineClearList
        lineClearNumber = lineClearNumber + len(lineClearList)
        if lineClearNumber < 100:
            if lineClearNumber < 10:
                lineClearsNumber.config(text = "00" + str(lineClearNumber))
            else:
                lineClearsNumber.config(text = "0" + str(lineClearNumber))
        else:
            lineClearsNumber.config(text = lineClearNumber)


    def displayScore():#display/update the total score
        global scoreNumbers
        if scoreNumbers < 100000:
            if scoreNumbers < 10000:
                if scoreNumbers < 1000:
                    if scoreNumbers < 100:
                        if scoreNumbers < 10:
                            scoreNumber.config(text = "00000" + str(scoreNumbers))
                        else:
                            scoreNumber.config(text = "0000" + str(scoreNumbers))
                    else:
                        scoreNumber.config(text = "000" + str(scoreNumbers))
                else:
                    scoreNumber.config(text = "00" + str(scoreNumbers))
            else:
                scoreNumber.config(text = "0" + str(scoreNumbers))
        else:
            scoreNumber.config(text = scoreNumbers)

    def lineClearScore():#formula for calculating how much score is added each time line clear/clears are performed
        global scoreNumbers
        global lineClearList
        if len(lineClearList) == 1:
            scoreNumbers = scoreNumbers + 200
        if len(lineClearList) == 2:
            scoreNumbers = scoreNumbers + 500
        if len(lineClearList) == 3:
            scoreNumbers = scoreNumbers + 1000
        if len(lineClearList) == 4:
            scoreNumbers = scoreNumbers + 3000
        if len(lineClearList) == 5:
            scoreNumbers = scoreNumbers + 5000
        displayScore()

    def lightningPowerUpScore():#formula for calculating how much score is added each time the lightning power up (the block with the lightning bolt image) is used
        global scoreNumbers
        global blocksDestroyed
        if blocksDestroyed < 5:
            scoreNumbers = scoreNumbers + 50 * blocksDestroyed
        if blocksDestroyed < 10 and blocksDestroyed > 4:
            scoreNumbers = scoreNumbers + 100 * blocksDestroyed
        if blocksDestroyed < 20 and blocksDestroyed > 9:
            scoreNumbers = scoreNumbers + 200 * blocksDestroyed
        if blocksDestroyed < 29 and blocksDestroyed > 19:
            scoreNumbers = scoreNumbers + 300 * blocksDestroyed
        if blocksDestroyed == 29:
            scoreNumbers = scoreNumbers + 15000
        displayScore()

    def bombPowerUpScore():#formula for calculating how much score is added each time the bomb power up (the block with the bomb image) is used
        global scoreNumbers
        global blocksDestroyed
        if blocksDestroyed < 11:
            scoreNumbers = scoreNumbers + 25 * blocksDestroyed
        if blocksDestroyed < 15 and blocksDestroyed > 10:
            scoreNumbers = scoreNumbers + 50 * blocksDestroyed
        if blocksDestroyed < 22 and blocksDestroyed > 14:
            scoreNumbers = scoreNumbers + 100 * blocksDestroyed
        if blocksDestroyed == 22:
            scoreNumbers = scoreNumbers + 4000
        displayScore()

    def nukePowerUpScore():#formula for calculating how much score is added each time the nuke power up (the block with the nuke cloud image) is used
        global scoreNumbers
        global blocksDestroyed
        if blocksDestroyed < 21:
            scoreNumbers = scoreNumbers + 25 * blocksDestroyed
        if blocksDestroyed < 31 and blocksDestroyed > 20:
            scoreNumbers = scoreNumbers + 50 * blocksDestroyed
        if blocksDestroyed < 42 and blocksDestroyed > 30:
            scoreNumbers = scoreNumbers + 100 * blocksDestroyed
        if blocksDestroyed == 42:
            scoreNumbers = scoreNumbers + 7000
        displayScore()


    def stats():#display/update the piece statistics
        if startPiece < 13:
            statsPiece[startPiece][1] = statsPiece[startPiece][1] + 1
            for i in range(0,7):
                statsPiece[i][0] = Label(gamePracticeScreen, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
                statsPiece[i][0].place(x = 650, y = 500 + 33 * i, anchor = CENTER)
            for i in range(7,13):
                statsPiece[i][0] = Label(gamePracticeScreen, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
                statsPiece[i][0].place(x = 180, y = 500 + 40 * (i - 7), anchor = CENTER)

    def randomPiece():#type of piece:
        global startPiece
        pieceType = random.randint(0,99)
        if pieceType < 10:
            startPiece = random.randint(13,15)
        else:
            startPiece = random.randint(0,12)

    def newPiece():#adds/spawns a new piece
        global Xpiece
        global Ypiece
        global startPiece
        global rotationPositionNumber
        global pieceBlocks
        global rotationNumber
        global blockColour
        global swapPieceOnce
        global downTimer
        downTimer.cancel()
        for i in range(0,len(filledBlocks)):
            stableFrameList[0].destroy()
            stableFrameList.pop(0)
        lineClearImage()
        Xpiece = 0 #the piece's horizontal distance moved 
        Ypiece = 0 #the piece's vertical distance moved
        randomPiece()
        newPieceList.append(startPiece)
        newPieceList.pop(0)
        startPiece = newPieceList[0]
        rotationPositionNumber = 0
        pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
        rotationNumber = len(rotationPosition[startPiece])
        blockImage()
        stats()
        deleteNextPiece()
        updateNextPiece()
        if swapPieceOnce == True:
            swapPieceOnce = False
        checkLoseCondition()
        downTimer = threading.Timer(drop, checkGravity)
        downTimer.start()

    def deleteNextPiece():#deletes the image in the next piece box
        for i in range(0,newPieceBlocks):
            nextPieceFrameList[0].destroy()
            nextPieceFrameList.pop(0)

    def updateNextPiece():#adds/updates the image in the next piece box
        global newStartPiece
        global newPieceBlocks
        newStartPiece = newPieceList[1]
        newPieceBlocks = len(rotationPosition[newStartPiece][0])
        if newStartPiece < 13:
            if Xlength[newStartPiece] == 0:
                for i in range(0,newPieceBlocks):
                    frame = Frame(nextPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[newStartPiece])
                    frame.place(x = 75 + (rotationPosition[newStartPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[newStartPiece][0][i][0] - 3) * 20, anchor = E)
                    nextPieceFrameList.append(frame)
            else:
                for i in range(0,newPieceBlocks):
                    frame = Frame(nextPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[newStartPiece])
                    frame.place(x = 85 + (rotationPosition[newStartPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[newStartPiece][0][i][0] - 3) * 20, anchor = E)
                    nextPieceFrameList.append(frame)
        if newStartPiece > 12:
            powerUpImage = Image.open(blockColour[newStartPiece])
            powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
            powerUpImage = ImageTk.PhotoImage(powerUpImage)
            powerUpImage_label= Label(image=powerUpImage)
            powerUpImage_label.image = powerUpImage
            frameImage = Label(nextPieceFrame, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
            frameImage.place(x = 85, y = 40, anchor = E)
            nextPieceFrameList.append(frameImage)

    def addSwapPiece():#adds/updates the image in the swap piece box
        if startPiece < 13:
            if Xlength[startPiece] == 0:
                for i in range(0,pieceBlocks):
                    frame = Frame(swapPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                    frame.place(x = 75 + (rotationPosition[startPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[startPiece][0][i][0] - 3) * 20, anchor = E)
                    swapPieceBlocksList.append(frame)
            else:
                for i in range(0,pieceBlocks):
                    frame = Frame(swapPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                    frame.place(x = 85 + (rotationPosition[startPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[startPiece][0][i][0] - 3) * 20, anchor = E)
                    swapPieceBlocksList.append(frame)
        if startPiece > 12:
            powerUpImage = Image.open(blockColour[startPiece])
            powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
            powerUpImage = ImageTk.PhotoImage(powerUpImage)
            powerUpImage_label= Label(image=powerUpImage)
            powerUpImage_label.image = powerUpImage
            frameImage = Label(swapPieceFrame, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
            frameImage.place(x = 85, y = 40, anchor = E)
            swapPieceBlocksList.append(frameImage)


    #game code
    def checkGravity():#set how fast the piece will drop (either normal level speed or the soft drop speed)
        global pressDown
        global drop
        global speed
        global checkGravityActive
        global downTimer
        if checkGravityActive == False:
            if pressDown == True:
                drop = 0.05
                speed = 0.04
                downTimer.cancel()
                checkGravityActive = True
                gravity()
        if pressDown == False:
            drop = 1
            speed = 0.8
            downTimer.cancel()
            checkGravityActive = True
            gravity()
        
    def gravity():#drop the piece
        global gameover
        global downTimer
        global dropTimer
        global speed
        global Ypiece
        global moveGravity
        global gravityActive
        global checkGravityActive
        if endGame1 == endGame2 and gameover == False:
            downTimer = threading.Timer(drop, checkGravity)
            downTimer.start()
            if time.time() - dropTimer > speed:
                testYpiece = Ypiece + 1
                pieceInGrid = True
                for i in range(0,pieceBlocks):
                    if rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece > 32:
                        pieceInGrid = False
                for j in range(0,len(filledBlocks)):
                    for i in range(0,pieceBlocks):
                        if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece:
                            if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece:
                                pieceInGrid = False
                if pieceInGrid == True:
                    moveGravity = True
                    gravityActive = True
                    Ypiece = Ypiece + 1
                    blockImage()
                    gravityActive = False
                    moveGravity = False
                else:
                    checkPieceType = True
                    if startPiece < 13:
                        polyomino()
                        checkPieceType = False
                    if checkPieceType == True:
                        if startPiece == 13:
                            lightningPowerUp()
                            checkPieceType = False
                    if checkPieceType == True:
                        if startPiece == 14:
                            bombPowerUp()
                            checkPieceType = False
                    if checkPieceType == True:
                        if startPiece == 15:
                            nukePowerUp()
                            checkPieceType = False
                dropTimer = time.time()
            checkGravityActive = False

    def polyomino():#code for normal pieces when they can't drop anymore
        global deleteActiveFrameList
        global moveGravity
        global gravityActive
        global downTimer
        if deleteActiveFrameList == False:
            deleteActiveFrameList = True
            moveGravity = True
            gravityActive = True
            downTimer.cancel()
            if len(activeFrameList) >= pieceBlocks:
                for i in range(0,pieceBlocks):
                    filledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece,blockColour[startPiece],activeFrameList[-1]])
                    testFilledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece,blockColour[startPiece],activeFrameList[-1]])
                    stableFrameList.append(activeFrameList[-1])
                    activeFrameList.pop(-1)
            deleteActiveFrames()
            sortFilledBlocks()
            checkLineClear()
            downTimer = threading.Timer(drop, checkGravity)
            downTimer.start()
            newPiece()
            gravityActive = False
            moveGravity = False
            deleteActiveFrameList = False

    def lightningPowerUp():#code for lightning power up when they can't drop anymore
        global filledBlocks
        global filledBlocksHorizontalLinesList
        global filledBlocksVerticalLinesList
        global downTimer
        global blocksDestroyed
        downTimer.cancel()
        deleteActiveFrames()
        blocksDestroyed = 0
        for i in range(0,len(filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1])):
            filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1][i][3].destroy()
            blocksDestroyed = blocksDestroyed + 1
        filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1] = []
        for i in range(0,len(stableFrameList)):
            stableFrameList[0].destroy()
            stableFrameList.pop(0)
        for i in range(0,15):
            for j in range(0,len(filledBlocksHorizontalLinesList[i])):
                testFilledBlocks.append(filledBlocksHorizontalLinesList[i][j])
        filledBlocksVerticalLinesList = []
        filledBlocksHorizontalLinesList = []
        for i in range(0,33):
            filledBlocksVerticalLinesList.append([])
        for i in range(0,15):
            filledBlocksHorizontalLinesList.append([])
        filledBlocks = []
        for i in range(0,len(testFilledBlocks)):
            filledBlocks.append(testFilledBlocks[i])
        lineClearImage()
        sortFilledBlocks()
        lightningPowerUpScore()
        downTimer = threading.Timer(drop, checkGravity)
        downTimer.start()
        newPiece()

    def bombPowerUp():#code for bomb power up when they can't drop anymore
        global filledBlocks
        global filledBlocksHorizontalLinesList
        global filledBlocksVerticalLinesList
        global downTimer
        global newFilledBlocks
        global blocksDestroyed
        global testFilledBlocks
        downTimer.cancel()
        deleteActiveFrames()
        blocksDestroyed = 0
        for j in range(-2,3):
            for i in range(0,len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j])):
                if filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][1] > rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 3 and filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][1] < rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece + 3:
                    filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][3].destroy()
                    filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i] = []
                    blocksDestroyed = blocksDestroyed + 1
        for i in range(0,len(stableFrameList)):
            stableFrameList[0].destroy()
            stableFrameList.pop(0)
        for i in range(0,30):
            for j in range(0,len(filledBlocksVerticalLinesList[i])):
                if filledBlocksVerticalLinesList[i][j] != []:
                    testFilledBlocks.append(filledBlocksVerticalLinesList[i][j])
        filledBlocks = []
        for i in range(0,len(testFilledBlocks)):
            filledBlocks.append(testFilledBlocks[i])
        testFilledBlocks = []
        for k in range(0,len(filledBlocks)):
            if filledBlocks[k][0] < rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 2 and filledBlocks[k][1] > rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 3 and filledBlocks[k][1] < rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece + 3:
                if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece + 2 <= 32:
                    newFilledBlocks.append([filledBlocks[k][0] + 5,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
                else:
                    newFilledBlocks.append([filledBlocks[k][0] + 32 - (rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3),filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
            else:
                newFilledBlocks.append(filledBlocks[k])
        filledBlocks = newFilledBlocks
        newFilledBlocks = []
        lineClearImage()
        for i in range(0,len(filledBlocks)):
            testFilledBlocks.append(filledBlocks[i])
        filledBlocksVerticalLinesList = []
        filledBlocksHorizontalLinesList = []
        for i in range(0,33):
            filledBlocksVerticalLinesList.append([])
        for i in range(0,15):
            filledBlocksHorizontalLinesList.append([])
        sortFilledBlocks()
        bombPowerUpScore()
        downTimer = threading.Timer(drop, checkGravity)
        downTimer.start()
        newPiece()

    def nukePowerUp():#code for nuke power up when they can't drop anymore
        global filledBlocks
        global filledBlocksHorizontalLinesList
        global filledBlocksVerticalLinesList
        global downTimer
        global newFilledBlocks
        global blocksDestroyed
        global testFilledBlocks
        downTimer.cancel()
        deleteActiveFrames()
        blocksDestroyed = 0
        for j in range(-1,2):
            for i in range(0,len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j])):
                filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][3].destroy()
                blocksDestroyed = blocksDestroyed + 1
            filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j] = []
        for i in range(0,len(stableFrameList)):
            stableFrameList[0].destroy()
            stableFrameList.pop(0)
        for i in range(0,30):
            for j in range(0,len(filledBlocksVerticalLinesList[i])):
                if filledBlocksVerticalLinesList[i][j] != []:
                    testFilledBlocks.append(filledBlocksVerticalLinesList[i][j])
        filledBlocks = []
        for i in range(0,len(testFilledBlocks)):
            filledBlocks.append(testFilledBlocks[i])
        testFilledBlocks = []
        for k in range(0,len(filledBlocks)):
            if filledBlocks[k][0] < rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1:
                if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece + 1 <= 32:
                    newFilledBlocks.append([filledBlocks[k][0] + 3,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
                else:
                    newFilledBlocks.append([filledBlocks[k][0] + 32 - (rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 2),filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
            else:
                newFilledBlocks.append(filledBlocks[k])
        filledBlocks = newFilledBlocks
        newFilledBlocks = []
        lineClearImage()
        for i in range(0,len(filledBlocks)):
            testFilledBlocks.append(filledBlocks[i])
        filledBlocksVerticalLinesList = []
        filledBlocksHorizontalLinesList = []
        for i in range(0,33):
            filledBlocksVerticalLinesList.append([])
        for i in range(0,15):
            filledBlocksHorizontalLinesList.append([])
        sortFilledBlocks()
        nukePowerUpScore()
        downTimer = threading.Timer(drop, checkGravity)
        downTimer.start()
        newPiece()

    def sortFilledBlocks():#adds the active blocks into the filled blocks horizontal and vertical lists when the active blocks can't drop anymore
        global testFilledBlocks
        for i in range(0,len(testFilledBlocks)):
            filledBlocksVerticalLinesList[testFilledBlocks[i][0] - 3].append(testFilledBlocks[i])
            filledBlocksHorizontalLinesList[testFilledBlocks[i][1] - 1].append(testFilledBlocks[i])
        testFilledBlocks = []

    def checkLineClear():#check if line clear/clears has been performed and if there is a line clear/clears, then perform a line clear/clears
        global filledBlocksVerticalLinesList
        global filledBlocksHorizontalLinesList
        global lineClearList
        global newFilledBlocks
        global filledBlocks
        for i in range(0,30):
            if len(filledBlocksVerticalLinesList[i]) == 15:
                lineClearList.append(filledBlocksVerticalLinesList[i][0][0])
        if lineClearList != []:
            for i in range(0,len(filledBlocks)):
                stableFrameList[0].destroy()
                stableFrameList.pop(0)
        for i in range(0,len(lineClearList)):
            for k in range(0,len(filledBlocks)):
                if filledBlocks[k][0] > lineClearList[i]:
                    newFilledBlocks.append(filledBlocks[k])
                if filledBlocks[k][0] < lineClearList[i]:
                    newFilledBlocks.append([filledBlocks[k][0] + 1,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
            filledBlocks = newFilledBlocks
            newFilledBlocks = []
        if lineClearList != []:
            lineClear()
            lineClearScore()
            lineClearImage()
            for i in range(0,len(filledBlocks)):
                testFilledBlocks.append(filledBlocks[i])
            filledBlocksVerticalLinesList = []
            filledBlocksHorizontalLinesList = []
            for i in range(0,33):
                filledBlocksVerticalLinesList.append([])
            for i in range(0,15):
                filledBlocksHorizontalLinesList.append([])
            sortFilledBlocks()
        lineClearList = []

    def deleteActiveFrames():
        global deleteActiveFrameList
        if deleteActiveFrameList == False:
            deleteActiveFrameList = True
            for i in range(0,len(activeFrameList)):
                activeFrameList[0].destroy()
                activeFrameList.pop(0)
            deleteActiveFrameList = False

    def blockImage():#updates the image of the active piece
        global blockImageActive
        if blockImageActive == False:
            blockImageActive = True
            if activeFrameList != []:
                deleteActiveFrames()
            if startPiece < 13:
                for i in range(0,pieceBlocks):
                    frame = Frame(gamePracticeScreen, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                    frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
                    activeFrameList.append(frame)
            if startPiece > 12:
                powerUpImage = Image.open(blockColour[startPiece])
                powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
                powerUpImage = ImageTk.PhotoImage(powerUpImage)
                powerUpImage_label= Label(image=powerUpImage)
                powerUpImage_label.image = powerUpImage
                frameImage = Label(gamePracticeScreen, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
                frameImage.grid(column = rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece)
                activeFrameList.append(frameImage)
            blockImageActive = False

    def lineClearImage():#updates the image of all the stable pieces
        for i in range(0,len(filledBlocks)):
            frame = Frame(gamePracticeScreen, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = filledBlocks[i][2])
            frame.grid(column = filledBlocks[i][1], row = filledBlocks[i][0])
            stableFrameList.append(frame)

    def checkLoseCondition():#check if the active piece has spawned inside a stable piece
        global gameover
        global downTimer
        #manually create double repeat loop -> lose condition variable in loop -> stop game + game over
        i = 0
        j = 0
        while i < pieceBlocks and gameover == False:
            while j < len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][i][0] - 3]) and gameover == False:
                if rotationPosition[startPiece][rotationPositionNumber][i][0] == filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][i][0] - 3][j][0] and rotationPosition[startPiece][rotationPositionNumber][i][1] == filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][i][0] - 3][j][1] and startPiece < 13:
                    gameover = True
                    End()
                    downTimer.cancel()
                else:
                    j = j + 1
            i = i + 1



    #controls
    def left(event):#move piece to the left by 1
        global Xpiece
        testXpiece = Xpiece - 1
        pieceInGrid = True
        for i in range(0,pieceBlocks):
            if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece < 1:
                pieceInGrid = False
        for j in range(0,len(filledBlocks)):
            for i in range(0,pieceBlocks):
                if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece:
                    if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece:
                        pieceInGrid = False
        if pieceInGrid == True:
                Xpiece = Xpiece - 1
                blockImage()

    def right(event):#move piece to the right by 1
        global Xpiece
        testXpiece = Xpiece + 1
        pieceInGrid = True
        for i in range(0,pieceBlocks):
            if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece > 15:
                pieceInGrid = False
        for j in range(0,len(filledBlocks)):
            for i in range(0,pieceBlocks):
                if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece:
                    if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece:
                        pieceInGrid = False
        if pieceInGrid == True:
                Xpiece = Xpiece + 1
                blockImage()

    def up(event):#rotate the piece to the next rotation position
        global rotationPositionNumber
        global rotationActive
        pieceInGrid = True
        testRotationPositionNumber = rotationPositionNumber
        testRotationPositionNumber = testRotationPositionNumber + 1
        if testRotationPositionNumber == rotationNumber:
            testRotationPositionNumber = 0
        for i in range(0,pieceBlocks):
            if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece > 15:
                pieceInGrid = False
            if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece < 1:
                pieceInGrid = False
            if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece > 32:
                pieceInGrid = False
            if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece < 3:
                pieceInGrid = False
        for j in range(0,len(filledBlocks)):
            for i in range(0,pieceBlocks):
                if filledBlocks[j][0] == rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece:
                    if filledBlocks[j][1] == rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece:
                        pieceInGrid = False
        if pieceInGrid == True and len(activeFrameList) == pieceBlocks:
            rotationActive = True
            deleteActiveFrames()
            rotationPositionNumber = rotationPositionNumber + 1
            if rotationPositionNumber == rotationNumber:
                rotationPositionNumber = 0
            deleteActivePiece = True
            blockImage()
            rotationActive = False

    def downPress(event):#change the piece drop speed to the soft drop speed
        global pressDown
        pressDown = True
        checkGravity()
        
    def downRelease(event):#change the piece drop speed to the normal level speed
        global pressDown
        pressDown = False
        checkGravity()

    def swapPieces(event):#swap the current active piece with the piece in the swap piece box
        global downTimer
        global swapActive
        global swapPiece
        global Xpiece
        global Ypiece
        global startPiece
        global rotationPositionNumber
        global pieceBlocks
        global rotationNumber
        global swapPieceOnce
        if gravityActive == False and swapPieceOnce == False and checkPieceType == False:
            downTimer.cancel()
            swapActive = True
            if swapPiece == False:
                swapPieceList[0] = startPiece
                addSwapPiece()
                deleteActiveFrames()
                newPiece()
                swapPiece = True
            else:
                swapPieceList[1] = swapPieceList[0]
                swapPieceList[0] = startPiece
                for i in range(0,len(swapPieceBlocksList)):
                    swapPieceBlocksList[0].destroy()
                    swapPieceBlocksList.pop(0)
                addSwapPiece()
                deleteActiveFrames()
                Xpiece = 0 #the piece's horizontal distance moved 
                Ypiece = 0 #the piece's vertical distance moved
                startPiece = swapPieceList[1]
                rotationPositionNumber = 0
                pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
                rotationNumber = len(rotationPosition[startPiece])
                blockImage()
            swapPieceOnce = True
            swapActive = False
            downTimer = threading.Timer(drop, checkGravity)
            downTimer.start()

    #start/end functions
    def Start():#initiate a countdown when the game begins
        global start
        global destroy
        global startNumber
        global endGame2
        startNumber.destroy()
        start = start - 1
        if destroy == False:
            if start > 0:
                startNumber = Label(gamePracticeScreen, text = start, fg = 'white', bg = 'black', font = ('calibri','100'))
                startNumber.place(x = 370, y = 400, anchor = CENTER)
                gamePracticeScreen.after(1000,Start)
            else:
                startNumber = Label(gamePracticeScreen, text = "start", fg = 'white', bg = 'black', font = ('calibri','100'))
                startNumber.place(x = 370, y = 400, anchor = CENTER)
                destroy = True
                gamePracticeScreen.after(1000,Start)
                endGame2 = endGame1#initially when the game starts, endgame1 is False and endgame2 is False and everytime game is closed, endgame1 switches and everytime the game begins, endgame2 switches
        else:
            gamePracticeScreen.bind("<KeyPress-Down>", downPress)
            gamePracticeScreen.bind("<KeyRelease-Down>", downRelease)
            gamePracticeScreen.bind("<Shift_L>", swapPieces)

    def End():#unbinds every control key when the game ends
        gamePracticeScreen.unbind("<Shift_L>")
        gamePracticeScreen.unbind("<Shift_R>")
        gamePracticeScreen.unbind("<Left>")
        gamePracticeScreen.unbind("<Right>")
        gamePracticeScreen.unbind("<KeyRelease-Up>")
        gamePracticeScreen.unbind("<KeyPress-Down>")
        gamePracticeScreen.unbind("<KeyRelease-Down>")

    #variable info + starting functions + adding objects
    deleteActiveFrameList = False
    press = False
    blockImageActive = False
    rotationActive = False
    gravityActive = False
    swapActive = False
    moveGravity = False
    gameover = False
    swapPiece = False
    swapPieceOnce = False
    checkPieceType = False
    checkGravityActive = False
    pressDown = False
    destroy = False
    timeStart = False
    minutes = 15
    seconds = 0
    lineClearNumber = 0
    scoreNumbers = 0
    drop = 6
    speed = 0.8
    start = 3
    randomPiece()
    newPieceList.append(startPiece)
    pieceType = random.randint(0,99)
    randomPiece()
    newPieceList.append(startPiece)
    downTimer = threading.Timer(10, checkGravity)
    downTimer.start()
    updateNextPiece()
    newPiece()
    dropTimer = time.time()
    startGravity = gamePracticeScreen.after(5000,gravity)
    startLabel = gamePracticeScreen.after(2000,Start)
    startNumber = Label(gamePracticeScreen, text = start, fg = 'white', bg = 'black', font = ('calibri','100'))
    startNumber.place(x = 370, y = 400, anchor = CENTER)
    gamePracticeScreen.bind("<Left>", left)
    gamePracticeScreen.bind("<Right>", right)
    gamePracticeScreen.bind("<KeyRelease-Up>", up)
             
    gamePracticeScreen.mainloop()




def Tutorial():#tutorial screen
    global setTutorial
    global tutorialFrame
    global fiveBlockFrame
    global fourBlockFrame
    global activeFrameList
    tutorialScreen = Toplevel()
    tutorialScreen.geometry("740x800")
    tutorialScreen.configure(bg = '#068C83')


    #setup grid and lists
    for i in range(1,16):
        for j in range(3,33):
            frame = Frame(tutorialScreen, height = 20, width = 20, bg = 'black')
            frame.grid(column = i, row = j)#setup the grid

    levelFrame = Frame(tutorialScreen, height = 50, width = 800, bg = '#9FEA7F')
    levelFrame.place(x = 0, y = 0)#the title box

    frame = Frame(tutorialScreen, height = 50, width = 20, bg = '#9FEA7F')
    frame.grid(column = 0, row = 0, padx=100)

    frame = Frame(tutorialScreen, height = 30, width = 20, bg = '#068C83')
    frame.grid(column = 0, row = 1, padx=100)

    frame = Frame(tutorialScreen, height = 40, width = 20, bg = '#068C83')
    frame.grid(column = 0, row = 2, padx=100)#3 placeholder frames (for making the grid system work) that are the same colour as the background image so users won't know the frames are there

    requiredScoreFrame = Frame(tutorialScreen, height = 100, width = 150, bg = 'black')
    requiredScoreFrame.place(x = 60, y = 120)

    nextPieceFrame = Frame(tutorialScreen, height = 100, width = 150, bg = 'black')
    nextPieceFrame.place(x = 60, y = 230)

    swapPieceFrame = Frame(tutorialScreen, height = 100, width = 150, bg = 'black')
    swapPieceFrame.place(x = 60, y = 340)

    fiveBlockFrame = Frame(tutorialScreen, height = 270, width = 150, bg = 'black')
    fiveBlockFrame.place(x = 60, y = 450)

    requiredLinesFrame = Frame(tutorialScreen, height = 100, width = 150, bg = 'black')
    requiredLinesFrame.place(x = 530, y = 120)

    scoreFrame = Frame(tutorialScreen, height = 100, width = 150, bg = 'black')
    scoreFrame.place(x = 530, y = 230)

    lineClearsFrame = Frame(tutorialScreen, height = 100, width = 150, bg = 'black')
    lineClearsFrame.place(x = 530, y = 340)

    fourBlockFrame = Frame(tutorialScreen, height = 270, width = 150, bg = 'black')
    fourBlockFrame.place(x = 530, y = 450)

    timeFrame = Frame(tutorialScreen, height = 40, width = 300, bg = 'white')
    timeFrame.place(x = 220, y = 80)

    exitFrame = Frame(tutorialScreen, height = 40, width = 80, bg = 'white')
    exitFrame.place(x = 60, y = 740)

    level = Label(levelFrame, text = "TUTORIAL", fg = 'black', bg = '#9FEA7F', font = ('Algerian','30'))
    level.place(x = 400, y = 24, anchor = CENTER)

    Exit = Button(exitFrame, width = 5, text = "Exit", relief = 'flat', fg = 'black', bg = 'white', font = ('calibri','20'), command = lambda:[tutorialScreen.destroy(),gamePractice()])
    Exit.place(x = 40, y = 20, anchor = CENTER)

    tutorialFrame = Frame(tutorialScreen, height = 200, width = 200, bg = '#EFF077')
    tutorialFrame.place(x = 370, y = 400, anchor = CENTER)#the title box


    rotationPosition = [[[[3,8], [3,9], [4,8], [4,9]]], [[[3,7], [3,8], [3,9], [4,7]], [[2,8], [3,8], [4,8], [4,9]], [[2,9], [3,7], [3,8], [3,9]],
                        [[2,7], [2,8], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,9]], [[2,8], [2,9], [3,8], [4,8]], [[2,7], [3,7], [3,8], [3,9]],
                        [[2,8], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [4,8]], [[2,8], [3,8], [3,9], [4,8]], [[2,8], [3,7], [3,8], [3,9]],
                        [[2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [4,8], [4,9]], [[2,9], [3,8], [3,9], [4,8]]], [[[3,8], [3,9], [4,7], [4,8]],
                        [[2,7], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [3,10]], [[1,9], [2,9], [3,9], [4,9]]], [[[3,7], [3,8], [3,9], [4,8], [5,8]],
                        [[2,8], [3,8], [3,9], [3,10], [4,8]], [[1,8], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,6], [3,7], [3,8], [4,8]]],
                        [[[3,7], [3,8], [3,9], [4,7], [4,8]], [[2,8], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,7], [3,8], [3,9]],
                        [[2,7], [2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,8], [3,9], [4,8]],
                        [[2,7], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,7], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [3,10], [4,7]],
                        [[1,9], [2,9], [3,9], [4,9], [4,10]], [[2,10], [3,7], [3,8], [3,9], [3,10]], [[1,8], [1,9], [2,9], [3,9], [4,9]]],
                        [[[3,7], [3,8], [3,9], [3,10], [4,10]], [[1,9], [1,10], [2,9], [3,9], [4,9]], [[2,7], [3,7], [3,8], [3,9], [3,10]],
                        [[1,9], [2,9], [3,9], [4,8], [4,9]]], [[[3,6], [3,7], [3,8], [3,9], [3,10]], [[1,8], [2,8], [3,8], [4,8], [5,8]]], [[[3,8]]], [[[3,8]]],
                        [[[3,8]]]]
    #spawns right to left then up to down
    #1-4 piece O shape, 2-4 piece L shape, 3-4 piece J shape, 4-4 piece T shape, 5-4 piece Z shape, 6-4 piece S shape, 7-4 piece I shape
    #8-5 piece T shape, 9-5 piece b shape, 10-5 piece d shape, 11-5 piece L shape, 12-5 piece J shape, 13-5 piece I piece
    #14-vertical lightning powerup, 15-5x5 bomb powerup, 16-3x9 nuke powerup
    #anti-clockwise
    #[Y,X]

    blockColour = ["#FF9900", "#0022FF", "#FF00EC", "#00E6FF", "#FFEC00", "#86FF00", "#FF0000", "#610034", "#00734D", "#2E6000", "#2A00B8", "#5200A5", "#660000",
                   "LIGHTNING.png", "BOMB.png", "NUKE.png"]#colour of each piece type
    activeFrameList = []
    newPieceList = []
    statsPiece = [["OPiece",0],["LPiece",0],["JPiece",0],["TPiece",0],["ZPiece",0],["SPiece",0],["IPiece",0],["5TPiece",0],["5BPiece",0],["5DPiece",0],["5LPiece",0],["5JPiece",0],["5IPiece",0]]

    def addStats():#add the stats box without the piece images
        global fiveBlockFrame
        global fourBlockFrame
        fiveBlocks = Label(fiveBlockFrame, text = "5 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
        fiveBlocks.place(x = 75, y = 10, anchor = CENTER)
        fourBlock = Label(fourBlockFrame, text = "4 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
        fourBlock.place(x = 75, y = 10, anchor = CENTER)
        for j in range(0,7):
            for i in range(0,4):
                frame = Frame(tutorialScreen, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
                frame.place(x = 560 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 33 * j, anchor = E)
        for j in range(7,13):
            for i in range(0,5):
                frame = Frame(tutorialScreen, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
                frame.place(x = 100 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 40 * (j - 7), anchor = E)
        for i in range(0,7):
            statsPiece[i][0] = Label(tutorialScreen, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
            statsPiece[i][0].place(x = 650, y = 500 + 33 * i, anchor = CENTER)
        for i in range(7,13):
            statsPiece[i][0] = Label(tutorialScreen, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
            statsPiece[i][0].place(x = 180, y = 500 + 40 * (i - 7), anchor = CENTER)


    #tutorial
    def Tutorial():#text in each tutorial screen
        global tutorialFrame
        global setTutorial
        global tutorialTitle
        global tutorialText
        global swapPieceText
        global nextPiece
        global fiveBlocks
        global fourBlock
        global score
        global scoreNumber
        global lineClears
        global lineClearsNumber
        global timeLabel
        global requiredScore
        global requiredLines
        global Xpiece
        global Ypiece
        global startPiece
        global rotationPositionNumber
        global pieceBlocks
        global rotationNumber
        global blockColour
        global swapPieceOnce
        global restartButton
        if setTutorial == 0:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','25'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "Welcome to the \n tutorial", fg = 'black', bg = '#EFF077', font = ('calibri','20'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 1:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "You will be controlling a main \n piece with your keyboard", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            Xpiece = 0 #the piece's horizontal distance moved 
            Ypiece = 0 #the piece's vertical distance moved
            startPiece = random.randint(0,12)
            newPieceList.append(startPiece)
            newPieceList.pop(0)
            startPiece = newPieceList[0]
            rotationPositionNumber = 0
            pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
            rotationNumber = len(rotationPosition[startPiece])
            blockImage()
            statsPiece[startPiece][1] = statsPiece[startPiece][1] + 1
        if setTutorial == 2:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "The piece must always be \n inside the 15x30 grid", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 3:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "To move the piece left, press \n or hold the left arrow key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 4:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "To move the piece right, \n press or hold the right arrow \n key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 5:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "To rotate the piece \n anti-clockwise, press and \n release the up arrow key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 6:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "The piece will slowly drop \n at a set level speed if the \n down arrow key isn't held", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 7:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "The piece will drop at the soft \n drop speed when the down \n key is held", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 8:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "You can press the left shift \n key to swap a piece if you \n have not swapped a piece \n since the piece has been \n spawned", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            swapPieceText = Label(swapPieceFrame, text = "Swap", fg = 'white', bg = 'black', font = ('calibri','20'))
            swapPieceText.place(x = 75, y = 10, anchor = CENTER)
        if setTutorial == 9:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "if the block below the piece is \n a stable piece or out of the \n grid, the piece becomes a \n stable piece and you can't \n control it anymore", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 10:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "if a new stable piece is created, the \n piece in the next piece box will be \n added to the grid and a randomly \n generated piece will replace the \n piece in the next piece box", fg = 'black', bg = '#EFF077', font = ('calibri','10'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            nextPiece = Label(nextPieceFrame, text = "Next", fg = 'white', bg = 'black', font = ('calibri','20'))
            nextPiece.place(x = 75, y = 10, anchor = CENTER)
        if setTutorial == 11:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "everytime a new piece is \n added, it will be added to the \n piece stats box", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            addStats()
        if setTutorial == 12:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "The two types of pieces are \n normal pieces and powerups", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 13:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "normal pieces are more \n common than powerups and \n they consists of either 4 or 5 \n blocks", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 14:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "normal pieces consists of \n either 4 or 5 blocks and they \n all have the same colour", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 15:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "powerups only consist of one \n block but they have an image", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 16:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "the lightning bolt powerup \n destroys every block in its \n column", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 17:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "the bomb powerup destroys \n every block in a 5x5 area with \n the powerup being the center", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 18:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "the nuke powerup destroys \n every block in the row above \n to the row below", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 19:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "to gain score, you can \n perform line clears \n or use powerups", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            score = Label(scoreFrame, text = "Score", fg = 'white', bg = 'black', font = ('calibri','20'))
            score.place(x = 75, y = 10, anchor = CENTER)
            scoreNumber = Label(scoreFrame, text = "000000", fg = 'white', bg = 'black', font = ('calibri','20'))
            scoreNumber.place(x = 75, y = 50, anchor = CENTER)
        if setTutorial == 20:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "when a row is fully filled with \n stable pieces, the whole row will \n disappear and all the blocks above \n the row will drop down the number \n of rows that have been cleared", fg = 'black', bg = '#EFF077', font = ('calibri','10'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            lineClears = Label(lineClearsFrame, text = "Line Clears", fg = 'white', bg = 'black', font = ('calibri','20'))
            lineClears.place(x = 75, y = 10, anchor = CENTER)
            lineClearsNumber = Label(lineClearsFrame, text = "000", fg = 'white', bg = 'black', font = ('calibri','20'))
            lineClearsNumber.place(x = 75, y = 50, anchor = CENTER)
        if setTutorial == 21:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "line clear score system: \n 1 line clear = 200 \n 2 line clear = 500 \n 3 line clear = 1000 \n 4 line clear = 3000 \n 5 line clear = 5000", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 22:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "lightning bolt powerup score system: \n 0-4 blocks = 50 x blocks destroyed \n 5-9 blocks = 100 x blocks destroyed \n 10-19 blocks = 200 x blocks destroyed \n 20-28 blocks = 300 x blocks destroyed \n 29 blocks = 15000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 23:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "bomb powerup score system: \n 0-10 blocks = 25 x blocks destroyed \n 11-14 blocks = 50 x blocks destroyed \n 15-21 blocks = 100 x blocks destroyed \n 22 blocks = 4000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 24:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "nuke powerup score system: \n 0-20 blocks = 25 x blocks destroyed \n 21-30 blocks = 50 x blocks destroyed \n 31-41 blocks = 100 x blocks destroyed \n 42 blocks = 7000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 25:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "if the level timer hits 0, \n you lose the level/game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            timeLabel = Label(timeFrame, text = "Time: 15:00", fg = 'black', bg = 'white', font = ('calibri','20'))
            timeLabel.place(x = 150, y = 10, anchor = CENTER)
        if setTutorial == 26:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "if the new piece spawns \n inside a stable piece, you \n also lose the game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 27:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "if you have reached the \n required score and lines \n before you have lost the \n game, you beat the \n level/game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            requiredScore = Label(requiredScoreFrame, text = "Required \n Score \n 010000", fg = 'white', bg = 'black', font = ('calibri','20'))
            requiredScore.place(x = 75, y = 45, anchor = CENTER)
            requiredLines = Label(requiredLinesFrame, text = "Required \n Lines \n 000", fg = 'white', bg = 'black', font = ('calibri','20'))
            requiredLines.place(x = 75, y = 45, anchor = CENTER)
        if setTutorial == 28:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "if you want to restart the \n level, click the restart button", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
            restartImage = Image.open("Restart button.png")
            restartImage = restartImage.resize((35,39), Image.LANCZOS)
            restartImage = ImageTk.PhotoImage(restartImage)
            restartImage_label= Label(image=restartImage)
            restartImage_label.image = restartImage
            restartButton = Label(tutorialScreen, height = 35, width = 40, relief = "flat", image=restartImage, bg = '#9FEA7F')
            restartButton.place(x = 50, y = 25, anchor = CENTER)
        if setTutorial == 29:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "you can't restart during \n the initial countdown", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)
        if setTutorial == 30:
            tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','25'))
            tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
            tutorialText = Label(tutorialFrame, text = "you have finished \n the tutorial", fg = 'black', bg = '#EFF077', font = ('calibri','20'))
            tutorialText.place(x = 100, y = 100, anchor = CENTER)

    def tutorialImage():#add the next and back buttons
        nextButtonImage = Image.open("Next button.png")
        nextButtonImage = nextButtonImage.resize((40,40), Image.LANCZOS)
        nextButtonImage = ImageTk.PhotoImage(nextButtonImage)
        nextButtonImage_label= Label(image=nextButtonImage)
        nextButtonImage_label.image = nextButtonImage
        nextButtonFrameImage = Button(tutorialFrame, height = 40, width = 40, relief = "flat", image=nextButtonImage, bg = '#EFF077', command = nextButton)
        nextButtonFrameImage.place(x = 170, y = 170, anchor = CENTER)
        backButtonImage = Image.open("Back button.png")
        backButtonImage = backButtonImage.resize((45,45), Image.LANCZOS)
        backButtonImage = ImageTk.PhotoImage(backButtonImage)
        backButtonImage_label= Label(image=backButtonImage)
        backButtonImage_label.image = backButtonImage
        backButtonImageFrameImage = Button(tutorialFrame, height = 40, width = 40, relief = "flat", image=backButtonImage, bg = '#EFF077', command = backButton)
        backButtonImageFrameImage.place(x = 30, y = 170, anchor = CENTER)

    def nextButton():#go to the next tutorial screen
        global setTutorial
        global tutorialTitle
        global tutorialText
        if setTutorial < 30:
            setTutorial = setTutorial + 1
        tutorialTitle.destroy()
        tutorialText.destroy()
        Tutorial()

    def backButton():#go to the previous tutorial screen and revert necessary changes
        global setTutorial
        global tutorialTitle
        global tutorialText
        global swapPieceText
        global nextPiece
        global fiveBlockFrame
        global fourBlockFrame
        global score
        global scoreNumber
        global lineClears
        global lineClearsNumber
        global timeLabel
        global requiredScore
        global requiredLines
        global Xpiece
        global Ypiece
        global startPiece
        global rotationPositionNumber
        global pieceBlocks
        global rotationNumber
        global blockColour
        global swapPieceOnce
        global restartButton
        if setTutorial == 0:
            pass
        else:
            setTutorial = setTutorial - 1
            if setTutorial == 0 or setTutorial == 1:
                deleteActiveFrames()
            if setTutorial == 7 or setTutorial == 8:
                swapPieceText.destroy()
            if setTutorial == 9 or setTutorial == 10:
                nextPiece.destroy()
            if setTutorial == 10 or setTutorial == 11:
                fiveBlockFrame = Frame(tutorialScreen, height = 270, width = 150, bg = 'black')
                fiveBlockFrame.place(x = 60, y = 450)
                fourBlockFrame = Frame(tutorialScreen, height = 270, width = 150, bg = 'black')
                fourBlockFrame.place(x = 530, y = 450)
            if setTutorial == 18 or setTutorial == 19:
                score.destroy()
                scoreNumber.destroy()
            if setTutorial == 19 or setTutorial == 20:
                lineClears.destroy()
                lineClearsNumber.destroy()
            if setTutorial == 24 or setTutorial == 25:
                timeLabel.destroy()
            if setTutorial == 26 or setTutorial == 27:
                requiredScore.destroy()
                requiredLines.destroy()
            if setTutorial == 27 or setTutorial == 28:
                restartButton.destroy()
        tutorialTitle.destroy()
        tutorialText.destroy()
        Tutorial()


    #setup/add info boxes/objects
    def deleteActiveFrames():#detete all the active piece blocks off the activeFrameList list
        global deleteActiveFrameList
        for i in range(0,len(activeFrameList)):
            activeFrameList[0].destroy()
            activeFrameList.pop(0)
    
    def blockImage():#updates the image of the active piece
        global startPiece
        global pieceBlocks
        global activeFrameList
        global rotationPositionNumber
        global Xpiece
        global Ypiece
        global blockColour
        global powerUpImage
        global blockImageActive
        global deleteActiveFrameList
        if activeFrameList != []:
            deleteActiveFrames()
        if startPiece < 13:
            for i in range(0,pieceBlocks):
                frame = Frame(tutorialScreen, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
                activeFrameList.append(frame)
        if startPiece > 12:
            powerUpImage = Image.open(blockColour[startPiece])
            powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
            powerUpImage = ImageTk.PhotoImage(powerUpImage)
            powerUpImage_label= Label(image=powerUpImage)
            powerUpImage_label.image = powerUpImage
            frameImage = Label(tutorialScreen, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
            frameImage.grid(column = rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece)
            activeFrameList.append(frameImage)

    #variable info + starting functions + adding objects
    startPiece = random.randint(0,15)
    newPieceList.append(startPiece)
    setTutorial = 0
    Tutorial()
    tutorialImage()
    tutorialScreen.mainloop()




def levelSelection():#level selection screen
    global dropSpeed
    global Speed
    global pieceSpawnRate
    global powerupSpawnRate
    global timeMinutes
    global timeSeconds
    global dropSpeedStats
    global pieceSpawnRateStats
    global powerupSpawnRateStats
    global timeStats
    global requiredLineClearsStats
    global requiredScoreStats
    global levelSelectionButton
    global requiredLineClearsText
    global requiredScoreText
    global requiredLineClearsGame
    global requiredScoreGame
    global level
    global highestLevel
    global level1Frame
    global level2Lock
    global level2Frame
    global level3Lock
    global level3Frame
    global level4Lock
    global level4Frame
    global level5Lock
    global level5Frame
    global level1
    global level2
    global level3
    global level4
    global level5
    global runLevelSelection
    levelSelectionScreen = Toplevel()
    levelSelectionScreen.geometry("740x800")
    levelSelectionScreen.configure(bg = '#00CBFF')

    

    def mainGame():#main game screen with levels
        game = Toplevel()
        game.geometry("740x800")
        game.configure(bg = '#068C83')


        #setup/add info boxes/objects
        def Time():#display/update the time left to complete the level
            global minutes
            global seconds
            global gameover
            global timeTimer
            global timeStart
            global loseReason
            restartButton['state'] = NORMAL
            timeStart = True
            if gameover == False:
                if minutes == 0 and seconds == 0:
                    restartLevel()
                    gameover = True
                    loseReason = "You lost by timeout"
                    disableGameButtons()
                    Lose()
                else:
                    if seconds == 0:
                        minutes = minutes - 1
                        seconds = 59
                    else:
                        seconds = seconds - 1
                    if seconds < 10:
                        secondsText = "0" + str(seconds)
                    else:
                        secondsText = str(seconds)
                    timeLabel.config(text = "Time: " + str(minutes) + ":" + secondsText)
                    timeTimer = game.after(1000,Time)


        def lineClear():#display/update the number of lines cleared
            global lineClearNumber
            global lineClearList
            lineClearNumber = lineClearNumber + len(lineClearList)
            if lineClearNumber < 100:
                if lineClearNumber < 10:
                    lineClearsNumber.config(text = "00" + str(lineClearNumber))
                else:
                    lineClearsNumber.config(text = "0" + str(lineClearNumber))
            else:
                lineClearsNumber.config(text = lineClearNumber)


        def displayScore():#display/update the total score
            global scoreNumbers
            if scoreNumbers < 100000:
                if scoreNumbers < 10000:
                    if scoreNumbers < 1000:
                        if scoreNumbers < 100:
                            if scoreNumbers < 10:
                                scoreNumber.config(text = "00000" + str(scoreNumbers))
                            else:
                                scoreNumber.config(text = "0000" + str(scoreNumbers))
                        else:
                            scoreNumber.config(text = "000" + str(scoreNumbers))
                    else:
                        scoreNumber.config(text = "00" + str(scoreNumbers))
                else:
                    scoreNumber.config(text = "0" + str(scoreNumbers))
            else:
                scoreNumber.config(text = scoreNumbers)

        def lineClearScore():#formula for calculating how much score is added each time line clear/clears are performed
            global scoreNumbers
            global lineClearList
            if len(lineClearList) == 1:
                scoreNumbers = scoreNumbers + 200
            if len(lineClearList) == 2:
                scoreNumbers = scoreNumbers + 500
            if len(lineClearList) == 3:
                scoreNumbers = scoreNumbers + 1000
            if len(lineClearList) == 4:
                scoreNumbers = scoreNumbers + 3000
            if len(lineClearList) == 5:
                scoreNumbers = scoreNumbers + 5000
            displayScore()

        def lightningPowerUpScore():#formula for calculating how much score is added each time the lightning power up (the block with the lightning bolt image) is used
            global scoreNumbers
            global blocksDestroyed
            if blocksDestroyed < 5:
                scoreNumbers = scoreNumbers + 50 * blocksDestroyed
            if blocksDestroyed < 10 and blocksDestroyed > 4:
                scoreNumbers = scoreNumbers + 100 * blocksDestroyed
            if blocksDestroyed < 20 and blocksDestroyed > 9:
                scoreNumbers = scoreNumbers + 200 * blocksDestroyed
            if blocksDestroyed < 29 and blocksDestroyed > 19:
                scoreNumbers = scoreNumbers + 300 * blocksDestroyed
            if blocksDestroyed == 29:
                scoreNumbers = scoreNumbers + 15000
            displayScore()

        def bombPowerUpScore():#formula for calculating how much score is added each time the bomb power up (the block with the bomb image) is used
            global scoreNumbers
            global blocksDestroyed
            if blocksDestroyed < 11:
                scoreNumbers = scoreNumbers + 25 * blocksDestroyed
            if blocksDestroyed < 15 and blocksDestroyed > 10:
                scoreNumbers = scoreNumbers + 50 * blocksDestroyed
            if blocksDestroyed < 22 and blocksDestroyed > 14:
                scoreNumbers = scoreNumbers + 100 * blocksDestroyed
            if blocksDestroyed == 22:
                scoreNumbers = scoreNumbers + 4000
            displayScore()

        def nukePowerUpScore():#formula for calculating how much score is added each time the nuke power up (the block with the nuke cloud image) is used
            global scoreNumbers
            global blocksDestroyed
            if blocksDestroyed < 21:
                scoreNumbers = scoreNumbers + 25 * blocksDestroyed
            if blocksDestroyed < 31 and blocksDestroyed > 20:
                scoreNumbers = scoreNumbers + 50 * blocksDestroyed
            if blocksDestroyed < 42 and blocksDestroyed > 30:
                scoreNumbers = scoreNumbers + 100 * blocksDestroyed
            if blocksDestroyed == 42:
                scoreNumbers = scoreNumbers + 7000
            displayScore()


        def stats():#display/update the piece statistics
            if startPiece < 13:
                statsPiece[startPiece][1] = statsPiece[startPiece][1] + 1
                for i in range(0,7):
                    statsPiece[i][0] = Label(game, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
                    statsPiece[i][0].place(x = 650, y = 500 + 33 * i, anchor = CENTER)
                for i in range(7,13):
                    statsPiece[i][0] = Label(game, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
                    statsPiece[i][0].place(x = 180, y = 500 + 40 * (i - 7), anchor = CENTER)

        def randomPiece():#type of piece:
            global startPiece
            pieceType = random.randint(0,99)
            if pieceType < powerupSpawnRate[level]:
                startPiece = random.randint(13,15)
            else:
                startPiece = random.randint(0,12)

        def newPiece():#adds/spawns a new piece
            global Xpiece
            global Ypiece
            global startPiece
            global rotationPositionNumber
            global pieceBlocks
            global rotationNumber
            global blockColour
            global swapPieceOnce
            global downTimer
            downTimer.cancel()
            for i in range(0,len(filledBlocks)):
                stableFrameList[0].destroy()
                stableFrameList.pop(0)
            lineClearImage()
            Xpiece = 0 #the piece's horizontal distance moved 
            Ypiece = 0 #the piece's vertical distance moved
            randomPiece()
            newPieceList.append(startPiece)
            newPieceList.pop(0)
            startPiece = newPieceList[0]
            rotationPositionNumber = 0
            pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
            rotationNumber = len(rotationPosition[startPiece])
            blockImage()
            stats()
            deleteNextPiece()
            updateNextPiece()
            if swapPieceOnce == True:
                swapPieceOnce = False
            checkWinCondition()
            checkLoseCondition()
            downTimer = threading.Timer(drop, checkGravity)
            downTimer.start()

        def deleteNextPiece():#deletes the image in the next piece box
            for i in range(0,newPieceBlocks):
                nextPieceFrameList[0].destroy()
                nextPieceFrameList.pop(0)

        def updateNextPiece():#adds/updates the image in the next piece box
            global newStartPiece
            global newPieceBlocks
            newStartPiece = newPieceList[1]
            newPieceBlocks = len(rotationPosition[newStartPiece][0])
            if newStartPiece < 13:
                if Xlength[newStartPiece] == 0:
                    for i in range(0,newPieceBlocks):
                        frame = Frame(nextPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[newStartPiece])
                        frame.place(x = 75 + (rotationPosition[newStartPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[newStartPiece][0][i][0] - 3) * 20, anchor = E)
                        nextPieceFrameList.append(frame)
                else:
                    for i in range(0,newPieceBlocks):
                        frame = Frame(nextPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[newStartPiece])
                        frame.place(x = 85 + (rotationPosition[newStartPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[newStartPiece][0][i][0] - 3) * 20, anchor = E)
                        nextPieceFrameList.append(frame)
            if newStartPiece > 12:
                powerUpImage = Image.open(blockColour[newStartPiece])
                powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
                powerUpImage = ImageTk.PhotoImage(powerUpImage)
                powerUpImage_label= Label(image=powerUpImage)
                powerUpImage_label.image = powerUpImage
                frameImage = Label(nextPieceFrame, height = 16, width = 16, relief = 'solid', image=powerUpImage, bg = 'black')
                frameImage.place(x = 85, y = 40, anchor = E)
                nextPieceFrameList.append(frameImage)

        def addSwapPiece():#adds/updates the image in the swap piece box
            if startPiece < 13:
                if Xlength[startPiece] == 0:
                    for i in range(0,pieceBlocks):
                        frame = Frame(swapPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                        frame.place(x = 75 + (rotationPosition[startPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[startPiece][0][i][0] - 3) * 20, anchor = E)
                        swapPieceBlocksList.append(frame)
                else:
                    for i in range(0,pieceBlocks):
                        frame = Frame(swapPieceFrame, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                        frame.place(x = 85 + (rotationPosition[startPiece][0][i][1] - 8) * 20, y = 40 + (rotationPosition[startPiece][0][i][0] - 3) * 20, anchor = E)
                        swapPieceBlocksList.append(frame)
            if startPiece > 12:
                powerUpImage = Image.open(blockColour[startPiece])
                powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
                powerUpImage = ImageTk.PhotoImage(powerUpImage)
                powerUpImage_label= Label(image=powerUpImage)
                powerUpImage_label.image = powerUpImage
                frameImage = Label(swapPieceFrame, height = 16, width = 16, relief = 'solid', image=powerUpImage, bg = 'black')
                frameImage.place(x = 85, y = 40, anchor = E)
                swapPieceBlocksList.append(frameImage)


        #game code
        def checkGravity():#set how fast the piece will drop (either normal level speed or the soft drop speed)
            global pressDown
            global drop
            global speed
            global checkGravityActive
            global downTimer
            if checkGravityActive == False:
                if pressDown == True:
                    drop = 0.05
                    speed = 0.04
                    downTimer.cancel()
                    checkGravityActive = True
                    gravity()
            if pressDown == False:
                drop = dropSpeed[level]
                speed = Speed[level]
                downTimer.cancel()
                checkGravityActive = True
                gravity()
            
        def gravity():#drop the piece
            global gameover
            global downTimer
            global dropTimer
            global speed
            global Ypiece
            global moveGravity
            global gravityActive
            global checkGravityActive
            if endGame1 == endGame2 and gameover == False:
                downTimer = threading.Timer(drop, checkGravity)
                downTimer.start()
                if time.time() - dropTimer > speed:
                    testYpiece = Ypiece + 1
                    pieceInGrid = True
                    for i in range(0,pieceBlocks):
                        if rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece > 32:
                            pieceInGrid = False
                    for j in range(0,len(filledBlocks)):
                        for i in range(0,pieceBlocks):
                            if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece:
                                if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece:
                                    pieceInGrid = False
                    if pieceInGrid == True:
                        moveGravity = True
                        gravityActive = True
                        Ypiece = Ypiece + 1
                        blockImage()
                        gravityActive = False
                        moveGravity = False
                    else:
                        checkPieceType = True
                        if startPiece < 13:
                            polyomino()
                            checkPieceType = False
                        if checkPieceType == True:
                            if startPiece == 13:
                                lightningPowerUp()
                                checkPieceType = False
                        if checkPieceType == True:
                            if startPiece == 14:
                                bombPowerUp()
                                checkPieceType = False
                        if checkPieceType == True:
                            if startPiece == 15:
                                nukePowerUp()
                                checkPieceType = False
                    dropTimer = time.time()
                checkGravityActive = False

        def polyomino():#code for normal pieces when they can't drop anymore
            global deleteActiveFrameList
            global moveGravity
            global gravityActive
            global downTimer
            if deleteActiveFrameList == False:
                deleteActiveFrameList = True
                moveGravity = True
                gravityActive = True
                downTimer.cancel()
                if len(activeFrameList) >= pieceBlocks:
                    for i in range(0,pieceBlocks):
                        filledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece,blockColour[startPiece],activeFrameList[-1]])
                        testFilledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece,blockColour[startPiece],activeFrameList[-1]])
                        stableFrameList.append(activeFrameList[-1])
                        activeFrameList.pop(-1)
                deleteActiveFrames()
                sortFilledBlocks()
                checkLineClear()
                downTimer = threading.Timer(drop, checkGravity)
                downTimer.start()
                newPiece()
                gravityActive = False
                moveGravity = False
                deleteActiveFrameList = False

        def lightningPowerUp():#code for lightning power up when they can't drop anymore
            global filledBlocks
            global filledBlocksHorizontalLinesList
            global filledBlocksVerticalLinesList
            global downTimer
            global blocksDestroyed
            downTimer.cancel()
            deleteActiveFrames()
            blocksDestroyed = 0
            for i in range(0,len(filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1])):
                filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1][i][3].destroy()
                blocksDestroyed = blocksDestroyed + 1
            filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1] = []
            for i in range(0,len(stableFrameList)):
                stableFrameList[0].destroy()
                stableFrameList.pop(0)
            for i in range(0,15):
                for j in range(0,len(filledBlocksHorizontalLinesList[i])):
                    testFilledBlocks.append(filledBlocksHorizontalLinesList[i][j])
            filledBlocksVerticalLinesList = []
            filledBlocksHorizontalLinesList = []
            for i in range(0,33):
                filledBlocksVerticalLinesList.append([])
            for i in range(0,15):
                filledBlocksHorizontalLinesList.append([])
            filledBlocks = []
            for i in range(0,len(testFilledBlocks)):
                filledBlocks.append(testFilledBlocks[i])
            lineClearImage()
            sortFilledBlocks()
            lightningPowerUpScore()
            downTimer = threading.Timer(drop, checkGravity)
            downTimer.start()
            newPiece()

        def bombPowerUp():#code for bomb power up when they can't drop anymore
            global filledBlocks
            global filledBlocksHorizontalLinesList
            global filledBlocksVerticalLinesList
            global downTimer
            global newFilledBlocks
            global blocksDestroyed
            global testFilledBlocks
            downTimer.cancel()
            deleteActiveFrames()
            blocksDestroyed = 0
            for j in range(-2,3):
                for i in range(0,len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j])):
                    if filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][1] > rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 3 and filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][1] < rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece + 3:
                        filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][3].destroy()
                        filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i] = []
                        blocksDestroyed = blocksDestroyed + 1
            for i in range(0,len(stableFrameList)):
                stableFrameList[0].destroy()
                stableFrameList.pop(0)
            for i in range(0,30):
                for j in range(0,len(filledBlocksVerticalLinesList[i])):
                    if filledBlocksVerticalLinesList[i][j] != []:
                        testFilledBlocks.append(filledBlocksVerticalLinesList[i][j])
            filledBlocks = []
            for i in range(0,len(testFilledBlocks)):
                filledBlocks.append(testFilledBlocks[i])
            testFilledBlocks = []
            for k in range(0,len(filledBlocks)):
                if filledBlocks[k][0] < rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 2 and filledBlocks[k][1] > rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 3 and filledBlocks[k][1] < rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece + 3:
                    if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece + 2 <= 32:
                        newFilledBlocks.append([filledBlocks[k][0] + 5,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
                    else:
                        newFilledBlocks.append([filledBlocks[k][0] + 32 - (rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3),filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
                else:
                    newFilledBlocks.append(filledBlocks[k])
            filledBlocks = newFilledBlocks
            newFilledBlocks = []
            lineClearImage()
            for i in range(0,len(filledBlocks)):
                testFilledBlocks.append(filledBlocks[i])
            filledBlocksVerticalLinesList = []
            filledBlocksHorizontalLinesList = []
            for i in range(0,33):
                filledBlocksVerticalLinesList.append([])
            for i in range(0,15):
                filledBlocksHorizontalLinesList.append([])
            sortFilledBlocks()
            bombPowerUpScore()
            downTimer = threading.Timer(drop, checkGravity)
            downTimer.start()
            newPiece()

        def nukePowerUp():#code for nuke power up when they can't drop anymore
            global filledBlocks
            global filledBlocksHorizontalLinesList
            global filledBlocksVerticalLinesList
            global downTimer
            global newFilledBlocks
            global blocksDestroyed
            global testFilledBlocks
            downTimer.cancel()
            deleteActiveFrames()
            blocksDestroyed = 0
            for j in range(-1,2):
                for i in range(0,len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j])):
                    filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][3].destroy()
                    blocksDestroyed = blocksDestroyed + 1
                filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j] = []
            for i in range(0,len(stableFrameList)):
                stableFrameList[0].destroy()
                stableFrameList.pop(0)
            for i in range(0,30):
                for j in range(0,len(filledBlocksVerticalLinesList[i])):
                    if filledBlocksVerticalLinesList[i][j] != []:
                        testFilledBlocks.append(filledBlocksVerticalLinesList[i][j])
            filledBlocks = []
            for i in range(0,len(testFilledBlocks)):
                filledBlocks.append(testFilledBlocks[i])
            testFilledBlocks = []
            for k in range(0,len(filledBlocks)):
                if filledBlocks[k][0] < rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1:
                    if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece + 1 <= 32:
                        newFilledBlocks.append([filledBlocks[k][0] + 3,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
                    else:
                        newFilledBlocks.append([filledBlocks[k][0] + 32 - (rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 2),filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
                else:
                    newFilledBlocks.append(filledBlocks[k])
            filledBlocks = newFilledBlocks
            newFilledBlocks = []
            lineClearImage()
            for i in range(0,len(filledBlocks)):
                testFilledBlocks.append(filledBlocks[i])
            filledBlocksVerticalLinesList = []
            filledBlocksHorizontalLinesList = []
            for i in range(0,33):
                filledBlocksVerticalLinesList.append([])
            for i in range(0,15):
                filledBlocksHorizontalLinesList.append([])
            sortFilledBlocks()
            nukePowerUpScore()
            downTimer = threading.Timer(drop, checkGravity)
            downTimer.start()
            newPiece()

        def sortFilledBlocks():#adds the active blocks into the filled blocks horizontal and vertical lists when the active blocks can't drop anymore
            global testFilledBlocks
            for i in range(0,len(testFilledBlocks)):
                filledBlocksVerticalLinesList[testFilledBlocks[i][0] - 3].append(testFilledBlocks[i])
                filledBlocksHorizontalLinesList[testFilledBlocks[i][1] - 1].append(testFilledBlocks[i])
            testFilledBlocks = []

        def checkLineClear():#check if line clear/clears has been performed and if there is a line clear/clears, then perform a line clear/clears
            global filledBlocksVerticalLinesList
            global filledBlocksHorizontalLinesList
            global lineClearList
            global newFilledBlocks
            global filledBlocks
            for i in range(0,30):
                if len(filledBlocksVerticalLinesList[i]) == 15:
                    lineClearList.append(filledBlocksVerticalLinesList[i][0][0])
            if lineClearList != []:
                for i in range(0,len(filledBlocks)):
                    stableFrameList[0].destroy()
                    stableFrameList.pop(0)
            for i in range(0,len(lineClearList)):
                for k in range(0,len(filledBlocks)):
                    if filledBlocks[k][0] > lineClearList[i]:
                        newFilledBlocks.append(filledBlocks[k])
                    if filledBlocks[k][0] < lineClearList[i]:
                        newFilledBlocks.append([filledBlocks[k][0] + 1,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3]])
                filledBlocks = newFilledBlocks
                newFilledBlocks = []
            if lineClearList != []:
                lineClear()
                lineClearScore()
                lineClearImage()
                for i in range(0,len(filledBlocks)):
                    testFilledBlocks.append(filledBlocks[i])
                filledBlocksVerticalLinesList = []
                filledBlocksHorizontalLinesList = []
                for i in range(0,33):
                    filledBlocksVerticalLinesList.append([])
                for i in range(0,15):
                    filledBlocksHorizontalLinesList.append([])
                sortFilledBlocks()
            lineClearList = []

        def deleteActiveFrames():#detete all the active piece blocks off the activeFrameList list
            global deleteActiveFrameList
            if deleteActiveFrameList == False:
                deleteActiveFrameList = True
                for i in range(0,len(activeFrameList)):
                    activeFrameList[0].destroy()
                    activeFrameList.pop(0)
                deleteActiveFrameList = False

        def blockImage():#updates the image of the active piece
            global blockImageActive
            if blockImageActive == False:
                blockImageActive = True
                if activeFrameList != []:
                    deleteActiveFrames()
                if startPiece < 13:
                    for i in range(0,pieceBlocks):
                        frame = Frame(game, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                        frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
                        activeFrameList.append(frame)
                if startPiece > 12:
                    powerUpImage = Image.open(blockColour[startPiece])
                    powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
                    powerUpImage = ImageTk.PhotoImage(powerUpImage)
                    powerUpImage_label= Label(image=powerUpImage)
                    powerUpImage_label.image = powerUpImage
                    frameImage = Label(game, height = 16, width = 16, relief = 'solid', image=powerUpImage, bg = 'black')
                    frameImage.grid(column = rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece)
                    activeFrameList.append(frameImage)
                blockImageActive = False

        def lineClearImage():#updates the image of all the stable pieces
            for i in range(0,len(filledBlocks)):
                frame = Frame(game, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = filledBlocks[i][2])
                frame.grid(column = filledBlocks[i][1], row = filledBlocks[i][0])
                stableFrameList.append(frame)

        def checkLoseCondition():#check if the active piece has spawned inside a stable piece
            global gameover
            global downTimer
            global loseReason
            #manually create double repeat loop -> lose condition variable in loop -> stop game + game over
            i = 0
            j = 0
            while i < pieceBlocks and gameover == False:
                while j < len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][i][0] - 3]) and gameover == False:
                    if rotationPosition[startPiece][rotationPositionNumber][i][0] == filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][i][0] - 3][j][0] and rotationPosition[startPiece][rotationPositionNumber][i][1] == filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][i][0] - 3][j][1] and startPiece < 13:
                        restartLevel()
                        gameover = True
                        loseReason = "You lost by topout"
                        End()
                        downTimer.cancel()
                        disableGameButtons()
                        Lose()
                    else:
                        j = j + 1
                i = i + 1


        def checkWinCondition():#check if the win requirements have been reached
            global gameover
            global downTimer
            global highestLevel
            if lineClearNumber >= requiredLineClearsGame[level] and scoreNumbers >= requiredScoreGame[level]:
                restartLevel()
                gameover = True
                End()
                downTimer.cancel()
                disableGameButtons()
                updateLevels()
                Win()


        #controls
        def left(event):#move piece to the left by 1
            global Xpiece
            testXpiece = Xpiece - 1
            pieceInGrid = True
            for i in range(0,pieceBlocks):
                if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece < 1:
                    pieceInGrid = False
            for j in range(0,len(filledBlocks)):
                for i in range(0,pieceBlocks):
                    if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece:
                        if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece:
                            pieceInGrid = False
            if pieceInGrid == True:
                    Xpiece = Xpiece - 1
                    blockImage()

        def right(event):#move piece to the right by 1
            global Xpiece
            testXpiece = Xpiece + 1
            pieceInGrid = True
            for i in range(0,pieceBlocks):
                if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece > 15:
                    pieceInGrid = False
            for j in range(0,len(filledBlocks)):
                for i in range(0,pieceBlocks):
                    if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece:
                        if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece:
                            pieceInGrid = False
            if pieceInGrid == True:
                    Xpiece = Xpiece + 1
                    blockImage()

        def up(event):#rotate the piece to the next rotation position
            global rotationPositionNumber
            global rotationActive
            pieceInGrid = True
            testRotationPositionNumber = rotationPositionNumber
            testRotationPositionNumber = testRotationPositionNumber + 1
            if testRotationPositionNumber == rotationNumber:
                testRotationPositionNumber = 0
            for i in range(0,pieceBlocks):
                if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece > 15:
                    pieceInGrid = False
                if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece < 1:
                    pieceInGrid = False
                if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece > 32:
                    pieceInGrid = False
                if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece < 3:
                    pieceInGrid = False
            for j in range(0,len(filledBlocks)):
                for i in range(0,pieceBlocks):
                    if filledBlocks[j][0] == rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece:
                        if filledBlocks[j][1] == rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece:
                            pieceInGrid = False
            if pieceInGrid == True and len(activeFrameList) == pieceBlocks:
                    rotationActive = True
                    deleteActiveFrames()
                    rotationPositionNumber = rotationPositionNumber + 1
                    if rotationPositionNumber == rotationNumber:
                        rotationPositionNumber = 0
                    blockImage()
                    rotationActive = False

        def downPress(event):#change the piece drop speed to the soft drop speed
            global pressDown
            pressDown = True
            checkGravity()
            
        def downRelease(event):#change the piece drop speed to the normal level speed
            global pressDown
            pressDown = False
            checkGravity()

        def swapPieces(event):#swap the current active piece with the piece in the swap piece box
            global downTimer
            global swapActive
            global swapPiece
            global Xpiece
            global Ypiece
            global startPiece
            global rotationPositionNumber
            global pieceBlocks
            global rotationNumber
            global swapPieceOnce
            if gravityActive == False and swapPieceOnce == False and checkPieceType == False:
                downTimer.cancel()
                swapActive = True
                if swapPiece == False:
                    swapPieceList[0] = startPiece
                    addSwapPiece()
                    deleteActiveFrames()
                    newPiece()
                    swapPiece = True
                else:
                    swapPieceList[1] = swapPieceList[0]
                    swapPieceList[0] = startPiece
                    for i in range(0,len(swapPieceBlocksList)):
                        swapPieceBlocksList[0].destroy()
                        swapPieceBlocksList.pop(0)
                    addSwapPiece()
                    deleteActiveFrames()
                    Xpiece = 0 #the piece's horizontal distance moved 
                    Ypiece = 0 #the piece's vertical distance moved
                    startPiece = swapPieceList[1]
                    rotationPositionNumber = 0
                    pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
                    rotationNumber = len(rotationPosition[startPiece])
                    blockImage()
                    checkLoseCondition()
                swapPieceOnce = True
                swapActive = False
                downTimer = threading.Timer(drop, checkGravity)
                downTimer.start()

        #start/end functions
        def Start():#initiate a countdown when the game begins
            global start
            global destroy
            global startNumber
            global endGame2
            startNumber.destroy()
            start = start - 1
            if destroy == False:
                if start > 0:
                    startNumber = Label(game, text = start, fg = 'white', bg = 'black', font = ('calibri','100'))
                    startNumber.place(x = 370, y = 400, anchor = CENTER)
                    game.after(1000,Start)
                else:
                    startNumber = Label(game, text = "start", fg = 'white', bg = 'black', font = ('calibri','100'))
                    startNumber.place(x = 370, y = 400, anchor = CENTER)
                    destroy = True
                    game.after(1000,Start)
                    endGame2 = endGame1#initially when the game starts, endgame1 is False and endgame2 is False and everytime game is closed, endgame1 switches and everytime the game begins, endgame2 switches
            else:
                game.bind("<KeyPress-Down>", downPress)
                game.bind("<KeyRelease-Down>", downRelease)
                game.bind("<Shift_L>", swapPieces)

        def End():#unbinds every control key when the game ends
            game.unbind("<Shift_L>")
            game.unbind("<Shift_R>")
            game.unbind("<Left>")
            game.unbind("<Right>")
            game.unbind("<KeyRelease-Up>")
            game.unbind("<KeyPress-Down>")
            game.unbind("<KeyRelease-Down>")

        def startLevel():#starts the game
            global deleteActiveFrameList
            global press
            global blockImageActive
            global rotationActive
            global gravityActive
            global swapActive
            global moveGravity
            global gameover
            global swapPiece
            global swapPieceOnce
            global checkPieceType
            global checkGravityActive
            global pressDown
            global destroy
            global timeStart
            global minutes
            global seconds
            global lineClearNumber
            global scoreNumbers
            global drop
            global speed
            global start
            global startPiece
            global newPieceList
            global downTimer
            global dropTimer
            global startGravity
            global startTimer
            global startLabel
            global rotationPosition
            global blockColour
            global Xlength
            global filledBlocks
            global newFilledBlocks
            global testFilledBlocks
            global filledBlocksVerticalLinesList
            global filledBlocksHorizontalLinesList
            global lineClearList
            global activeFrameList
            global stableFrameList
            global newPieceList
            global nextPieceFrameList
            global swapPieceList
            global swapPieceBlocksList
            global statsPiece
            global nextPieceFrame
            global swapPieceFrame
            global Exit
            global restartButton
            global startNumber
            global timeLabel
            global lineClearsNumber
            global scoreNumber
            global restartButton
            #setup grid and lists
            for i in range(1,16):
                for j in range(3,33):
                    frame = Frame(game, height = 20, width = 20, bg = 'black')
                    frame.grid(column = i, row = j)#setup the grid

            levelFrame = Frame(game, height = 50, width = 800, bg = '#9FEA7F')
            levelFrame.place(x = 0, y = 0)#the title box

            frame = Frame(game, height = 50, width = 20, bg = '#9FEA7F')
            frame.grid(column = 0, row = 0, padx=100)

            frame = Frame(game, height = 30, width = 20, bg = '#068C83')
            frame.grid(column = 0, row = 1, padx=100)

            frame = Frame(game, height = 40, width = 20, bg = '#068C83')
            frame.grid(column = 0, row = 2, padx=100)#3 placeholder frames (for making the grid system work) that are the same colour as the background image so users won't know the frames are there

            requiredScoreFrame = Frame(game, height = 100, width = 150, bg = 'black')
            requiredScoreFrame.place(x = 60, y = 120)

            nextPieceFrame = Frame(game, height = 100, width = 150, bg = 'black')
            nextPieceFrame.place(x = 60, y = 230)

            swapPieceFrame = Frame(game, height = 100, width = 150, bg = 'black')
            swapPieceFrame.place(x = 60, y = 340)

            fiveBlockFrame = Frame(game, height = 270, width = 150, bg = 'black')
            fiveBlockFrame.place(x = 60, y = 450)

            requiredLinesFrame = Frame(game, height = 100, width = 150, bg = 'black')
            requiredLinesFrame.place(x = 530, y = 120)

            scoreFrame = Frame(game, height = 100, width = 150, bg = 'black')
            scoreFrame.place(x = 530, y = 230)

            lineClearsFrame = Frame(game, height = 100, width = 150, bg = 'black')
            lineClearsFrame.place(x = 530, y = 340)

            fourBlockFrame = Frame(game, height = 270, width = 150, bg = 'black')
            fourBlockFrame.place(x = 530, y = 450)

            timeFrame = Frame(game, height = 40, width = 300, bg = 'white')
            timeFrame.place(x = 220, y = 80)

            exitFrame = Frame(game, height = 40, width = 80, bg = 'white')
            exitFrame.place(x = 60, y = 740)

            levelTitle = Label(levelFrame, text = Level[level], fg = 'black', bg = '#9FEA7F', font = ('Algerian','30'))
            levelTitle.place(x = 400, y = 24, anchor = CENTER)

            requiredScore = Label(requiredScoreFrame, text = "Required \n Score \n " + requiredScoreText[level], fg = 'white', bg = 'black', font = ('calibri','20'))
            requiredScore.place(x = 75, y = 45, anchor = CENTER)

            nextPiece = Label(nextPieceFrame, text = "Next", fg = 'white', bg = 'black', font = ('calibri','20'))
            nextPiece.place(x = 75, y = 10, anchor = CENTER)

            swapPiece = Label(swapPieceFrame, text = "Swap", fg = 'white', bg = 'black', font = ('calibri','20'))
            swapPiece.place(x = 75, y = 10, anchor = CENTER)

            fiveBlocks = Label(fiveBlockFrame, text = "5 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
            fiveBlocks.place(x = 75, y = 10, anchor = CENTER)

            requiredLines = Label(requiredLinesFrame, text = "Required \n Lines \n " + requiredLineClearsText[level], fg = 'white', bg = 'black', font = ('calibri','20'))
            requiredLines.place(x = 75, y = 45, anchor = CENTER)

            score = Label(scoreFrame, text = "Score", fg = 'white', bg = 'black', font = ('calibri','20'))
            score.place(x = 75, y = 10, anchor = CENTER)

            scoreNumber = Label(scoreFrame, text = "000000", fg = 'white', bg = 'black', font = ('calibri','20'))
            scoreNumber.place(x = 75, y = 50, anchor = CENTER)

            lineClears = Label(lineClearsFrame, text = "Line Clears", fg = 'white', bg = 'black', font = ('calibri','20'))
            lineClears.place(x = 75, y = 10, anchor = CENTER)

            lineClearsNumber = Label(lineClearsFrame, text = "000", fg = 'white', bg = 'black', font = ('calibri','20'))
            lineClearsNumber.place(x = 75, y = 50, anchor = CENTER)

            fourBlock = Label(fourBlockFrame, text = "4 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
            fourBlock.place(x = 75, y = 10, anchor = CENTER)

            timeLabel = Label(timeFrame, text = "Time: " + str(timeMinutes[level]) + ":00", fg = 'black', bg = 'white', font = ('calibri','20'))
            timeLabel.place(x = 150, y = 10, anchor = CENTER)

            Exit = Button(exitFrame, width = 5, text = "Exit", relief = 'flat', fg = 'black', bg = 'white', font = ('calibri','20'), command = lambda:[restartLevel(),closeLevel(),game.destroy(),enableLevelSelectionScreenButtons()])
            Exit.place(x = 40, y = 20, anchor = CENTER)

            restartImage = Image.open("Restart button.png")
            restartImage = restartImage.resize((35,40), Image.LANCZOS)
            restartImage = ImageTk.PhotoImage(restartImage)
            restartImage_label= Label(image=restartImage)
            restartImage_label.image = restartImage
            restartButton = Button(game, height = 35, width = 40, relief = 'flat', image=restartImage, bg = '#9FEA7F', command = lambda:[restartLevel(),startLevel()])
            restartButton.place(x = 50, y = 25, anchor = CENTER)

            restartButton['state'] = DISABLED


            rotationPosition = [[[[3,8], [3,9], [4,8], [4,9]]], [[[3,7], [3,8], [3,9], [4,7]], [[2,8], [3,8], [4,8], [4,9]], [[2,9], [3,7], [3,8], [3,9]],
                                [[2,7], [2,8], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,9]], [[2,8], [2,9], [3,8], [4,8]], [[2,7], [3,7], [3,8], [3,9]],
                                [[2,8], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [4,8]], [[2,8], [3,8], [3,9], [4,8]], [[2,8], [3,7], [3,8], [3,9]],
                                [[2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [4,8], [4,9]], [[2,9], [3,8], [3,9], [4,8]]], [[[3,8], [3,9], [4,7], [4,8]],
                                [[2,7], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [3,10]], [[1,9], [2,9], [3,9], [4,9]]], [[[3,7], [3,8], [3,9], [4,8], [5,8]],
                                [[2,8], [3,8], [3,9], [3,10], [4,8]], [[1,8], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,6], [3,7], [3,8], [4,8]]],
                                [[[3,7], [3,8], [3,9], [4,7], [4,8]], [[2,8], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,7], [3,8], [3,9]],
                                [[2,7], [2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,8], [3,9], [4,8]],
                                [[2,7], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,7], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [3,10], [4,7]],
                                [[1,9], [2,9], [3,9], [4,9], [4,10]], [[2,10], [3,7], [3,8], [3,9], [3,10]], [[1,8], [1,9], [2,9], [3,9], [4,9]]],
                                [[[3,7], [3,8], [3,9], [3,10], [4,10]], [[1,9], [1,10], [2,9], [3,9], [4,9]], [[2,7], [3,7], [3,8], [3,9], [3,10]],
                                [[1,9], [2,9], [3,9], [4,8], [4,9]]], [[[3,6], [3,7], [3,8], [3,9], [3,10]], [[1,8], [2,8], [3,8], [4,8], [5,8]]], [[[3,8]]], [[[3,8]]],
                                [[[3,8]]]]
            #spawns right to left then up to down
            #1-4 piece O shape, 2-4 piece L shape, 3-4 piece J shape, 4-4 piece T shape, 5-4 piece Z shape, 6-4 piece S shape, 7-4 piece I shape
            #8-5 piece T shape, 9-5 piece b shape, 10-5 piece d shape, 11-5 piece L shape, 12-5 piece J shape, 13-5 piece I piece
            #14-vertical lightning powerup, 15-5x5 bomb powerup, 16-3x9 nuke powerup
            #anti-clockwise
            #[Y,X]

            blockColour = ["#FF9900", "#0022FF", "#FF00EC", "#00E6FF", "#FFEC00", "#86FF00", "#FF0000", "#610034", "#00734D", "#2E6000", "#2A00B8", "#5200A5", "#660000",
                           "LIGHTNING.png", "BOMB.png", "NUKE.png"]#colour of each piece type
            Xlength = [0,1,1,1,1,1,0,1,1,1,0,0,1,1,1,1]
            filledBlocks = []
            newFilledBlocks = []
            testFilledBlocks = []
            filledBlocksVerticalLinesList = []
            filledBlocksHorizontalLinesList = []
            lineClearList = []
            activeFrameList = []
            stableFrameList = []
            newPieceList = []
            nextPieceFrameList = []
            swapPieceList = [[],[]]
            swapPieceBlocksList = []
            statsPiece = [["OPiece",0],["LPiece",0],["JPiece",0],["TPiece",0],["ZPiece",0],["SPiece",0],["IPiece",0],["5TPiece",0],["5BPiece",0],["5DPiece",0],["5LPiece",0],["5JPiece",0],["5IPiece",0]]
            for i in range(0,33):
                filledBlocksVerticalLinesList.append([])
            for i in range(0,15):
                filledBlocksHorizontalLinesList.append([])
            for j in range(0,7):
                for i in range(0,4):
                    frame = Frame(game, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
                    frame.place(x = 560 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 33 * j, anchor = E)
            for j in range(7,13):
                for i in range(0,5):
                    frame = Frame(game, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
                    frame.place(x = 100 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 40 * (j - 7), anchor = E)
            for i in range(0,7):
                statsPiece[i][0] = Label(game, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
                statsPiece[i][0].place(x = 650, y = 500 + 33 * i, anchor = CENTER)
            for i in range(7,13):
                statsPiece[i][0] = Label(game, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
                statsPiece[i][0].place(x = 180, y = 500 + 40 * (i - 7), anchor = CENTER)
            #variable info + starting functions + adding objects
            deleteActiveFrameList = False
            press = False
            blockImageActive = False
            rotationActive = False
            gravityActive = False
            swapActive = False
            moveGravity = False
            gameover = False
            swapPiece = False
            swapPieceOnce = False
            checkPieceType = False
            checkGravityActive = False
            pressDown = False
            destroy = False
            timeStart = False
            minutes = timeMinutes[level]
            seconds = 0
            lineClearNumber = 0
            scoreNumbers = 0
            drop = 5 + dropSpeed[level]
            speed = Speed[level]
            start = 3
            randomPiece()
            newPieceList.append(startPiece)
            randomPiece()
            newPieceList.append(startPiece)
            downTimer = threading.Timer(10, checkGravity)
            downTimer.start()
            updateNextPiece()
            newPiece()
            dropTimer = time.time()
            startGravity = game.after(5000,gravity)
            startTimer = game.after(5000,Time)
            startLabel = game.after(2000,Start)
            startNumber = Label(game, text = start, fg = 'white', bg = 'black', font = ('calibri','100'))
            startNumber.place(x = 370, y = 400, anchor = CENTER)
            game.bind("<Left>", left)
            game.bind("<Right>", right)
            game.bind("<KeyRelease-Up>", up)

        def restartLevel():#stops the game functions
            global downTimer
            global timeStart
            global timeTimer
            downTimer.cancel()
            if timeStart == True:
                game.after_cancel(timeTimer)
                timeStart = False
            else:
                game.after_cancel(startGravity)
                game.after_cancel(startTimer)
                game.after_cancel(startLabel)
            game.unbind("<Left>")
            game.unbind("<Right>")
            game.unbind("<KeyRelease-Up>")

        def closeLevel():#stops the functions/threads in the practice screen when the screen is closed
            global gameover
            global endGame1
            global endGame2
            downTimer.cancel()
            gameover = True
            if endGame1 == False:#initially when the game starts, endgame1 is False and endgame2 is False and everytime game is closed, endgame1 switches and everytime the game begins, endgame2 switches
                endGame1 = True
            else:
                endGame1 = False

        def nextLevel():#selects the level after the current level
            global level
            if level < 4:
                level = level + 1

        def disableGameButtons():#disable buttons in the game
            Exit['state'] = DISABLED
            restartButton['state'] = DISABLED

        def enableGameButtons():#enable buttons in the game
            Exit['state'] = NORMAL


        def countTotalPieces():#count the total pieces that have been spawned
            global totalPieces
            totalPieces = 0
            for i in range(0,len(statsPiece)):
                totalPieces = totalPieces + statsPiece[i][1]


        def Win():#win screen
            youWinScreen = Tk()
            youWinScreen.geometry("400x400")
            youWinScreen.configure(bg = '#00DCFF')

            canvas = Canvas(youWinScreen, width = 400, height = 400, bg="#00DCFF")
            canvas.pack()

            if level == 4:
                Title = Label(youWinScreen, text = "GG", fg = 'black', bg = '#00DCFF', font = ('Algerian','50'))
                Title.place(x = 200, y = 100, anchor = CENTER)
            else:
                Title = Label(youWinScreen, text = "YOU WIN", fg = 'black', bg = '#00DCFF', font = ('Algerian','50'))
                Title.place(x = 200, y = 100, anchor = CENTER)

            Reason = Label(youWinScreen, text = "Good job!", fg = 'black', bg = '#00DCFF', font = ('Calibri','20'))
            Reason.place(x = 200, y = 160, anchor = CENTER)

            Score = Label(youWinScreen, text = "you got a score of " + str(scoreNumbers) + " \n and " + str(lineClearNumber) + " line clears", fg = 'black', bg = '#00DCFF', font = ('Calibri','20'))
            Score.place(x = 200, y = 220, anchor = CENTER)

            countTotalPieces()

            totalPiecesText = Label(youWinScreen, text = "you spawned " + str(totalPieces) + " pieces", fg = 'black', bg = '#00DCFF', font = ('Calibri','20'))
            totalPiecesText.place(x = 200, y = 280, anchor = CENTER)

            winLevelSelectionButton = Button(youWinScreen, height = 2, width = 15, text = "LEVEL SELECTION", fg = 'white', bg = '#2699FB', font = ('Arial','10'), command = lambda:[youWinScreen.destroy(),game.destroy(),enableLevelSelectionScreenButtons()])
            winLevelSelectionButton.place(x = 75, y = 370, anchor = CENTER)

            nextLevelSelectionButton = Button(youWinScreen, height = 2, width = 15, text = "NEXT LEVEL", fg = 'white', bg = '#2699FB', font = ('Arial','10'), command = lambda:[youWinScreen.destroy(),enableGameButtons(),nextLevel(),game.destroy(),mainGame()])
            nextLevelSelectionButton.place(x = 325, y = 370, anchor = CENTER)

            youWinScreen.mainloop()



        def Lose():#lose screen
            gameOverScreen = Tk()
            gameOverScreen.geometry("400x400")
            gameOverScreen.configure(bg = 'red')

            canvas = Canvas(gameOverScreen, width = 400, height = 400, bg="red")
            canvas.pack()

            Title = Label(gameOverScreen, text = "GAME OVER", fg = 'black', bg = 'red', font = ('Algerian','50'))
            Title.place(x = 200, y = 100, anchor = CENTER)

            Reason = Label(gameOverScreen, text = loseReason, fg = 'black', bg = 'red', font = ('Calibri','20'))
            Reason.place(x = 200, y = 160, anchor = CENTER)

            Score = Label(gameOverScreen, text = "you got a score of " + str(scoreNumbers) + " \n and " + str(lineClearNumber) + " line clears", fg = 'black', bg = 'red', font = ('Calibri','20'))
            Score.place(x = 200, y = 220, anchor = CENTER)

            countTotalPieces()

            totalPiecesText = Label(gameOverScreen, text = "you spawned " + str(totalPieces) + " pieces", fg = 'black', bg = 'red', font = ('Calibri','20'))
            totalPiecesText.place(x = 200, y = 280, anchor = CENTER)

            levelSelectionButton = Button(gameOverScreen, height = 2, width = 15, text = "LEVEL SELECTION", fg = 'white', bg = '#D90101', font = ('Arial','10'), command = lambda:[gameOverScreen.destroy(),game.destroy(),enableLevelSelectionScreenButtons()])
            levelSelectionButton.place(x = 75, y = 370, anchor = CENTER)

            levelSelectionButton = Button(gameOverScreen, height = 2, width = 15, text = "TRY AGAIN", fg = 'white', bg = '#D90101', font = ('Arial','10'), command = lambda:[gameOverScreen.destroy(),enableGameButtons(),game.destroy(),mainGame()])
            levelSelectionButton.place(x = 325, y = 370, anchor = CENTER)

            gameOverScreen.mainloop()

        
        startLevel()
        game.mainloop()



    def levelSelectionStats():#stats that are displayed when a level is selected in the level selection screen
        global dropSpeedStats
        global pieceSpawnRateStats
        global powerupSpawnRateStats
        global timeStats
        global requiredLineClearsStats
        global requiredScoreStats
        global levelSelectionButton
        dropSpeedStats.destroy()
        pieceSpawnRateStats.destroy()
        powerupSpawnRateStats.destroy()
        timeStats.destroy()
        requiredLineClearsStats.destroy()
        requiredScoreStats.destroy()
        levelSelectionButton.destroy()
        
        dropSpeedStats = Label(levelStatsFrame, text = "Drop speed: " + str(dropSpeed[level]) + "s", fg = 'black', bg = '#676060', font = ('Calibri','20'))
        dropSpeedStats.place(x = 50, y = 50)

        pieceSpawnRateStats = Label(levelStatsFrame, text = "Piece spawn rate: " + str(pieceSpawnRate[level]) + "%", fg = 'black', bg = '#676060', font = ('Calibri','20'))
        pieceSpawnRateStats.place(x = 50, y = 90)

        powerupSpawnRateStats = Label(levelStatsFrame, text = "Powerup spawn rate: " + str(powerupSpawnRate[level]) + "%", fg = 'black', bg = '#676060', font = ('Calibri','20'))
        powerupSpawnRateStats.place(x = 50, y = 130)

        timeStats = Label(levelStatsFrame, text = "Time: " + str(timeMinutes[level]) + ":00", fg = 'black', bg = '#676060', font = ('Calibri','20'))
        timeStats.place(x = 50, y = 170)

        requiredLineClearsStats = Label(levelStatsFrame, text = "Required line clears: " + requiredLineClearsText[level], fg = 'black', bg = '#676060', font = ('Calibri','20'))
        requiredLineClearsStats.place(x = 50, y = 210)

        requiredScoreStats = Label(levelStatsFrame, text = "Required Score clears: " + requiredScoreText[level], fg = 'black', bg = '#676060', font = ('Calibri','20'))
        requiredScoreStats.place(x = 50, y = 250)

        levelSelectionButton = Button(levelStatsFrame, width = 20, text = "START", fg = 'white', bg = '#00CA0D', font = ('Arial','30'), command = mainGame)
        levelSelectionButton.place(x = 400, y = 340, anchor = CENTER)
        
    def updateLevels():#updates graphically which levels are locked
        global highestLevel
        global level2
        global level3
        global level4
        global level5
        if level == 0 and highestLevel == 0:
            level2Lock.destroy()
            highestLevel = highestLevel + 1
        if level == 1 and highestLevel == 1:
            level3Lock.destroy()
            highestLevel = highestLevel + 1
        if level == 2 and highestLevel == 2:
            level4Lock.destroy()
            highestLevel = highestLevel + 1
        if level == 3 and highestLevel == 3:
            level5Lock.destroy()
            highestLevel = highestLevel + 1
        changeButtonColour()
        initialButtonColour()

    def changeButtonColour():#updates which levels can be played (or changed from labels to buttons) and the colour of each buttons (which button is currently selected or not)
        global level1
        global level2
        global level3
        global level4
        global level5
        if highestLevel >= 0:
            level1.destroy()
            level1 = Button(level1Frame, height = 15, width = 15, relief = 'flat', text = "1", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'), command = lambda:[changeButtonColour(),level1Button()])
            level1.place(x = 50, y = 50, anchor = CENTER)
        if highestLevel >= 1:
            level2.destroy()
            level2Lock.destroy()
            level2 = Button(level2Frame, height = 15, width = 15, relief = 'flat', text = "2", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'), command = lambda:[changeButtonColour(),level2Button()])
            level2.place(x = 50, y = 50, anchor = CENTER)
        if highestLevel >= 2:
            level3.destroy()
            level3Lock.destroy()
            level3 = Button(level3Frame, height = 15, width = 15, relief = 'flat', text = "3", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'), command = lambda:[changeButtonColour(),level3Button()])
            level3.place(x = 50, y = 50, anchor = CENTER)
        if highestLevel >= 3:
            level4.destroy()
            level4Lock.destroy()
            level4 = Button(level4Frame, height = 15, width = 15, relief = 'flat', text = "4", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'), command = lambda:[changeButtonColour(),level4Button()])
            level4.place(x = 50, y = 50, anchor = CENTER)
        if highestLevel == 4:
            level5.destroy()
            level5Lock.destroy()
            level5 = Button(level5Frame, height = 15, width = 15, relief = 'flat', text = "5", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'), command = lambda:[changeButtonColour(),level5Button()])
            level5.place(x = 50, y = 50, anchor = CENTER)

    def initialButtonColour():#change button colour to show the current level is selected if the level selection is selected or the level is changed through the main game screen
        if level == 0:
            level1.config(bg = '#949494')
        if level == 1:
            level2.config(bg = '#949494')
        if level == 2:
            level3.config(bg = '#949494')
        if level == 3:
            level4.config(bg = '#949494')
        if level == 4:
            level5.config(bg = '#949494')

    def level1Button():#change level 1 button colour to be the selected colour if it is selected
        global level1
        global level
        level1.config(bg = '#949494')
        level = 0
        levelSelectionStats()

    def level2Button():#change level 2 button colour to be the selected colour if it is selected
        global level2
        global level
        level2.config(bg = '#949494')
        level = 1
        levelSelectionStats()

    def level3Button():#change level 3 button colour to be the selected colour if it is selected
        global level3
        global level
        level3.config(bg = '#949494')
        level = 2
        levelSelectionStats()

    def level4Button():#change level 4 button colour to be the selected colour if it is selected
        global level4
        global level
        level4.config(bg = '#949494')
        level = 3
        levelSelectionStats()

    def level5Button():#change level 5 button colour to be the selected colour if it is selected
        global level5
        global level
        level5.config(bg = '#949494')
        level = 4
        levelSelectionStats()

    def disableLevelSelectionScreenButtons():#disable buttons in level selection screen
        backButtonImageFrameImage['state'] = DISABLED
        levelSelectionButton['state'] = DISABLED
        level1['state'] = DISABLED
        level2['state'] = DISABLED
        level3['state'] = DISABLED
        level4['state'] = DISABLED
        level5['state'] = DISABLED

    def enableLevelSelectionScreenButtons():#enable buttons in level selection screen
        backButtonImageFrameImage['state'] = NORMAL
        levelSelectionButton['state'] = NORMAL
        level1['state'] = NORMAL
        level2['state'] = NORMAL
        level3['state'] = NORMAL
        level4['state'] = NORMAL
        level5['state'] = NORMAL

    titleFrame = Frame(levelSelectionScreen, height = 50, width = 800, bg = '#D3FFC0')
    titleFrame.place(x = 0, y = 0)

    Title = Label(titleFrame, text = "LEVEL SELECTION", fg = 'black', bg = '#D3FFC0', font = ('Algerian','30'))
    Title.place(x = 400, y = 24, anchor = CENTER)

    levelTitleFrame = Frame(levelSelectionScreen, height = 350, width = 800, bg = '#00CBFF')
    levelTitleFrame.place(x = 0, y = 50)

    levelTitle = Label(levelTitleFrame, text = "LEVEL", fg = 'black', bg = '#00CBFF', font = ('Algerian','30'))
    levelTitle.place(x = 400, y = 24, anchor = CENTER)

    levelStatsFrame = Frame(levelSelectionScreen, height = 400, width = 800, bg = '#676060')
    levelStatsFrame.place(x = 0, y = 400)

    levelStats = Label(levelStatsFrame, text = "LEVEL INFO", fg = 'white', bg = '#676060', font = ('Algerian','30'))
    levelStats.place(x = 400, y = 24, anchor = CENTER)

    level1Frame = Frame(levelSelectionScreen, height = 100, width = 100, relief = 'solid', bg = '#949494')
    level1Frame.place(x = 150, y = 125)

    level1 = Button(level1Frame, height = 15, width = 15, relief = 'flat', text = "1", fg = 'black', bg = '#949494', font = ('Calibri','70'), command = lambda:[changeButtonColour(),level1Button()])
    level1.place(x = 50, y = 50, anchor = CENTER)

    level1 = Button(level1Frame, height = 15, width = 15, relief = 'flat', text = "1", fg = 'black', bg = '#949494', font = ('Calibri','70'), command = lambda:[changeButtonColour(),level1Button()])
    level1.place(x = 50, y = 50, anchor = CENTER)

    level2Frame = Frame(levelSelectionScreen, height = 100, width = 100, relief = 'solid', bg = '#F7CA08')
    level2Frame.place(x = 350, y = 125)

    level2 = Label(level2Frame, text = "2", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'))
    level2.place(x = 50, y = 50, anchor = CENTER)

    level3Frame = Frame(levelSelectionScreen, height = 100, width = 100, relief = 'solid', bg = '#F7CA08')
    level3Frame.place(x = 550, y = 125)

    level3 = Label(level3Frame, text = "3", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'))
    level3.place(x = 50, y = 50, anchor = CENTER)

    level4Frame = Frame(levelSelectionScreen, height = 100, width = 100, relief = 'solid', bg = '#F7CA08')
    level4Frame.place(x = 250, y = 275)

    level4 = Label(level4Frame, text = "4", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'))
    level4.place(x = 50, y = 50, anchor = CENTER)

    level5Frame = Frame(levelSelectionScreen, height = 100, width = 100, relief = 'solid', bg = '#F7CA08')
    level5Frame.place(x = 450, y = 275)

    level5 = Label(level5Frame, text = "5", fg = 'black', bg = '#F7CA08', font = ('Calibri','70'))
    level5.place(x = 50, y = 50, anchor = CENTER)

    lockIcon = Image.open("lock.png")
    lockIcon = lockIcon.resize((60,60), Image.LANCZOS)
    lockIcon = ImageTk.PhotoImage(lockIcon)
    lockIcon_label= Label(image=lockIcon)
    lockIcon_label.image = lockIcon

    level2Lock = Label(levelSelectionScreen, height = 57, width = 38, image=lockIcon, bg = '#00CBFF')
    level2Lock.place(x = 425, y = 97)

    level3Lock = Label(levelSelectionScreen, height = 57, width = 38, image=lockIcon, bg = '#00CBFF')
    level3Lock.place(x = 625, y = 97)

    level4Lock = Label(levelSelectionScreen, height = 57, width = 38, image=lockIcon, bg = '#00CBFF')
    level4Lock.place(x = 325, y = 247)

    level5Lock = Label(levelSelectionScreen, height = 57, width = 38, image=lockIcon, bg = '#00CBFF')
    level5Lock.place(x = 525, y = 247)

    Level = ["LEVEL 1","LEVEL 2","LEVEL 3","LEVEL 4","LEVEL 5"]
    dropSpeed = [2,1,0.5,0.2,0.1]
    Speed = [1.8,0.8,0.3,0.19,0.09]
    pieceSpawnRate = [75,90,95,98,100]
    powerupSpawnRate = [25,10,5,2,0]
    timeMinutes = [10,15,30,45,60]
    requiredLineClearsText = ["000","010","050","075","100"]#used for displaying text
    requiredLineClearsGame = [0,10,50,75,100]#used for game code
    requiredScoreText = ["005000","010000","020000","030000","050000"]
    requiredScoreGame = [10,0,0,0,0]

    if runLevelSelection == False:
        runLevelSelection = True
        level = 4#first level
        highestLevel = 0#highest unlocked level
    else:
        changeButtonColour()
        initialButtonColour()
    
    dropSpeedStats = Label(levelStatsFrame, text = "Drop speed: " + str(dropSpeed[level]) + "s", fg = 'black', bg = '#676060', font = ('Calibri','20'))
    dropSpeedStats.place(x = 50, y = 50)

    pieceSpawnRateStats = Label(levelStatsFrame, text = "Piece spawn rate: " + str(pieceSpawnRate[level]) + "%", fg = 'black', bg = '#676060', font = ('Calibri','20'))
    pieceSpawnRateStats.place(x = 50, y = 90)

    powerupSpawnRateStats = Label(levelStatsFrame, text = "Powerup spawn rate: " + str(powerupSpawnRate[level]) + "%", fg = 'black', bg = '#676060', font = ('Calibri','20'))
    powerupSpawnRateStats.place(x = 50, y = 130)

    timeStats = Label(levelStatsFrame, text = "Time: " + str(timeMinutes[level]) + ":00", fg = 'black', bg = '#676060', font = ('Calibri','20'))
    timeStats.place(x = 50, y = 170)

    requiredLineClearsStats = Label(levelStatsFrame, text = "Required line clears: " + requiredLineClearsText[level], fg = 'black', bg = '#676060', font = ('Calibri','20'))
    requiredLineClearsStats.place(x = 50, y = 210)

    requiredScoreStats = Label(levelStatsFrame, text = "Required Score clears: " + requiredScoreText[level], fg = 'black', bg = '#676060', font = ('Calibri','20'))
    requiredScoreStats.place(x = 50, y = 250)

    levelSelectionButton = Button(levelStatsFrame, width = 20, text = "START", fg = 'white', bg = '#00CA0D', font = ('Arial','30'), command = lambda:[disableLevelSelectionScreenButtons(),mainGame()])
    levelSelectionButton.place(x = 400, y = 340, anchor = CENTER)

    backButtonImage = Image.open("Back button.png")
    backButtonImage = backButtonImage.resize((80,80), Image.LANCZOS)
    backButtonImage = ImageTk.PhotoImage(backButtonImage)
    backButtonImage_label= Label(image=backButtonImage)
    backButtonImage_label.image = backButtonImage
    backButtonImageFrameImage = Button(levelSelectionScreen, height = 80, width = 80, relief = "flat", image=backButtonImage, bg = '#676060', command = lambda:[levelSelectionScreen.destroy(),enableHomeScreenButtons()])
    backButtonImageFrameImage.place(x = 75, y = 740, anchor = CENTER)
    
    levelSelectionScreen.mainloop()


    



pygame.mixer.init()
pygame.mixer.music.load("Wings of Liberty Main Theme.MP3")
pygame.mixer.music.play(loops=-1)

def stop():#stop music
    pygame.mixer.music.stop()

canvas = Canvas(homeScreen, width = 740, height = 800, bg="#26FB58")
canvas.pack()

Title = Label(canvas, text = "B", fg = 'black', bg = '#26FB58', font = ('Stencil','100'))
Title.place(x = 60, y = 120, anchor = CENTER)

frame = Frame(canvas, height = 105, width = 39, bg = 'black')
frame.place(x = 107, y = 67)

frame = Frame(canvas, height = 39, width = 39, bg = 'black')
frame.place(x = 140, y = 133)

frame = Frame(canvas, height = 33, width = 33, borderwidth = 3, relief = 'solid', bg = '#FF0000')
frame.place(x = 110, y = 70)

frame = Frame(canvas, height = 33, width = 33, borderwidth = 3, relief = 'solid', bg = '#F6FF00')
frame.place(x = 110, y = 103)

frame = Frame(canvas, height = 33, width = 33, borderwidth = 3, relief = 'solid', bg = '#0043FF')
frame.place(x = 110, y = 136)

frame = Frame(canvas, height = 33, width = 33, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 143, y = 136)

circle=canvas.create_oval(180, 70, 260, 169, fill = 'black')

circle=canvas.create_oval(190, 80, 250, 159, fill = 'white')

Title = Label(canvas, text = "CKS", fg = 'black', bg = '#26FB58', font = ('Stencil','100'))
Title.place(x = 390, y = 120, anchor = CENTER)

circle=canvas.create_oval(550, 70, 630, 169, fill = 'black')

circle=canvas.create_oval(560, 80, 620, 159, fill = 'white')

frame = Frame(canvas, height = 46, width = 46, bg = 'black')
frame.place(x = 567, y = 97)

frame = Frame(canvas, height = 20, width = 20, borderwidth = 3, relief = 'solid', bg = '#FF0000')
frame.place(x = 570, y = 100)

frame = Frame(canvas, height = 20, width = 20, borderwidth = 3, relief = 'solid', bg = '#F6FF00')
frame.place(x = 590, y = 100)

frame = Frame(canvas, height = 20, width = 20, borderwidth = 3, relief = 'solid', bg = '#0043FF')
frame.place(x = 570, y = 120)

frame = Frame(canvas, height = 20, width = 20, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 590, y = 120)

Title = Label(canvas, text = "F", fg = 'black', bg = '#26FB58', font = ('Calibri','100'))
Title.place(x = 670, y = 115, anchor = CENTER)

Title = Label(canvas, text = "MADNESS", fg = 'black', bg = '#26FB58', font = ('Algerian','100'))
Title.place(x = 360, y = 250, anchor = CENTER)

frame = Frame(canvas, height = 199, width = 689, bg = 'black')
frame.place(x = 0, y = 601)

frame = Frame(canvas, height = 52, width = 398, bg = 'black')
frame.place(x = 46, y = 551)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 0, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 49, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#00E6FF')
frame.place(x = 98, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#00E6FF')
frame.place(x = 147, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#00E6FF')
frame.place(x = 196, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 245, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 294, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 343, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 392, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 441, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 490, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 539, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 588, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 637, y = 751)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 0, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 49, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 98, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#00E6FF')
frame.place(x = 147, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#86FF00')
frame.place(x = 196, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 245, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 294, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 343, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 392, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 441, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 490, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 539, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 588, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 637, y = 702)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 0, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 49, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 98, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#86FF00')
frame.place(x = 147, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#86FF00')
frame.place(x = 196, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 245, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 294, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 343, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 392, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 441, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#610034')
frame.place(x = 490, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 539, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 588, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 637, y = 653)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 0, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E6000')
frame.place(x = 49, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 98, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#86FF00')
frame.place(x = 147, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 196, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 245, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FFEC00')
frame.place(x = 294, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 343, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 392, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 441, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 490, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF00EC')
frame.place(x = 539, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 588, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0080FF')
frame.place(x = 637, y = 604)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#2E5500')
frame.place(x = 49, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 98, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#5200A5')
frame.place(x = 147, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 196, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 245, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#0022FF')
frame.place(x = 294, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 343, y = 555)

frame = Frame(canvas, height = 49, width = 49, borderwidth = 3, relief = 'solid', bg = '#FF9900')
frame.place(x = 392, y = 555)

def disableHomeScreenButtons():#disable buttons in the home screen
    settingsButton['state'] = DISABLED
    levelSelectionScreenButton['state'] = DISABLED
    practiceLevelButton['state'] = DISABLED
    quitButton['state'] = DISABLED

def enableHomeScreenButtons():#enable buttons in the home screen
    settingsButton['state'] = NORMAL
    levelSelectionScreenButton['state'] = NORMAL
    practiceLevelButton['state'] = NORMAL
    quitButton['state'] = NORMAL

settingsIcon = Image.open("settings icon.png")
settingsIcon = settingsIcon.resize((50,50), Image.LANCZOS)
settingsIcon = ImageTk.PhotoImage(settingsIcon)
settingsIcon_label= Label(image=settingsIcon)
settingsIcon_label.image = settingsIcon
settingsButton = Button(homeScreen, height = 60, width = 60, relief = 'flat', image=settingsIcon, bg = '#26FB58', command = lambda:[disableHomeScreenButtons(),Settings()])
settingsButton.place(x = 670, y = 5)

levelSelectionScreenButton = Button(canvas, width = 27, text = "LEVEL SELECTION", fg = 'white', bg = '#FBD026', font = ('Arial','25'), command = lambda:[disableHomeScreenButtons(),levelSelection()])
levelSelectionScreenButton.place(x = 360, y = 360, anchor = CENTER)

practiceLevelButton = Button(canvas, width = 27, text = "PRACTICE", fg = 'white', bg = '#26A6FB', font = ('Arial','25'), command = lambda:[disableHomeScreenButtons(),gamePractice()])
practiceLevelButton.place(x = 360, y = 435, anchor = CENTER)

quitButton = Button(canvas, width = 27, text = "QUIT", fg = 'white', bg = '#FB2626', font = ('Arial','25'), command = lambda:[homeScreen.destroy(),stop()])
quitButton.place(x = 360, y = 510, anchor = CENTER)

runLevelSelection = False
endGame1 = False
endGame2 = True



homeScreen.mainloop()
