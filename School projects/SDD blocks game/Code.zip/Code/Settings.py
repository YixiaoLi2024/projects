from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
import pygame
settingsScreen = Tk()
settingsScreen.geometry("400x400")
settingsScreen.configure(bg = '#FFFF00')

pygame.mixer.init()
pygame.mixer.music.load("Wings of Liberty Main Theme.MP3")
pygame.mixer.music.play(loops=-1)

def switchMusicButtons():
    global music
    global musicButtonText
    if music == ON:
        music = OFF
        stop()
        musicButtonText.destroy()
        musicButton.configure(bg = '#FFFFFF')
        musicButton.place(x = 300, y = 100, anchor = CENTER)
        musicButtonText = Label(settingsScreen, text="OFF", fg = 'black', bg = '#FFFF00', font = ('Arial','20'))
        musicButtonText.place(x = 350, y = 100, anchor = CENTER)
    else:
        music = ON
        play()
        musicButtonText.destroy()
        musicButton.configure(bg = '#AAAAAA')
        musicButton.place(x = 300, y = 100, anchor = CENTER)
        musicButtonText = Label(settingsScreen, text="ON", fg = 'black', bg = '#FFFF00', font = ('Arial','20'))
        musicButtonText.place(x = 350, y = 100, anchor = CENTER)
def play():
    pygame.mixer.music.load("Wings of Liberty Main Theme.MP3")
    pygame.mixer.music.play(loops=-1)

def stop():
    pygame.mixer.music.stop()

Title = Label(settingsScreen, text = "SETTINGS", fg = 'black', bg = '#FFFF00', font = ('Algerian','30'))
Title.place(x = 200, y = 40, anchor = CENTER)

musicSettings = Label(settingsScreen, text = "Music:", fg = 'black', bg = '#FFFF00', font = ('Arial','10'))
musicSettings.place(x = 100, y = 100, anchor = CENTER)

musicButton = Button(settingsScreen, height = 1, width = 5, relief = "flat", fg = 'black', bg = '#AAAAAA', command = switchMusicButtons)
musicButton.place(x = 300, y = 100, anchor = CENTER)

musicButtonText = Label(settingsScreen, text="ON", fg = 'black', bg = '#FFFF00', font = ('Arial','20'))
musicButtonText.place(x = 350, y = 100, anchor = CENTER)

music = ON

settingsScreen.mainloop()
