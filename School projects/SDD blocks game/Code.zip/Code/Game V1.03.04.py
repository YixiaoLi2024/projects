from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
top = Tk()
top.geometry("740x800")
top.configure(bg = '#068C83')
for i in range(1,16):
    for j in range(3,33):
        frame = Frame(top, height = 20, width = 20, bg = 'black')
        frame.grid(column = i, row = j)

levelFrame = Frame(top, height = 50, width = 800, bg = '#9FEA7F')
levelFrame.place(x = 0, y = 0)

frame = Frame(top, height = 50, width = 20, bg = '#9FEA7F')
frame.grid(column = 0, row = 0, padx=100)

frame = Frame(top, height = 30, width = 20, bg = '#068C83')
frame.grid(column = 0, row = 1, padx=100)

frame = Frame(top, height = 40, width = 20, bg = '#068C83')
frame.grid(column = 0, row = 2, padx=100)

requiredScoreFrame = Frame(top, height = 100, width = 150, bg = 'black')
requiredScoreFrame.place(x = 60, y = 120)

nextPieceFrame = Frame(top, height = 100, width = 150, bg = 'black')
nextPieceFrame.place(x = 60, y = 230)

swapPieceFrame = Frame(top, height = 100, width = 150, bg = 'black')
swapPieceFrame.place(x = 60, y = 340)

fiveBlockFrame = Frame(top, height = 270, width = 150, bg = 'black')
fiveBlockFrame.place(x = 60, y = 450)

requiredLinesFrame = Frame(top, height = 100, width = 150, bg = 'black')
requiredLinesFrame.place(x = 530, y = 120)

scoreFrame = Frame(top, height = 100, width = 150, bg = 'black')
scoreFrame.place(x = 530, y = 230)

lineClearsFrame = Frame(top, height = 100, width = 150, bg = 'black')
lineClearsFrame.place(x = 530, y = 340)

fourBlockFrame = Frame(top, height = 270, width = 150, bg = 'black')
fourBlockFrame.place(x = 530, y = 450)

timeFrame = Frame(top, height = 40, width = 300, bg = 'white')
timeFrame.place(x = 220, y = 80)

exitFrame = Frame(top, height = 40, width = 80, bg = 'white')
exitFrame.place(x = 60, y = 740)

levelFrame = Label(levelFrame, text = "Level 1", fg = 'black', bg = '#9FEA7F', font = ('Algerian','30'))
levelFrame.place(x = 400, y = 24, anchor = CENTER)

requiredScoreFrame = Label(requiredScoreFrame, text = "Required \n Score", fg = 'white', bg = 'black', font = ('calibri','20'))
requiredScoreFrame.place(x = 75, y = 30, anchor = CENTER)

nextPieceFrame = Label(nextPieceFrame, text = "Next", fg = 'white', bg = 'black', font = ('calibri','20'))
nextPieceFrame.place(x = 75, y = 10, anchor = CENTER)

swapPieceFrame = Label(swapPieceFrame, text = "Swap", fg = 'white', bg = 'black', font = ('calibri','20'))
swapPieceFrame.place(x = 75, y = 10, anchor = CENTER)

fiveBlocks = Label(fiveBlockFrame, text = "5 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
fiveBlocks.place(x = 75, y = 10, anchor = CENTER)

requiredLinesFrame = Label(requiredLinesFrame, text = "Required \n Lines", fg = 'white', bg = 'black', font = ('calibri','20'))
requiredLinesFrame.place(x = 75, y = 30, anchor = CENTER)

scoreFrame = Label(scoreFrame, text = "Score", fg = 'white', bg = 'black', font = ('calibri','20'))
scoreFrame.place(x = 75, y = 10, anchor = CENTER)

lineClearsFrame = Label(lineClearsFrame, text = "Line Clears", fg = 'white', bg = 'black', font = ('calibri','20'))
lineClearsFrame.place(x = 75, y = 10, anchor = CENTER)

fourBlockFrame = Label(fourBlockFrame, text = "4 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
fourBlockFrame.place(x = 75, y = 10, anchor = CENTER)

timeFrame = Label(timeFrame, text = "Time: 15:00", fg = 'black', bg = 'white', font = ('calibri','20'))
timeFrame.place(x = 150, y = 10, anchor = CENTER)

exitFrame = Label(exitFrame, text = "Exit", fg = 'black', bg = 'white', font = ('calibri','20'))
exitFrame.place(x = 40, y = 10, anchor = CENTER)

def Time():
    global minutes
    global seconds
    if minutes == 0 and seconds == 0:
        print("gameover")
    else:
        if seconds == 0:
            minutes = minutes - 1
            seconds = 59
        else:
            seconds = seconds - 1
        if seconds < 10:
            secondsText = "0" + str(seconds)
        else:
            secondsText = str(seconds)
        timeFrame.config(text = "Time: " + str(minutes) + ":" + secondsText)
        timeFrame.after(1000,Time)
    

rotationPosition = [[[[3,8], [3,9], [4,8], [4,9]]], [[[3,7], [3,8], [3,9], [4,7]], [[2,8], [3,8], [4,8], [4,9]], [[2,9], [3,7], [3,8], [3,9]],
                    [[2,7], [2,8], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,9]], [[2,8], [2,9], [3,8], [4,8]], [[2,7], [3,7], [3,8], [3,9]],
                    [[2,8], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [4,8]], [[2,8], [3,8], [3,9], [4,8]], [[2,8], [3,7], [3,8], [3,9]],
                    [[2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [4,8], [4,9]], [[2,9], [3,8], [3,9], [4,8]]], [[[3,8], [3,9], [4,7], [4,8]],
                    [[2,7], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [3,10]], [[1,9], [2,9], [3,9], [4,9]]], [[[3,7], [3,8], [3,9], [4,8], [5,8]],
                    [[2,8], [3,8], [3,9], [3,10], [4,8]], [[1,8], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,6], [3,7], [3,8], [4,8]]],
                    [[[3,7], [3,8], [3,9], [4,7], [4,8]], [[2,8], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,7], [3,8], [3,9]],
                    [[2,7], [2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,8], [3,9], [4,8]],
                    [[2,7], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,7], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [3,10], [4,7]],
                    [[1,9], [2,9], [3,9], [4,9], [4,10]], [[2,10], [3,7], [3,8], [3,9], [3,10]], [[1,8], [1,9], [2,9], [3,9], [4,9]]],
                    [[[3,7], [3,8], [3,9], [3,10], [4,10]], [[1,9], [1,10], [2,9], [3,9], [4,9]], [[2,7], [3,7], [3,8], [3,9], [3,10]],
                    [[1,9], [2,9], [3,9], [4,8], [4,9]]], [[[3,6], [3,7], [3,8], [3,9], [3,10]], [[1,8], [2,8], [3,8], [4,8], [5,8]]], [[[3,8]]], [[[3,8]]],
                    [[[3,8]]]]
#spawns right to left then up to down
#1-4 piece O shape, 2-4 piece L shape, 3-4 piece J shape, 4-4 piece T shape, 5-4 piece Z shape, 6-4 piece S shape, 7-4 piece I shape
#8-5 piece T shape, 9-5 piece b shape, 10-5 piece d shape, 11-5 piece L shape, 12-5 piece J shape, 13-5 piece I piece
#14-vertical lightning powerup, 15-5x5 bomb powerup, 16-3x9 nuke powerup
#anti-clockwise
#[Y,X]

blockColour = ["#FF9900", "#0022FF", "#FF00EC", "#00E6FF", "#FFEC00", "#86FF00", "#FF0000", "#610034", "#00734D", "#2E6000", "#2A00B8", "#5200A5", "#660000",
               "LIGHTNING.png", "BOMB.png", "NUKE.png"]
#colour of each piece type
filledBlocks = []
newFilledBlocks = []
testFilledBlocks = []
filledBlocksVerticalLinesList = []
filledBlocksHorizontalLinesList = []
lineClearList = []
activeFrameList = []
stableFrameList = []
for i in range(0,33):
    filledBlocksVerticalLinesList.append([])
for i in range(0,15):
    filledBlocksHorizontalLinesList.append([])

def sortFilledBlocks():
    global filledBlocks
    global testFilledBlocks
    for i in range(0,len(testFilledBlocks)):
        filledBlocksVerticalLinesList[testFilledBlocks[i][0] - 3].append(testFilledBlocks[i])
        filledBlocksHorizontalLinesList[testFilledBlocks[i][1] - 1].append(testFilledBlocks[i])
    testFilledBlocks = []

def checkLineClear():
    global filledBlocksVerticalLinesList
    global filledBlocksHorizontalLinesList
    global lineClearList
    global newFilledBlocks
    global filledBlocks
    global testFilledBlocks
    for i in range(0,30):
        if len(filledBlocksVerticalLinesList[i]) == 15:
            lineClearList.append(filledBlocksVerticalLinesList[i][0][0])
    if lineClearList != []:
        for i in range(0,len(filledBlocks)):
            stableFrameList[0].destroy()
            stableFrameList.pop(0)
    for i in range(0,len(lineClearList)):
        for k in range(0,len(filledBlocks)):
            if filledBlocks[k][0] > lineClearList[i]:
                newFilledBlocks.append(filledBlocks[k])
            if filledBlocks[k][0] < lineClearList[i]:
                newFilledBlocks.append([filledBlocks[k][0] + 1,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3],filledBlocks[k][4]])
        filledBlocks = newFilledBlocks
        newFilledBlocks = []
    if lineClearList != []:
        lineClearImage()
        for i in range(0,len(filledBlocks)):
            testFilledBlocks.append(filledBlocks[i])
        filledBlocksVerticalLinesList = []
        filledBlocksHorizontalLinesList = []
        for i in range(0,33):
            filledBlocksVerticalLinesList.append([])
        for i in range(0,15):
            filledBlocksHorizontalLinesList.append([])
        sortFilledBlocks()
    lineClearList = []

def newPiece():
    global Xpiece
    global Ypiece
    global startPiece
    global rotationPositionNumber
    global pieceBlocks
    global rotationNumber
    global blockColour
    Xpiece = 0 #the piece's horizontal distance moved 
    Ypiece = 0 #the piece's vertical distance moved
    if press == False:
        startPiece = random.randint(0,15) #type of piece:
    else:
        startPiece = 15
    rotationPositionNumber = 0
    pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
    rotationNumber = len(rotationPosition[startPiece])
    blockImage()

def left(event):
    global Xpiece
    global Ypiece
    global rotationPositionNumber
    global pieceBlocks
    global leftActive
    testXpiece = Xpiece - 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece < 1:
            pieceInGrid = False
    for j in range(0,len(filledBlocks)):
        for i in range(0,pieceBlocks):
            if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece:
                if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece:
                    pieceInGrid = False
    if pieceInGrid == True:
        if gravityActive == False and leftActive == False:
            leftActive = True
            Xpiece = Xpiece - 1
            for i in range(0,pieceBlocks):
                activeFrameList[0].destroy()
                activeFrameList.pop(0)
            blockImage()
            leftActive = False

def right(event):
    global Xpiece
    global Ypiece
    global rotationPositionNumber
    global pieceBlocks
    global rightActive
    testXpiece = Xpiece + 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece > 15:
            pieceInGrid = False
    for j in range(0,len(filledBlocks)):
        for i in range(0,pieceBlocks):
            if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece:
                if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + testXpiece:
                    pieceInGrid = False
    if pieceInGrid == True:
        if gravityActive == False and rightActive == False:
            rightActive = True
            Xpiece = Xpiece + 1
            for i in range(0,pieceBlocks):
                activeFrameList[0].destroy()
                activeFrameList.pop(0)
            blockImage()
            rightActive = False

def up(event):
    global rotationPositionNumber
    global Xpiece
    global Ypiece
    global pieceBlocks
    global rotationNumber
    global rotationActive
    pieceInGrid = True
    testRotationPositionNumber = rotationPositionNumber
    testRotationPositionNumber = testRotationPositionNumber + 1
    if testRotationPositionNumber == rotationNumber:
        testRotationPositionNumber = 0
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece > 15:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece < 1:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece > 32:
            pieceInGrid = False
        if rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece < 3:
            pieceInGrid = False
    for j in range(0,len(filledBlocks)):
        for i in range(0,pieceBlocks):
            if filledBlocks[j][0] == rotationPosition[startPiece][testRotationPositionNumber][i][0] + Ypiece:
                if filledBlocks[j][1] == rotationPosition[startPiece][testRotationPositionNumber][i][1] + Xpiece:
                    pieceInGrid = False
    if pieceInGrid == True:
        if gravityActive == False and rotationActive == False:
            rotationActive = True
            for i in range(0,pieceBlocks):
                activeFrameList[0].destroy()
                activeFrameList.pop(0)
            rotationPositionNumber = rotationPositionNumber + 1
            if rotationPositionNumber == rotationNumber:
                rotationPositionNumber = 0
            blockImage()
            rotationActive = False

def downPress(event):
    global gameDown
    global pressDown
    global pressOnce
    global drop
    global userDown
    global runGravity
    pressDown = True
    checkGravity()
    
def downRelease(event):
    global gameDown
    global pressDown
    global pressOnce
    pressDown = False
    checkGravity()
    
def shift(event):
    global press
    press = False
def shift1(event):
    global press
    press = True

def checkGravity():
    global pressDown
    global drop
    global speed
    global checkGravityActive
    global downTimer
    if checkGravityActive == False:
        if pressDown == True:
            drop = 0.05
            speed = 0.04
            downTimer.cancel()
            checkGravityActive = True
            gravity()
    if pressDown == False:
        drop = 1
        speed = 0.8
        downTimer.cancel()
        checkGravityActive = True
        gravity()
    
def gravity():
    global Ypiece
    global dropTimer
    global gameDown
    global userDown
    global pressDown
    global pressOnce
    global drop
    global runGravity
    global downTimer
    global speed
    global checkGravityActive
    global rotationPositionNumber
    global pieceBlocks
    global testFilledBlocks
    global leftActive
    global rightActive
    global rotationActive
    global gravityActive
    global moveGravity
    global pieceInGrid
    start = time.time()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()
    if time.time() - dropTimer > speed:
        testYpiece = Ypiece + 1
        pieceInGrid = True
        for i in range(0,pieceBlocks):
            if rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece > 32:
                pieceInGrid = False
        for j in range(0,len(filledBlocks)):
            for i in range(0,pieceBlocks):
                if filledBlocks[j][0] == rotationPosition[startPiece][rotationPositionNumber][i][0] + testYpiece:
                    if filledBlocks[j][1] == rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece:
                        pieceInGrid = False
        if pieceInGrid == True:
            moveGravity = True
            while moveGravity == True:
                if gravityActive == False and leftActive == False and rightActive == False and rotationActive == False:
                    gravityActive = True
                    Ypiece = Ypiece + 1
                    for i in range(0,pieceBlocks):
                        activeFrameList[0].destroy()
                        activeFrameList.pop(0)
                    blockImage()
                    gravityActive = False
                    moveGravity = False
        else:
            checkPieceType = False
            if startPiece < 13:
                polyomino()
                checkPieceType = True
            if checkPieceType == False:
                if startPiece == 13:
                    lightningPowerUp()
                    checkPieceType = True
            if checkPieceType == False:
                if startPiece == 14:
                    bombPowerUp()
                    checkPieceType = True
            if checkPieceType == False:
                if startPiece == 15:
                    nukePowerUp()
        dropTimer = time.time()
    checkGravityActive = False

def blockImage():
    global startPiece
    global pieceBlocks
    global activeFrameList
    global rotationPositionNumber
    global Xpiece
    global Ypiece
    global blockColour
    global powerUpImage
    if startPiece < 13:
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
            activeFrameList.append(frame)
    if startPiece > 12:
        frame = Frame(top, height = 20, width = 20, relief = 'solid', bg = 'black')
        frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece)
        powerUpImage = Image.open(blockColour[startPiece])
        powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
        powerUpImage = ImageTk.PhotoImage(powerUpImage)
        powerUpImage_label= Label(image=powerUpImage)
        powerUpImage_label.image = powerUpImage
        frameImage = Label(master=frame, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
        frameImage.grid()
        activeFrameList.append(frame)

def lineClearImage():
    global startPiece
    global pieceBlocks
    global activeFrameList
    global rotationPositionNumber
    global Xpiece
    global Ypiece
    global blockColour
    global powerUpImage
    for i in range(0,len(filledBlocks)):
        if filledBlocks[i][3] == "polyomino":
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = filledBlocks[i][2])
            frame.grid(column = filledBlocks[i][1], row = filledBlocks[i][0])
            stableFrameList.append(frame)
        else:
            frame = Frame(top, height = 20, width = 20, relief = 'solid', bg = 'black')
            frame.grid(column = filledBlocks[i][1], row = filledBlocks[i][0])
            powerUpImage = Image.open(filledBlocks[i][2])
            powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
            powerUpImage = ImageTk.PhotoImage(powerUpImage)
            powerUpImage_label= Label(image=powerUpImage)
            powerUpImage_label.image = powerUpImage
            frameImage = Label(master=frame, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
            frameImage.grid()
            stableFrameList.append(frame)
        
def polyomino():
    global pieceInGrid
    global moveGravity
    global leftActive
    global rightActive
    global rotationActive
    global gravityActive
    global Ypiece
    global pieceBlocks
    global activeFrameList
    global filledBlocks
    global testFilledBlocks
    global stableFrameList
    global activeFrameList
    global downTimer
    global dropTimer
    global pieceType
    moveGravity = True
    while moveGravity == True:
        if gravityActive == False and leftActive == False and rightActive == False and rotationActive == False:
            gravityActive = True
            downTimer.cancel()
            for i in range(0,pieceBlocks):
                if startPiece < 13:
                    pieceType = "polyomino"
                else:
                    pieceType = "powerUp"
                filledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece,blockColour[startPiece],pieceType,activeFrameList[0]])
                testFilledBlocks.append([rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece,rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece,blockColour[startPiece],pieceType,activeFrameList[0]])
                stableFrameList.append(activeFrameList[0])
                activeFrameList.pop(0)
            sortFilledBlocks()
            checkLineClear()
            newPiece()
            downTimer = threading.Timer(drop, checkGravity)
            downTimer.start()
            gravityActive = False
            moveGravity = False

def lightningPowerUp():
    global filledBlocks
    global testFilledBlocks
    global filledBlocksHorizontalLinesList
    global filledBlocksVerticalLinesList
    global stableFrameList
    global downTimer
    downTimer.cancel()
    activeFrameList[0].destroy()
    activeFrameList.pop(0)
    for i in range(0,len(filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1])):
        filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1][i][4].destroy()
    filledBlocksHorizontalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 1] = []
    for i in range(0,len(filledBlocks)):
        stableFrameList[0].destroy()
        stableFrameList.pop(0)
    for i in range(0,15):
        for j in range(0,len(filledBlocksHorizontalLinesList[i])):
            testFilledBlocks.append(filledBlocksHorizontalLinesList[i][j])
    filledBlocksVerticalLinesList = []
    filledBlocksHorizontalLinesList = []
    for i in range(0,33):
        filledBlocksVerticalLinesList.append([])
    for i in range(0,15):
        filledBlocksHorizontalLinesList.append([])
    filledBlocks = []
    for i in range(0,len(testFilledBlocks)):
        filledBlocks.append(testFilledBlocks[i])
    lineClearImage()
    sortFilledBlocks()
    newPiece()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()

def bombPowerUp():
    global filledBlocks
    global testFilledBlocks
    global filledBlocksHorizontalLinesList
    global filledBlocksVerticalLinesList
    global stableFrameList
    global downTimer
    global newFilledBlocks
    downTimer.cancel()
    activeFrameList[0].destroy()
    activeFrameList.pop(0)
    for j in range(-2,3):
        for i in range(0,len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j])):
            if filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][1] > rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 3 and filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][1] < rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece + 3:
                filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][4].destroy()
                filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i] = []
    for i in range(0,len(filledBlocks)):
        stableFrameList[0].destroy()
        stableFrameList.pop(0)
    for i in range(0,30):
        for j in range(0,len(filledBlocksVerticalLinesList[i])):
            if filledBlocksVerticalLinesList[i][j] != []:
                testFilledBlocks.append(filledBlocksVerticalLinesList[i][j])
    filledBlocks = []
    for i in range(0,len(testFilledBlocks)):
        filledBlocks.append(testFilledBlocks[i])
    testFilledBlocks = []
    for k in range(0,len(filledBlocks)):
        if filledBlocks[k][0] < rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 2:
            if filledBlocks[k][1] > rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece - 3 and filledBlocks[k][1] < rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece + 3:
                if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece + 2 <= 32:
                    newFilledBlocks.append([filledBlocks[k][0] + 5,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3],filledBlocks[k][4]])
                else:
                    newFilledBlocks.append([filledBlocks[k][0] + 32 - (rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3),filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3],filledBlocks[k][4]])
        else:
            newFilledBlocks.append(filledBlocks[k])
    filledBlocks = newFilledBlocks
    newFilledBlocks = []
    lineClearImage()
    for i in range(0,len(filledBlocks)):
        testFilledBlocks.append(filledBlocks[i])
    filledBlocksVerticalLinesList = []
    filledBlocksHorizontalLinesList = []
    for i in range(0,33):
        filledBlocksVerticalLinesList.append([])
    for i in range(0,15):
        filledBlocksHorizontalLinesList.append([])
    sortFilledBlocks()
    newPiece()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()

def nukePowerUp():
    global filledBlocks
    global testFilledBlocks
    global filledBlocksHorizontalLinesList
    global filledBlocksVerticalLinesList
    global stableFrameList
    global downTimer
    global newFilledBlocks
    downTimer.cancel()
    activeFrameList[0].destroy()
    activeFrameList.pop(0)
    for j in range(-1,2):
        for i in range(0,len(filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j])):
            filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i][4].destroy()
            filledBlocksVerticalLinesList[rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 3 + j][i] = []
    for i in range(0,len(filledBlocks)):
        stableFrameList[0].destroy()
        stableFrameList.pop(0)
    for i in range(0,30):
        for j in range(0,len(filledBlocksVerticalLinesList[i])):
            if filledBlocksVerticalLinesList[i][j] != []:
                testFilledBlocks.append(filledBlocksVerticalLinesList[i][j])
    filledBlocks = []
    for i in range(0,len(testFilledBlocks)):
        filledBlocks.append(testFilledBlocks[i])
    testFilledBlocks = []
    for k in range(0,len(filledBlocks)):
        if filledBlocks[k][0] < rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 1:
            if rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece + 1 <= 32:
                newFilledBlocks.append([filledBlocks[k][0] + 3,filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3],filledBlocks[k][4]])
            else:
                newFilledBlocks.append([filledBlocks[k][0] + 32 - (rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece - 2),filledBlocks[k][1],filledBlocks[k][2],filledBlocks[k][3],filledBlocks[k][4]])
        else:
            newFilledBlocks.append(filledBlocks[k])
    filledBlocks = newFilledBlocks
    newFilledBlocks = []
    lineClearImage()
    for i in range(0,len(filledBlocks)):
        testFilledBlocks.append(filledBlocks[i])
    filledBlocksVerticalLinesList = []
    filledBlocksHorizontalLinesList = []
    for i in range(0,33):
        filledBlocksVerticalLinesList.append([])
    for i in range(0,15):
        filledBlocksHorizontalLinesList.append([])
    sortFilledBlocks()
    newPiece()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()

def Start():
    global start
    global destroy
    global startNumber
    startNumber.destroy()
    start = start - 1
    if destroy == False:
        if start > 0:
            startNumber = Label(top, text = start, fg = 'white', bg = 'black', font = ('calibri','100'))
            startNumber.place(x = 370, y = 400, anchor = CENTER)
            top.after(1000,Start)
        else:
            startNumber = Label(top, text = "start", fg = 'white', bg = 'black', font = ('calibri','100'))
            startNumber.place(x = 370, y = 400, anchor = CENTER)
            destroy = True
            top.after(1000,Start)
    else:
        top.bind("<KeyPress-Down>", downPress)
        top.bind("<KeyRelease-Down>", downRelease)

minutes = 15
seconds = 0
timeFrame.after(5000,Time)
press = False
leftActive = False
rightActive = False
rotationActive = False
gravityActive = False
moveGravity = False
newPiece()
checkGravityActive = False
pressDown = False
dropTimer = time.time()
drop = 1
speed = 0.9
top.after(5000,gravity)
destroy = False
start = 3
startNumber = Label(top, text = start, fg = 'white', bg = 'black', font = ('calibri','100'))
startNumber.place(x = 370, y = 400, anchor = CENTER)
top.after(2000,Start)
top.bind("<Shift_L>", shift)
top.bind("<Shift_R>", shift1)
top.bind("<Left>", left)
top.bind("<Right>", right)
top.bind("<KeyRelease-Up>", up)
         
top.mainloop()

