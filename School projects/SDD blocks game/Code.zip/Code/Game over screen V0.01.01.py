from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
gameOverScreen = Tk()
gameOverScreen.geometry("400x400")
gameOverScreen.configure(bg = 'red')

canvas = Canvas(gameOverScreen, width = 400, height = 400, bg="red")
canvas.pack()

Title = Label(gameOverScreen, text = "GAME OVER", fg = 'black', bg = 'red', font = ('Algerian','50'))
Title.place(x = 200, y = 100, anchor = CENTER)

loseReason = "You lost by time out"

Reason = Label(gameOverScreen, text = loseReason, fg = 'black', bg = 'red', font = ('Calibri','20'))
Reason.place(x = 200, y = 160, anchor = CENTER)

score = "you got a score of " + str("000332")
Score = Label(gameOverScreen, text = score, fg = 'black', bg = 'red', font = ('Calibri','20'))
Score.place(x = 200, y = 200, anchor = CENTER)

circle=canvas.create_rectangle(10, 350, 140, 390, fill = '#D90101')

levelSelectionButton = Label(canvas, text = "LEVEL SELECTION", fg = 'white', bg = '#D90101', font = ('Arial','10'))
levelSelectionButton.place(x = 75, y = 370, anchor = CENTER)

circle=canvas.create_rectangle(260, 350, 390, 390, fill = '#D90101')

levelSelectionButton = Label(canvas, text = "TRY AGAIN", fg = 'white', bg = '#D90101', font = ('Arial','10'))
levelSelectionButton.place(x = 325, y = 370, anchor = CENTER)

gameOverScreen.mainloop()
