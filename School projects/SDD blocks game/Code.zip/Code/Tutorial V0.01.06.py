from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
top = Tk()
top.geometry("740x800")
top.configure(bg = '#068C83')


#setup grid and lists
for i in range(1,16):
    for j in range(3,33):
        frame = Frame(top, height = 20, width = 20, bg = 'black')
        frame.grid(column = i, row = j)#setup the grid

levelFrame = Frame(top, height = 50, width = 800, bg = '#9FEA7F')
levelFrame.place(x = 0, y = 0)#the title box

frame = Frame(top, height = 50, width = 20, bg = '#9FEA7F')
frame.grid(column = 0, row = 0, padx=100)

frame = Frame(top, height = 30, width = 20, bg = '#068C83')
frame.grid(column = 0, row = 1, padx=100)

frame = Frame(top, height = 40, width = 20, bg = '#068C83')
frame.grid(column = 0, row = 2, padx=100)#3 placeholder frames (for making the grid system work) that are the same colour as the background image so users won't know the frames are there

requiredScoreFrame = Frame(top, height = 100, width = 150, bg = 'black')
requiredScoreFrame.place(x = 60, y = 120)

nextPieceFrame = Frame(top, height = 100, width = 150, bg = 'black')
nextPieceFrame.place(x = 60, y = 230)

swapPieceFrame = Frame(top, height = 100, width = 150, bg = 'black')
swapPieceFrame.place(x = 60, y = 340)

fiveBlockFrame = Frame(top, height = 270, width = 150, bg = 'black')
fiveBlockFrame.place(x = 60, y = 450)

requiredLinesFrame = Frame(top, height = 100, width = 150, bg = 'black')
requiredLinesFrame.place(x = 530, y = 120)

scoreFrame = Frame(top, height = 100, width = 150, bg = 'black')
scoreFrame.place(x = 530, y = 230)

lineClearsFrame = Frame(top, height = 100, width = 150, bg = 'black')
lineClearsFrame.place(x = 530, y = 340)

fourBlockFrame = Frame(top, height = 270, width = 150, bg = 'black')
fourBlockFrame.place(x = 530, y = 450)

timeFrame = Frame(top, height = 40, width = 300, bg = 'white')
timeFrame.place(x = 220, y = 80)

exitFrame = Frame(top, height = 40, width = 80, bg = 'white')
exitFrame.place(x = 60, y = 740)

level = Label(levelFrame, text = "TUTORIAL", fg = 'black', bg = '#9FEA7F', font = ('Algerian','30'))
level.place(x = 400, y = 24, anchor = CENTER)

#requiredScore = Label(requiredScoreFrame, text = "Required \n Score \n 010000", fg = 'white', bg = 'black', font = ('calibri','20'))
#requiredScore.place(x = 75, y = 45, anchor = CENTER)

#nextPiece = Label(nextPieceFrame, text = "Next", fg = 'white', bg = 'black', font = ('calibri','20'))
#nextPiece.place(x = 75, y = 10, anchor = CENTER)

#swapPiece = Label(swapPieceFrame, text = "Swap", fg = 'white', bg = 'black', font = ('calibri','20'))
#swapPiece.place(x = 75, y = 10, anchor = CENTER)

#fiveBlocks = Label(fiveBlockFrame, text = "5 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
#fiveBlocks.place(x = 75, y = 10, anchor = CENTER)

#requiredLines = Label(requiredLinesFrame, text = "Required \n Lines \n 000", fg = 'white', bg = 'black', font = ('calibri','20'))
#requiredLines.place(x = 75, y = 45, anchor = CENTER)

#score = Label(scoreFrame, text = "Score", fg = 'white', bg = 'black', font = ('calibri','20'))
#score.place(x = 75, y = 10, anchor = CENTER)

#scoreNumber = Label(scoreFrame, text = "000000", fg = 'white', bg = 'black', font = ('calibri','20'))
#scoreNumber.place(x = 75, y = 50, anchor = CENTER)

#lineClears = Label(lineClearsFrame, text = "Line Clears", fg = 'white', bg = 'black', font = ('calibri','20'))
#lineClears.place(x = 75, y = 10, anchor = CENTER)

#lineClearsNumber = Label(lineClearsFrame, text = "000", fg = 'white', bg = 'black', font = ('calibri','20'))
#lineClearsNumber.place(x = 75, y = 50, anchor = CENTER)

#fourBlock = Label(fourBlockFrame, text = "4 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
#fourBlock.place(x = 75, y = 10, anchor = CENTER)

#timeLabel = Label(timeFrame, text = "Time: 15:00", fg = 'black', bg = 'white', font = ('calibri','20'))
#timeLabel.place(x = 150, y = 10, anchor = CENTER)

Exit = Label(exitFrame, text = "Exit", fg = 'black', bg = 'white', font = ('calibri','20'))
Exit.place(x = 40, y = 10, anchor = CENTER)

tutorialFrame = Frame(top, height = 200, width = 200, bg = '#EFF077')
tutorialFrame.place(x = 370, y = 400, anchor = CENTER)#the title box


rotationPosition = [[[[3,8], [3,9], [4,8], [4,9]]], [[[3,7], [3,8], [3,9], [4,7]], [[2,8], [3,8], [4,8], [4,9]], [[2,9], [3,7], [3,8], [3,9]],
                    [[2,7], [2,8], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,9]], [[2,8], [2,9], [3,8], [4,8]], [[2,7], [3,7], [3,8], [3,9]],
                    [[2,8], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [4,8]], [[2,8], [3,8], [3,9], [4,8]], [[2,8], [3,7], [3,8], [3,9]],
                    [[2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [4,8], [4,9]], [[2,9], [3,8], [3,9], [4,8]]], [[[3,8], [3,9], [4,7], [4,8]],
                    [[2,7], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [3,10]], [[1,9], [2,9], [3,9], [4,9]]], [[[3,7], [3,8], [3,9], [4,8], [5,8]],
                    [[2,8], [3,8], [3,9], [3,10], [4,8]], [[1,8], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,6], [3,7], [3,8], [4,8]]],
                    [[[3,7], [3,8], [3,9], [4,7], [4,8]], [[2,8], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,7], [3,8], [3,9]],
                    [[2,7], [2,8], [3,7], [3,8], [4,8]]], [[[3,7], [3,8], [3,9], [4,8], [4,9]], [[2,8], [2,9], [3,8], [3,9], [4,8]],
                    [[2,7], [2,8], [3,7], [3,8], [3,9]], [[2,8], [3,7], [3,8], [4,7], [4,8]]], [[[3,7], [3,8], [3,9], [3,10], [4,7]],
                    [[1,9], [2,9], [3,9], [4,9], [4,10]], [[2,10], [3,7], [3,8], [3,9], [3,10]], [[1,8], [1,9], [2,9], [3,9], [4,9]]],
                    [[[3,7], [3,8], [3,9], [3,10], [4,10]], [[1,9], [1,10], [2,9], [3,9], [4,9]], [[2,7], [3,7], [3,8], [3,9], [3,10]],
                    [[1,9], [2,9], [3,9], [4,8], [4,9]]], [[[3,6], [3,7], [3,8], [3,9], [3,10]], [[1,8], [2,8], [3,8], [4,8], [5,8]]], [[[3,8]]], [[[3,8]]],
                    [[[3,8]]]]
#spawns right to left then up to down
#1-4 piece O shape, 2-4 piece L shape, 3-4 piece J shape, 4-4 piece T shape, 5-4 piece Z shape, 6-4 piece S shape, 7-4 piece I shape
#8-5 piece T shape, 9-5 piece b shape, 10-5 piece d shape, 11-5 piece L shape, 12-5 piece J shape, 13-5 piece I piece
#14-vertical lightning powerup, 15-5x5 bomb powerup, 16-3x9 nuke powerup
#anti-clockwise
#[Y,X]

blockColour = ["#FF9900", "#0022FF", "#FF00EC", "#00E6FF", "#FFEC00", "#86FF00", "#FF0000", "#610034", "#00734D", "#2E6000", "#2A00B8", "#5200A5", "#660000",
               "LIGHTNING.png", "BOMB.png", "NUKE.png"]
#colour of each piece type
Xlength = [0,1,1,1,1,1,0,1,1,1,0,0,1,1,1,1]
filledBlocks = []
newFilledBlocks = []
testFilledBlocks = []
filledBlocksVerticalLinesList = []
filledBlocksHorizontalLinesList = []
lineClearList = []
activeFrameList = []
stableFrameList = []
newPieceList = []
nextPieceFrameList = []
swapPieceList = [[],[]]
swapPieceBlocksList = []
statsPiece = [["OPiece",0],["LPiece",0],["JPiece",0],["TPiece",0],["ZPiece",0],["SPiece",0],["IPiece",0],["5TPiece",0],["5BPiece",0],["5DPiece",0],["5LPiece",0],["5JPiece",0],["5IPiece",0]]
for i in range(0,33):
    filledBlocksVerticalLinesList.append([])
for i in range(0,15):
    filledBlocksHorizontalLinesList.append([])

def addStats():
    global fiveBlockFrame
    global fourBlockFrame
    fiveBlocks = Label(fiveBlockFrame, text = "5 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
    fiveBlocks.place(x = 75, y = 10, anchor = CENTER)
    fourBlock = Label(fourBlockFrame, text = "4 Blocks", fg = 'white', bg = 'black', font = ('calibri','20'))
    fourBlock.place(x = 75, y = 10, anchor = CENTER)
    for j in range(0,7):
        for i in range(0,4):
            frame = Frame(top, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
            frame.place(x = 560 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 33 * j, anchor = E)
    for j in range(7,13):
        for i in range(0,5):
            frame = Frame(top, height = 10, width = 10, borderwidth = 1, relief = 'solid', bg = blockColour[j])
            frame.place(x = 100 + (rotationPosition[j][0][i][1] - 8) * 10, y = 500 + (rotationPosition[j][0][i][0] - 3) * 10 + 40 * (j - 7), anchor = E)
    for i in range(0,7):
        statsPiece[i][0] = Label(top, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
        statsPiece[i][0].place(x = 650, y = 500 + 33 * i, anchor = CENTER)
    for i in range(7,13):
        statsPiece[i][0] = Label(top, text = str(statsPiece[i][1]), fg = 'white', bg = 'black', font = ('calibri','20'))
        statsPiece[i][0].place(x = 180, y = 500 + 40 * (i - 7), anchor = CENTER)


#tutorial
def Tutorial():
    global tutorialFrame
    global setTutorial
    global tutorialTitle
    global tutorialText
    global swapPieceText
    global nextPiece
    global fiveBlocks
    global fourBlock
    global score
    global scoreNumber
    global lineClears
    global lineClearsNumber
    global timeLabel
    global requiredScore
    global requiredLines
    global Xpiece
    global Ypiece
    global startPiece
    global rotationPositionNumber
    global pieceBlocks
    global rotationNumber
    global blockColour
    global swapPieceOnce
    if setTutorial == 0:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','25'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "Welcome to the \n tutorial", fg = 'black', bg = '#EFF077', font = ('calibri','20'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 1:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "You will be controlling a main \n piece with your keyboard", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        Xpiece = 0 #the piece's horizontal distance moved 
        Ypiece = 0 #the piece's vertical distance moved
        startPiece = random.randint(0,12)
        newPieceList.append(startPiece)
        newPieceList.pop(0)
        startPiece = newPieceList[0]
        rotationPositionNumber = 0
        pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece
        rotationNumber = len(rotationPosition[startPiece])
        blockImage()
        statsPiece[startPiece][1] = statsPiece[startPiece][1] + 1
    if setTutorial == 2:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "The piece must always be \n inside the grid", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 3:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "To move the piece left, press \n or hold the left arrow key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 4:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "To move the piece right, \n press or hold the right arrow \n key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 5:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "To rotate the piece \n anti-clockwise, press and \n release the up arrow key", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 6:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "The piece will slowly drop \n at a set level speed if the \n down arrow key isn't held", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 7:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "The piece will drop at the soft \n drop speed when the down \n key is held", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 8:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "You can press the left shift \n key to swap a piece if you \n have not swapped a piece \n since the piece has been \n spawned", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        swapPieceText = Label(swapPieceFrame, text = "Swap", fg = 'white', bg = 'black', font = ('calibri','20'))
        swapPieceText.place(x = 75, y = 10, anchor = CENTER)
    if setTutorial == 9:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if the block below the piece is \n a stable piece or out of the \n grid, the piece becomes a \n stable piece and you can't \n control it anymore", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 10:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if a new stable piece is created, the \n piece in the next piece box will be \n added to the grid and a randomly \n generated piece will replace the \n piece in the next piece box", fg = 'black', bg = '#EFF077', font = ('calibri','10'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        nextPiece = Label(nextPieceFrame, text = "Next", fg = 'white', bg = 'black', font = ('calibri','20'))
        nextPiece.place(x = 75, y = 10, anchor = CENTER)
    if setTutorial == 11:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "everytime a new piece is \n added, it will be added to the \n piece stats box", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        addStats()
    if setTutorial == 12:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "The two types of pieces are \n normal pieces and powerups", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 13:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "normal pieces are more \n common than powerups and \n they consists of either 4 or 5 \n blocks", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 14:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "normal pieces consists of \n either 4 or 5 blocks and they \n all have the same colour", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 15:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "powerups only consist of one \n block but they have an image", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 16:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "the lightning bolt powerup \n destroys every block in its \n column", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 17:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "the bomb powerup destroys \n every block in a 5x5 area with \n the powerup being the center", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 18:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "the nuke powerup destroys \n every block in the row above \n to the row below", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 19:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "to gain score, you can \n perform line clears \n or use powerups", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        score = Label(scoreFrame, text = "Score", fg = 'white', bg = 'black', font = ('calibri','20'))
        score.place(x = 75, y = 10, anchor = CENTER)
        scoreNumber = Label(scoreFrame, text = "000000", fg = 'white', bg = 'black', font = ('calibri','20'))
        scoreNumber.place(x = 75, y = 50, anchor = CENTER)
    if setTutorial == 20:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "when a row is fully filled with \n stable pieces, the whole row will \n disappear and all the blocks above \n the row will drop down the number \n of rows that have been cleared", fg = 'black', bg = '#EFF077', font = ('calibri','10'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        lineClears = Label(lineClearsFrame, text = "Line Clears", fg = 'white', bg = 'black', font = ('calibri','20'))
        lineClears.place(x = 75, y = 10, anchor = CENTER)
        lineClearsNumber = Label(lineClearsFrame, text = "000", fg = 'white', bg = 'black', font = ('calibri','20'))
        lineClearsNumber.place(x = 75, y = 50, anchor = CENTER)
    if setTutorial == 21:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "line clear score system: \n 1 line clear = 200 \n 2 line clear = 500 \n 3 line clear = 1000 \n 4 line clear = 3000 \n 5 line clear = 5000", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 22:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "lightning bolt powerup score system: \n 0-4 blocks = 50 x blocks destroyed \n 5-9 blocks = 100 x blocks destroyed \n 10-19 blocks = 200 x blocks destroyed \n 20-28 blocks = 300 x blocks destroyed \n 29 blocks = 15000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 23:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "bomb powerup score system: \n 0-10 blocks = 25 x blocks destroyed \n 11-14 blocks = 50 x blocks destroyed \n 15-21 blocks = 100 x blocks destroyed \n 22 blocks = 4000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 24:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "nuke powerup score system: \n 0-20 blocks = 25 x blocks destroyed \n 21-30 blocks = 50 x blocks destroyed \n 31-41 blocks = 100 x blocks destroyed \n 42 blocks = 7000", fg = 'black', bg = '#EFF077', font = ('calibri','8'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 25:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if the level timer hits 0, \n you lose the level/game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        timeLabel = Label(timeFrame, text = "Time: 15:00", fg = 'black', bg = 'white', font = ('calibri','20'))
        timeLabel.place(x = 150, y = 10, anchor = CENTER)
    if setTutorial == 26:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if the new piece spawns \n inside a stable piece, you \n also lose the game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    if setTutorial == 27:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','15'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "if you have reached the \n required score and lines \n before you have lost the \n game, you beat the \n level/game", fg = 'black', bg = '#EFF077', font = ('calibri','12'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
        requiredScore = Label(requiredScoreFrame, text = "Required \n Score \n 010000", fg = 'white', bg = 'black', font = ('calibri','20'))
        requiredScore.place(x = 75, y = 45, anchor = CENTER)
        requiredLines = Label(requiredLinesFrame, text = "Required \n Lines \n 000", fg = 'white', bg = 'black', font = ('calibri','20'))
        requiredLines.place(x = 75, y = 45, anchor = CENTER)
    if setTutorial == 28:
        tutorialTitle = Label(tutorialFrame, text = "TUTORIAL", fg = 'black', bg = '#EFF077', font = ('calibri','25'))
        tutorialTitle.place(x = 100, y = 25, anchor = CENTER)
        tutorialText = Label(tutorialFrame, text = "you have finished \n the tutorial", fg = 'black', bg = '#EFF077', font = ('calibri','20'))
        tutorialText.place(x = 100, y = 100, anchor = CENTER)
    
    #swapPiece, nextPiece, Stats, normalPiece, Powerups, scoreSystem, lineClears, Timer, loseCondition, winCondition

def tutorialImage():
    tutorialImage = Image.open("Next button.png")
    tutorialImage = tutorialImage.resize((40,40), Image.LANCZOS)
    tutorialImage = ImageTk.PhotoImage(tutorialImage)
    tutorialImage_label= Label(image=tutorialImage)
    tutorialImage_label.image = tutorialImage
    frameImage = Button(tutorialFrame, height = 40, width = 40, relief = "flat", image=tutorialImage, bg = '#EFF077', command = nextButton)
    frameImage.place(x = 170, y = 170, anchor = CENTER)
    tutorialImage = Image.open("Back button.png")
    tutorialImage = tutorialImage.resize((45,45), Image.LANCZOS)
    tutorialImage = ImageTk.PhotoImage(tutorialImage)
    tutorialImage_label= Label(image=tutorialImage)
    tutorialImage_label.image = tutorialImage
    frameImage = Button(tutorialFrame, height = 40, width = 40, relief = "flat", image=tutorialImage, bg = '#EFF077', command = backButton)
    frameImage.place(x = 30, y = 170, anchor = CENTER)

def nextButton():
    global setTutorial
    global tutorialTitle
    global tutorialText
    if setTutorial < 28:
        setTutorial = setTutorial + 1
    tutorialTitle.destroy()
    tutorialText.destroy()
    Tutorial()
    print(setTutorial)

def backButton():
    global setTutorial
    global tutorialTitle
    global tutorialText
    global swapPieceText
    global nextPiece
    global fiveBlockFrame
    global fourBlockFrame
    global score
    global scoreNumber
    global lineClears
    global lineClearsNumber
    global timeLabel
    global requiredScore
    global requiredLines
    global Xpiece
    global Ypiece
    global startPiece
    global rotationPositionNumber
    global pieceBlocks
    global rotationNumber
    global blockColour
    global swapPieceOnce
    if setTutorial == 0:
        pass
    else:
        setTutorial = setTutorial - 1
        if setTutorial == 0 or setTutorial == 1:
            deleteActiveFrames()
        if setTutorial == 7 or setTutorial == 8:
            swapPieceText.destroy()
        if setTutorial == 9 or setTutorial == 10:
            nextPiece.destroy()
        if setTutorial == 10 or setTutorial == 11:
            fiveBlockFrame = Frame(top, height = 270, width = 150, bg = 'black')
            fiveBlockFrame.place(x = 60, y = 450)
            fourBlockFrame = Frame(top, height = 270, width = 150, bg = 'black')
            fourBlockFrame.place(x = 530, y = 450)
        if setTutorial == 18 or setTutorial == 19:
            score.destroy()
            scoreNumber.destroy()
        if setTutorial == 19 or setTutorial == 20:
            lineClears.destroy()
            lineClearsNumber.destroy()
        if setTutorial == 24 or setTutorial == 25:
            timeLabel.destroy()
        if setTutorial == 26 or setTutorial == 27:
            requiredScore.destroy()
            requiredLines.destroy()
    tutorialTitle.destroy()
    tutorialText.destroy()
    Tutorial()


#setup/add info boxes/objects
def deleteActiveFrames():
    global deleteActiveFrameList
    for i in range(0,len(activeFrameList)):
        activeFrameList[0].destroy()
        activeFrameList.pop(0)
def blockImage():#updates the image of the active piece
    global startPiece
    global pieceBlocks
    global activeFrameList
    global rotationPositionNumber
    global Xpiece
    global Ypiece
    global blockColour
    global powerUpImage
    global blockImageActive
    global deleteActiveFrameList
    if activeFrameList != []:
        deleteActiveFrames()
    if startPiece < 13:
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
            frame.grid(column = rotationPosition[startPiece][rotationPositionNumber][i][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][i][0] + Ypiece)
            activeFrameList.append(frame)
    if startPiece > 12:
        powerUpImage = Image.open(blockColour[startPiece])
        powerUpImage = powerUpImage.resize((18,18), Image.LANCZOS)
        powerUpImage = ImageTk.PhotoImage(powerUpImage)
        powerUpImage_label= Label(image=powerUpImage)
        powerUpImage_label.image = powerUpImage
        frameImage = Label(top, height = 16, width = 16, relief = "solid", image=powerUpImage, bg = 'black')
        frameImage.grid(column = rotationPosition[startPiece][rotationPositionNumber][0][1] + Xpiece, row = rotationPosition[startPiece][rotationPositionNumber][0][0] + Ypiece)
        activeFrameList.append(frameImage)

#variable info + starting functions + adding objects
startPiece = random.randint(0,15)
newPieceList.append(startPiece)
setTutorial = 0
Tutorial()
tutorialImage()
top.mainloop()

