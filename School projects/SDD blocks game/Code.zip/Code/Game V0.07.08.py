from tkinter import*
from PIL import Image, ImageTk
import random
import time
from time import sleep
import threading
top = Tk()
top.geometry("800x700")
top.configure(bg = '#068C83')
for i in range(1,16):
    for j in range(1,30):
        frame = Frame(top, height = 20, width = 20, bg = 'black')
        frame.grid(column = i, row = j)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 0, row = 0, padx=100)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 2, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 3, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 4, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 5, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 6, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 7, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 8, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 9, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 10, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 11, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 12, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 13, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 14, row = 30)

frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 15, row = 30)






frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 1)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 2)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 3)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 4)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 5)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 6)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 7)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 8)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 9)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 10)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 11)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 12)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 13)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 14)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 15)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 16)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 17)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 18)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 19)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 20)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 21)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 22)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 23)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 24)

frame = Frame(top, height = 20, width = 20, bg = 'pink')
frame.grid(column = 1, row = 25)

frame = Frame(top, height = 20, width = 20, bg = 'yellow')
frame.grid(column = 1, row = 26)

frame = Frame(top, height = 20, width = 20, bg = 'red')
frame.grid(column = 1, row = 27)
        
frame = Frame(top, height = 20, width = 20, bg = 'blue')
frame.grid(column = 1, row = 28)

frame = Frame(top, height = 20, width = 20, bg = 'black')
frame.grid(column = 1, row = 29)



rotationPosition = [[[[1,8], [1,9], [2,8], [2,9]]], [[[1,7], [1,8], [1,9], [2,7]], [[0,8], [1,8], [2,8], [2,9]], [[0,9], [1,7], [1,8], [1,9]],
                    [[0,7], [0,8], [1,8], [2,8]]], [[[1,7], [1,8], [1,9], [2,9]], [[0,8], [0,9], [1,8], [2,8]], [[0,7], [1,7], [1,8], [1,9]],
                    [[0,8], [1,8], [2,7], [2,8]]], [[[1,7], [1,8], [1,9], [2,8]], [[0,8], [1,8], [1,9], [2,8]], [[0,8], [1,7], [1,8], [1,9]],
                    [[0,8], [1,7], [1,8], [2,8]]], [[[1,7], [1,8], [2,8], [2,9]], [[0,9], [1,8], [1,9], [2,8]]], [[[1,8], [1,9], [2,7], [2,8]],
                    [[0,7], [1,7], [1,8], [2,8]]], [[[1,7], [1,8], [1,9], [1,10]], [[-1,9], [0,9], [1,9], [2,9]]], [[[1,7], [1,8], [1,9], [2,8], [3,8]],
                    [[0,8], [1,8], [1,9], [1,10], [2,8]], [[-1,8], [0,8], [1,7], [1,8], [1,9]], [[0,8], [1,6], [1,7], [1,8], [2,8]]],
                    [[[1,7], [1,8], [1,9], [2,7], [2,8]], [[0,8], [1,8], [1,9], [2,8], [2,9]], [[0,8], [0,9], [1,7], [1,8], [1,9]],
                    [[0,7], [0,8], [1,7], [1,8], [2,8]]], [[[1,7], [1,8], [1,9], [2,8], [2,9]], [[0,8], [0,9], [1,8], [1,9], [2,8]],
                    [[0,7], [0,8], [1,7], [1,8], [1,9]], [[0,8], [1,7], [1,8], [2,7], [2,8]]], [[[1,7], [1,8], [1,9], [1,10], [2,7]],
                    [[-1,9], [0,9], [1,9], [2,9], [2,10]], [[0,10], [1,7], [1,8], [1,9], [1,10]], [[-1,8], [-1,9], [0,9], [1,9], [2,9]]],
                    [[[1,7], [1,8], [1,9], [1,10], [2,10]], [[-1,9], [-1,10], [0,9], [1,9], [2,9]], [[0,7], [1,7], [1,8], [1,9], [1,10]],
                    [[-1,9], [0,9], [1,9], [2,8], [2,9]]], [[[1,6], [1,7], [1,8], [1,9], [1,10]], [[-1,8], [0,8], [1,8], [2,8], [3,8]]], [[[1,8]]], [[[1,8]]],
                    [[[1,8]]]]
#1-4 piece O shape, 2-4 piece L shape, 3-4 piece J shape, 4-4 piece T shape, 5-4 piece Z shape, 6-4 piece S shape, 7-4 piece I shape
#8-5 piece T shape, 9-5 piece b shape, 10-5 piece d shape, 11-5 piece L shape, 12-5 piece J shape, 13-5 piece I piece
#14-vertical lightning powerup, 15-5x5 bomb powerup, 16-3x9 nuke powerup
#anti-clockwise
#[Y,X]

Xpiece = 0 #the piece's horizontal distance moved 
Ypiece = 0 #the piece's vertical distance moved
startPiece = random.randint(0,15) #type of piece

pieceBlocks = len(rotationPosition[startPiece][0]) #number of blocks in the piece

blockColour = ["#FF9900", "#0022FF", "#FF00EC", "#00E6FF", "#FFEC00", "#86FF00", "#FF0000", "#610034", "#00734D", "#2E6000", "#2A00B8", "#5200A5", "#660000",
               "black", "black", "black"]
#colour of each piece type


for i in range(0,pieceBlocks):
    frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
    frame.grid(column = rotationPosition[startPiece][0][i][1], row = rotationPosition[startPiece][0][i][0])


def left(event):
    global Xpiece
    global Ypiece
    global movePiece
    testXpiece = Xpiece - 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][0][i][1] + testXpiece < 1:
            pieceInGrid = False
    if pieceInGrid == True:
        Xpiece = Xpiece - 1
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, bg = 'black')
            frame.grid(column = rotationPosition[startPiece][0][i][1] + Xpiece + 1, row = rotationPosition[startPiece][0][i][0] + Ypiece)
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
            frame.grid(column = rotationPosition[startPiece][0][i][1] + Xpiece, row = rotationPosition[startPiece][0][i][0] + Ypiece)

def right(event):
    global Xpiece
    global Ypiece
    global movePiece
    testXpiece = Xpiece + 1
    pieceInGrid = True
    for i in range(0,pieceBlocks):
        if rotationPosition[startPiece][0][i][1] + testXpiece > 15:
            pieceInGrid = False
    if pieceInGrid == True:
        Xpiece = Xpiece + 1
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, bg = 'black')
            frame.grid(column = rotationPosition[startPiece][0][i][1] + Xpiece - 1, row = rotationPosition[startPiece][0][i][0] + Ypiece)
        for i in range(0,pieceBlocks):
            frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
            frame.grid(column = rotationPosition[startPiece][0][i][1] + Xpiece, row = rotationPosition[startPiece][0][i][0] + Ypiece)

def up(event):
    x=0
    y=-10
    canvas.move(circle, x, y)
def downPress(event):
    global gameDown
    global pressDown
    global pressOnce
    global drop
    global userDown
    global runGravity
    pressDown = True
    checkGravity()
    
def downRelease(event):
    global gameDown
    global pressDown
    global pressOnce
    pressDown = False
    checkGravity()
    
def shift(event):
    x=10
    y=10
    canvas.move(circle, x, y)

def checkGravity():
    global pressDown
    global drop
    global speed
    global checkGravityActive
    if checkGravityActive == False:
        if pressDown == False:
            drop = 1
            speed = 0.9
            checkGravityActive = True
            gravity()
        else:
            drop = 0.05
            speed = 0.04
            downTimer.cancel()
            checkGravityActive = True
            gravity()
    
def gravity():
    global Ypiece
    global dropTimer
    global movePiece
    global gameDown
    global userDown
    global pressDown
    global pressOnce
    global drop
    global runGravity
    global downTimer
    global speed
    global checkGravityActive
    print(time.time() - dropTimer)
    start = time.time()
    downTimer = threading.Timer(drop, checkGravity)
    downTimer.start()
    movePiece = True
    if time.time() - dropTimer > speed:
        testYpiece = Ypiece + 1
        pieceInGrid = True
        print("gravity")
        for i in range(0,pieceBlocks):
            if rotationPosition[startPiece][0][i][0] + testYpiece > 30:
                pieceInGrid = False
        if pieceInGrid == True:
            Ypiece = Ypiece + 1
            for j in range(1,15):
                frame = Frame(top, height = 20, width = 20, bg = 'black')
                frame.grid(column = j, row = rotationPosition[startPiece][0][0][0] + Ypiece - 1)
            for i in range(0,pieceBlocks):
                frame = Frame(top, height = 20, width = 20, bg = 'black')
                frame.grid(column = rotationPosition[startPiece][0][i][1] + Xpiece, row = rotationPosition[startPiece][0][i][0] + Ypiece - 1)
            for i in range(0,pieceBlocks):
                frame = Frame(top, height = 20, width = 20, borderwidth = 1, relief = 'solid', bg = blockColour[startPiece])
                frame.grid(column = rotationPosition[startPiece][0][i][1] + Xpiece, row = rotationPosition[startPiece][0][i][0] + Ypiece)
        else:
            pass
        dropTimer = time.time()
        movePiece = False
    checkGravityActive = False

checkGravityActive = False
pressDown = False
dropTimer = time.time()
checkGravity()
top.bind("<Shift_L>", shift)
top.bind("<Shift_R>", gravity)
top.bind("<Left>", left)
top.bind("<Right>", right)
top.bind("<Up>", up)
top.bind("<KeyPress-Down>", downPress)
top.bind("<KeyRelease-Down>", downRelease)
         
top.mainloop()

