from tkinter import*
from PIL import Image, ImageTk
top = Tk()
top.geometry("800x800")
top.configure(bg='green')


frame = Frame(top, height=60, width=60, bg='white')
frame.grid(column=0, row=0, padx=100)
frame = Frame(top, height=60, width=60, bg='white')
frame.grid(column=1, row=1)
        


def left(event):
    x=-10
    y=0
    canvas.move(circle, x, y)
def right(event):
    x=10
    y=0
    canvas.move(circle, x, y)
def up(event):
    x=0
    y=-10
    canvas.move(circle, x, y)
def down(event):
    x=0
    y=10
    canvas.move(circle, x, y)
def shift(event):
    print("shift")
    x=10
    y=10
    canvas.move(circle, x, y)

top.bind("<Shift_L>", shift)
top.bind("<Shift_R>", shift)
top.bind("<Left>", left)
top.bind("<Right>", right)
top.bind("<Up>", up)
top.bind("<Down>", down)
         
top.mainloop()
