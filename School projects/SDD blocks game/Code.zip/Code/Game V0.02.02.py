from tkinter import*
from PIL import Image, ImageTk
top = Tk()
top.geometry("800x700")
top.configure(bg='green')
for i in range(1,16):
    for j in range(1,30):
        frame = Frame(top, height=20, width=20, bg='white')
        frame.grid(column=i, row=j)

frame = Frame(top, height=20, width=20, bg='black')
frame.grid(column=0, row=0, padx=100)

frame = Frame(top, height=20, width=20, bg='pink')
frame.grid(column=1, row=30)

frame = Frame(top, height=20, width=20, bg='red')
frame.grid(column=2, row=30)

frame = Frame(top, height=20, width=20, bg='blue')
frame.grid(column=3, row=30)

frame = Frame(top, height=20, width=20, bg='black')
frame.grid(column=4, row=30)

frame = Frame(top, height=20, width=20, bg='red')
frame.grid(column=5, row=30)

frame = Frame(top, height=20, width=20, bg='yellow')
frame.grid(column=6, row=30)

frame = Frame(top, height=20, width=20, bg='red')
frame.grid(column=7, row=30)

frame = Frame(top, height=20, width=20, bg='blue')
frame.grid(column=8, row=30)

frame = Frame(top, height=20, width=20, bg='red')
frame.grid(column=9, row=30)

frame = Frame(top, height=20, width=20, bg='black')
frame.grid(column=10, row=30)

frame = Frame(top, height=20, width=20, bg='yellow')
frame.grid(column=11, row=30)

frame = Frame(top, height=20, width=20, bg='pink')
frame.grid(column=12, row=30)

frame = Frame(top, height=20, width=20, bg='red')
frame.grid(column=13, row=30)

frame = Frame(top, height=20, width=20, bg='yellow')
frame.grid(column=14, row=30)

frame = Frame(top, height=20, width=20, bg='blue')
frame.grid(column=15, row=30)









def left(event):
    x=-10
    y=0
    canvas.move(circle, x, y)
def right(event):
    x=10
    y=0
    canvas.move(circle, x, y)
def up(event):
    x=0
    y=-10
    canvas.move(circle, x, y)
def down(event):
    x=0
    y=10
    canvas.move(circle, x, y)
def shift(event):
    print("shift")
    x=10
    y=10
    canvas.move(circle, x, y)

top.bind("<Shift_L>", shift)
top.bind("<Shift_R>", shift)
top.bind("<Left>", left)
top.bind("<Right>", right)
top.bind("<Up>", up)
top.bind("<Down>", down)
         
top.mainloop()
